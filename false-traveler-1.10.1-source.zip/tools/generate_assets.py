"""Deterministic original pixel artwork. Run with Pillow; not required at runtime."""
from pathlib import Path
import json, random
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1] / "src/main/resources/assets/false_traveler"

def save(im, name):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    im.save(path)

def write(name, obj):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def fill_noise(im, box, color, seed, strength=8):
    r = random.Random(seed)
    for y in range(box[1], box[3]):
        for x in range(box[0], box[2]):
            n = r.randint(-strength,strength)
            im.putpixel((x,y), tuple(max(0,min(255,c+n)) for c in color)+(255,))

def sigil(d, cx, cy, color, scale=1):
    # The same broken compass appears on Luka's clasp and the shrine murals.
    s=scale
    d.line([(cx,cy-4*s),(cx+3*s,cy),(cx,cy+4*s),(cx-3*s,cy),(cx,cy-4*s)],fill=color,width=s)
    d.line([(cx,cy-2*s),(cx,cy+2*s)],fill=color,width=s)
    d.point((cx+4*s,cy-3*s),fill=color)

for variant in ("luka", "luka_awakened", "shadow"):
    im=Image.new("RGBA", (64,64), (0,0,0,0)); d=ImageDraw.Draw(im)
    dark=variant != "luka"; shadow=variant == "shadow"
    blue=(40,73,111) if not dark else (43,29,64)
    light=(69,110,149) if not dark else (72,41,94)
    skin=(204,158,121) if not shadow else (31,29,42)
    hair=(58,46,40) if not shadow else (23,21,35)
    for box,c in [((0,0,32,16),skin),((16,16,40,32),blue),((40,16,56,32),blue),((0,16,16,32),(41,43,51)),((0,32,20,46),blue)]:
        fill_noise(im,box,c,variant+str(box),5)
    # Classic humanoid UVs: face, front tunic, boots, hands, cloak.
    d.rectangle((8,0,23,7),fill=hair);d.rectangle((0,8,7,15),fill=hair);d.rectangle((24,8,31,15),fill=hair)
    d.rectangle((8,8,15,9),fill=hair);d.rectangle((8,10,8,12),fill=hair);d.rectangle((15,10,15,12),fill=hair)
    eyes=(127,196,215) if not dark else (213,138,237)
    d.point((10,11),fill=eyes);d.point((13,11),fill=eyes);d.line((11,14,12,14),fill=(119,83,68))
    if shadow:d.line((9,11,10,11),fill=eyes);d.line((13,11,14,11),fill=eyes)
    # Silver shoulder clasp / overlapping coat edge.
    d.rectangle((20,20,22,30),fill=light);d.rectangle((20,30,27,31),fill=(160,159,152))
    d.line((23,20,23,28),fill=(28,38,56));d.rectangle((25,20,27,22),fill=(190,202,203))
    d.point((26,21),fill=blue)
    d.rectangle((44,28,47,31),fill=skin);d.line((44,27,47,27),fill=(165,166,160))
    d.rectangle((4,29,7,31),fill=(25,23,29));d.line((4,28,7,28),fill=(91,81,69))
    d.rectangle((1,44,9,45),fill=(137,155,168) if not dark else (119,79,133))
    sigil(d,5,38,(167,184,194) if not dark else (195,145,211))
    # Transparent hat layer keeps the face visible; soft blue shoulder hood.
    for x in range(40,48):im.putpixel((x,8),blue+(255,))
    save(im, f"textures/entity/{variant}.png")

im=Image.new("RGBA",(16,16));d=ImageDraw.Draw(im)
d.rectangle((3,1,12,14),fill=(26,39,53));d.rectangle((4,2,12,13),fill=(170,151,107))
d.rectangle((3,1,10,12),fill=(41,75,109));d.line((4,2,4,11),fill=(113,140,154))
d.line((5,13,11,13),fill=(236,221,180));d.rectangle((9,11,10,15),fill=(168,87,65))
sigil(d,7,6,(215,200,157));save(im,"textures/item/journal.png")

im=Image.new("RGBA",(16,16));d=ImageDraw.Draw(im)
d.line([(5,1),(3,3),(4,6),(7,8),(11,5),(12,2),(10,1)],fill=(201,172,102),width=1)
d.polygon([(7,5),(12,10),(7,15),(2,10)],fill=(85,68,39));d.polygon([(7,6),(11,10),(7,14),(3,10)],fill=(228,196,113))
d.polygon([(7,8),(9,10),(7,12),(5,10)],fill=(166,211,208));d.point((7,9),fill=(245,255,235))
save(im,"textures/item/dawn_charm.png")

for kind in ("valley_stone","altar_side","altar_top","pedestal_side","pedestal_top"):
    im=Image.new("RGBA",(16,16));d=ImageDraw.Draw(im)
    base=(72,82,84) if kind=="valley_stone" else (52,55,68) if kind.startswith("altar") else (106,115,112)
    fill_noise(im,(0,0,16,16),base,kind,10)
    if kind=="valley_stone":
        for y in (0,8):d.line((0,y,15,y),fill=(43,54,59))
        d.line((7,0,7,7),fill=(43,54,59));d.line((2,8,2,15),fill=(43,54,59))
        d.line((0,1,15,1),fill=(95,104,104));d.line((0,9,15,9),fill=(95,104,104))
    elif kind.endswith("side"):
        d.rectangle((0,0,15,2),fill=(143,143,127));d.rectangle((0,13,15,15),fill=(39,45,52))
        d.line((1,3,1,12),fill=(157,144,104));d.line((14,3,14,12),fill=(157,144,104))
        sigil(d,7,7,(188,179,128) if kind.startswith("altar") else (64,98,110))
    else:
        d.rectangle((1,1,14,14),outline=(177,159,109));d.rectangle((3,3,12,12),outline=(90,101,108))
        sigil(d,8,8,(158,196,200) if kind.startswith("pedestal") else (200,173,119))
    save(im,f"textures/block/{kind}.png")

im=Image.new("RGBA",(16,16));d=ImageDraw.Draw(im);sigil(d,7,8,(224,203,150),1)
save(im,"textures/gui/sigil.png")

for name in ("journal","dawn_charm"):
    write(f"models/item/{name}.json",{"parent":"minecraft:item/generated","textures":{"layer0":f"false_traveler:item/{name}"}})
for name in ("altar","pedestal","valley_stone"):
    write(f"blockstates/{name}.json",{"variants":{"":{"model":f"false_traveler:block/{name}"}}})
    write(f"models/item/{name}.json",{"parent":f"false_traveler:block/{name}"})
    if name=="valley_stone":
        write(f"models/block/{name}.json",{"parent":"minecraft:block/cube_all","textures":{"all":"false_traveler:block/valley_stone"}})
    else:
        write(f"models/block/{name}.json",{"parent":"minecraft:block/cube_bottom_top","textures":{"side":f"false_traveler:block/{name}_side","top":f"false_traveler:block/{name}_top","bottom":"false_traveler:block/valley_stone"}})

write("sounds.json",{
    "dialogue":{"subtitle":"subtitles.false_traveler.dialogue","sounds":[{"name":"minecraft:item.book.page_turn","type":"event","volume":0.8}]},
    "warning":{"subtitle":"subtitles.false_traveler.warning","sounds":[{"name":"minecraft:block.note_block.bell","type":"event","volume":0.9,"pitch":0.7}]},
    "transform":{"subtitle":"subtitles.false_traveler.transform","sounds":[{"name":"minecraft:entity.evoker.prepare_summon","type":"event","volume":0.8,"pitch":0.7}]},
    "defeat":{"subtitle":"subtitles.false_traveler.defeat","sounds":[{"name":"minecraft:ui.toast.challenge_complete","type":"event","volume":0.7,"pitch":1.1}]}
})

im=Image.new("RGB",(128,128),(20,30,43));d=ImageDraw.Draw(im)
for y in range(128):d.line((0,y,127,y),fill=(20+y//12,30+y//10,43+y//9))
d.polygon([(0,110),(29,42),(52,79),(86,24),(128,108)],fill=(51,75,88))
d.polygon([(0,127),(32,78),(65,115),(102,68),(128,111),(128,127)],fill=(24,39,51))
sigil(d,64,62,(219,197,139),8)
d.rectangle((5,5,122,122),outline=(160,143,104),width=2)
save(im,"icon.png")
print("Original assets generated:", ROOT)
