"""Validate and normalize the checked-in bilingual language resources.

The JSON files are the source of truth. Keeping this helper non-destructive prevents an old
hard-coded story table from restoring removed rewards or overwriting newly added UI keys.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "src/main/resources/assets/false_traveler/lang"
paths = {language: ROOT / f"{language}.json" for language in ("ja_jp", "en_us")}
documents = {language: json.loads(path.read_text(encoding="utf-8")) for language, path in paths.items()}

ja_keys = set(documents["ja_jp"])
en_keys = set(documents["en_us"])
if ja_keys != en_keys:
    missing_ja = sorted(en_keys - ja_keys)
    missing_en = sorted(ja_keys - en_keys)
    raise SystemExit(f"Language-key mismatch; missing ja={missing_ja}, missing en={missing_en}")

for language, path in paths.items():
    path.write_text(json.dumps(documents[language], ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

print(f"Validated {len(ja_keys)} bilingual language keys")
