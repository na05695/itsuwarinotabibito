from pathlib import Path
from PIL import Image
from io import BytesIO
import zipfile

ROOT=Path(__file__).resolve().parents[1]/"src/main/resources/assets/false_traveler/textures"

def rect(im,box,color): im.paste(color,box)
def px(im,x,y,color): im.putpixel((x,y),color)

def skin(awakened=False):
    im=Image.new("RGBA",(64,64),(0,0,0,0))
    if awakened:
        # The awakened renderer hides every humanoid cube. This atlas is exclusively used by
        # the connected eclipse-idol body, wings, halo and eye.
        dark=(8,10,27,255); navy=(16,25,55,255); purple=(73,35,118,255); cyan=(49,230,236,255); silver=(173,204,222,255)
        for y in range(64):
            for x in range(64):
                px(im,x,y,navy if (x//5+y//4)%2 else dark)
        for y in range(32,64,4): rect(im,(0,y,64,y+1),purple)
        for x,y in ((7,35),(20,39),(33,34),(47,42),(57,36),(12,52),(29,58),(44,55),(59,61)):
            rect(im,(x,y,min(64,x+3),min(64,y+2)),cyan);px(im,min(63,x+1),min(63,y+1),silver)
        # High-contrast eye and pupil UV islands for the eclipse-seraph model.
        rect(im,(20,50,39,57),dark);rect(im,(22,51,37,56),purple);rect(im,(27,51,32,56),cyan)
        rect(im,(0,58,8,64),cyan);rect(im,(2,59,6,64),dark);rect(im,(3,60,5,64),silver)
        return im
    skin=(195,139,105,255) if not awakened else (174,127,113,255)
    shade=(150,96,79,255)
    hair=(24,25,31,255) if not awakened else (27,18,32,255)
    navy=(20,34,62,255) if not awakened else (25,23,56,255)
    blue=(34,73,132,255) if not awakened else (53,39,104,255)
    light=(70,124,176,255) if not awakened else (93,61,145,255)
    cyan=(50,232,235,255); violet=(185,89,255,255); silver=(183,207,220,255); dark=(13,17,28,255)
    # Head base: paint every face, then hair and features on the front face.
    for b in ((0,8,8,16),(8,8,16,16),(16,8,24,16),(24,8,32,16),(8,0,16,8),(16,0,24,8)): rect(im,b,skin)
    rect(im,(8,8,16,11),hair); rect(im,(8,11,10,12),hair); rect(im,(14,10,16,12),hair)
    rect(im,(0,8,8,12),hair); rect(im,(16,8,24,12),hair); rect(im,(24,8,32,16),hair); rect(im,(8,0,16,8),hair)
    px(im,10,12,cyan);px(im,13,12,cyan);px(im,10,13,(18,55,61,255));px(im,13,13,(18,55,61,255));px(im,11,15,shade);px(im,12,15,shade)
    # Head overlay gives windswept fringe and a subtle cyan rim.
    rect(im,(40,8,48,10),hair);px(im,39,10,hair);px(im,47,10,hair);px(im,46,9,cyan)
    # Torso and coat.
    for b in ((16,20,20,32),(20,20,28,32),(28,20,32,32),(32,20,40,32),(20,16,28,20),(28,16,36,20)): rect(im,b,navy)
    rect(im,(21,20,27,32),blue);rect(im,(23,20,25,32),light);rect(im,(20,20,28,22),dark)
    rect(im,(32,20,40,32),blue);rect(im,(32,29,40,32),navy)
    # Compass clasp / awakened breast runes.
    if awakened:
        for x,y,c in ((21,22,cyan),(24,22,violet),(26,23,cyan),(22,26,violet),(25,28,cyan),(23,30,cyan)): px(im,x,y,c)
    else:
        rect(im,(24,21,27,24),silver);px(im,25,22,(34,73,132,255));px(im,26,22,(210,68,60,255))
        for x in (21,23,25,27): px(im,x,30,cyan)
    # Arms (old and modern left-arm regions).
    for b in ((40,20,44,32),(44,20,48,32),(48,20,52,32),(52,20,56,32),(36,52,40,64),(40,52,44,64),(44,52,48,64),(48,52,52,64)): rect(im,b,navy)
    rect(im,(44,28,48,32),dark);rect(im,(40,60,44,64),dark)
    if awakened:
        rect(im,(44,21,48,27),blue);rect(im,(40,53,44,59),(63,31,99,255));
        for x,y in ((45,22),(46,25),(41,54),(42,57)): px(im,x,y,violet if x<44 else cyan)
    else:
        rect(im,(44,27,48,29),light);rect(im,(40,59,44,61),light)
    # Legs and boots.
    for b in ((0,20,4,32),(4,20,8,32),(8,20,12,32),(12,20,16,32),(16,52,20,64),(20,52,24,64),(24,52,28,64),(28,52,32,64)): rect(im,b,navy)
    rect(im,(4,28,8,32),dark);rect(im,(20,60,24,64),dark);rect(im,(4,24,8,26),blue);rect(im,(20,56,24,58),blue)
    if awakened:
        for x,y in ((5,22),(6,25),(21,54),(22,58)): px(im,x,y,cyan if y%2==0 else violet)
    # Outer coat/cloak layer, including the custom model's back panel UV.
    rect(im,(16,32,40,48),(0,0,0,0));rect(im,(0,32,24,48),(0,0,0,0))
    rect(im,(0,32,9,44),blue);rect(im,(0,42,9,45),navy)
    for x in range(1,9,2): px(im,x,43,cyan if not awakened or x<5 else violet)
    if awakened:
        # Custom shoulder guards and floating crown use these reserved UV cells.
        rect(im,(32,48,64,59),(35,28,76,255));rect(im,(32,48,64,50),(95,72,156,255))
        rect(im,(32,40,56,44),silver);px(im,35,41,cyan);px(im,47,41,violet);px(im,53,42,cyan)
    return im

def item_icon(kind):
    im=Image.new("RGBA",(16,16),(0,0,0,0)); cyan=(61,231,236,255); blue=(38,64,116,255); edge=(15,20,38,255); silver=(189,215,227,255); purple=(113,60,166,255)
    if kind=="flask":
        rect(im,(6,2,10,5),silver);rect(im,(5,5,11,13),edge);rect(im,(6,7,10,12),cyan);px(im,7,8,(255,220,92,255));px(im,8,10,(255,255,255,255))
    elif kind=="bell":
        rect(im,(7,2,9,4),silver);rect(im,(4,4,12,11),blue);rect(im,(3,10,13,12),purple);rect(im,(7,12,9,14),cyan)
    elif kind=="feather":
        for i in range(3,13):px(im,13-i,i,cyan if i%2 else silver)
        for i in range(4,11):rect(im,(13-i,i,16-i,i+1),purple)
        rect(im,(3,11,5,15),edge)
    elif kind=="hourglass":
        rect(im,(4,2,12,4),silver);rect(im,(4,12,12,14),silver);rect(im,(5,4,11,12),edge)
        for i in range(4):rect(im,(6+i,5+i,10-i,6+i),purple)
        rect(im,(7,9,9,12),cyan)
    elif kind=="sigil":
        rect(im,(2,2,14,14),edge)
        for x,y in ((7,2),(8,2),(4,3),(11,3),(3,4),(12,4),(2,7),(13,7),(2,8),(13,8),(3,11),(12,11),(4,12),(11,12),(7,13),(8,13)):px(im,x,y,cyan)
        for x,y in ((7,4),(8,4),(6,5),(9,5),(5,6),(10,6),(4,7),(11,7),(5,8),(10,8),(6,9),(9,9),(7,10),(8,10)):px(im,x,y,purple)
        rect(im,(7,6,9,9),silver)
    elif kind=="sword":
        for i in range(2,12): rect(im,(11-i,i,13-i,i+2),silver)
        for i in range(3,10,2): px(im,11-i,i,cyan)
        rect(im,(3,10,10,12),blue);rect(im,(7,11,9,15),edge);px(im,8,13,purple)
    else:
        shapes={
            "helmet":((3,3,13,11),(5,8,11,12)),
            "chestplate":((3,4,13,13),(6,2,10,7)),
            "leggings":((4,3,12,10),(4,8,7,15),(9,8,12,15)),
            "boots":((3,4,7,13),(9,4,13,13),(2,11,7,15),(9,11,14,15)),
        }
        parts=shapes[kind];rect(im,parts[0],blue)
        for p in parts[1:]:rect(im,p,edge)
        rect(im,(4,4,12,6),purple);px(im,7,7,cyan);px(im,8,8,cyan)
    return im

def armor_layer(second=False):
    # Reuse only the vanilla armor alpha/shading mask so pixels outside valid armor UV islands stay
    # transparent. The previous full-canvas fill produced the large dark cuboids reported in game.
    jar=Path(__file__).resolve().parents[1]/"build/moddev/artifacts/neoforge-21.1.235-client-extra-aka-minecraft-resources.jar"
    entry=f"assets/minecraft/textures/models/armor/diamond_layer_{2 if second else 1}.png"
    if jar.exists():
        with zipfile.ZipFile(jar) as z: reference=Image.open(BytesIO(z.read(entry))).convert("RGBA")
    else:
        reference=Image.new("RGBA",(64,32),(0,0,0,0))
        for box in ((0,0,32,16),(16,16,40,32),(40,16,64,32) if not second else (0,16,32,32)):rect(reference,box,(255,255,255,255))
    im=Image.new("RGBA",(64,32),(0,0,0,0));base=(28,54,96);cyan=(66,224,229);purple=(91,48,139)
    for y in range(32):
        for x in range(64):
            r,g,b,a=reference.getpixel((x,y))
            if not a:continue
            light=(r+g+b)/765
            color=tuple(min(255,int(c*(.55+light*.75))) for c in base)
            if (x*3+y*5)%29==0:color=cyan
            elif (x+y*2)%31==0:color=purple
            px(im,x,y,(*color,a))
    return im

entity=ROOT/"entity";items=ROOT/"item";entity.mkdir(parents=True,exist_ok=True);items.mkdir(parents=True,exist_ok=True)
skin(False).save(entity/"luka.png")
skin(True).save(entity/"luka_awakened.png")
item_icon("sword").save(items/"traveler_sword.png")
item_icon("sigil").save(items/"geometry_sigil.png")
item_icon("flask").save(items/"dawn_flask.png")
item_icon("bell").save(items/"aegis_bell.png")
item_icon("feather").save(items/"rift_feather.png")
item_icon("hourglass").save(items/"binding_hourglass.png")
for name in ("helmet","chestplate","leggings","boots"):item_icon(name).save(items/f"traveler_{name}.png")
armor=ROOT/"models/armor";armor.mkdir(parents=True,exist_ok=True)
armor_layer(False).save(armor/"traveler_layer_1.png")
armor_layer(True).save(armor/"traveler_layer_2.png")
