import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/** Builds the boss texture as a real Minecraft UV atlas plus a private model-parts area. */
public final class GenerateBossSkin {
    private static final int CLEAR = 0x00000000;
    private static final int SKIN = argb("f4d5cb"), SKIN_SHADOW = argb("d8aaa3");
    private static final int HAIR = argb("eee8eb"), HAIR_LIGHT = argb("fffafb"), HAIR_SHADOW = argb("bcb3c2");
    private static final int RED = argb("a71935"), RED_LIGHT = argb("dc3550"), RED_DARK = argb("5b1025");
    private static final int GOLD = argb("d6a53c"), GOLD_LIGHT = argb("f4d878"), RUBY = argb("f01838");
    private static final int EYE = argb("a00024"), DARK = argb("32131d"), WHITE = argb("fff8f1");

    private static BufferedImage image;

    public static void main(String[] args) throws Exception {
        if (args.length < 1 || args.length > 2) throw new IllegalArgumentException("boss output PNG and optional normal skin path required");
        image = new BufferedImage(128, 128, BufferedImage.TYPE_INT_ARGB);
        fill(0, 0, 128, 128, CLEAR);
        head(); torso(); rightArm(); leftArm(); rightLeg(); leftLeg(); overlays(); modelParts();
        File output = new File(args[0]);
        File parent = output.getParentFile(); if (parent != null) parent.mkdirs();
        ImageIO.write(image, "png", output);
        if (args.length == 2) padNormalSkin(new File(args[1]));
    }

    private static void head() {
        // Base head: pale face with silver hair on every side.
        fill(8,0,8,8,HAIR); fill(16,0,8,8,HAIR_SHADOW);
        fill(0,8,8,8,HAIR_SHADOW); fill(8,8,8,8,SKIN); fill(16,8,8,8,HAIR); fill(24,8,8,8,HAIR_SHADOW);
        // Soft fringe, brows and ruby eyes on the front face.
        pixels(8,8,new String[]{
            "hhhhhhhh","HhhhhhhH","Hh....hH","h......h",
            "..d..d..","..e..e..","...ss...","...mm..."
        });
        // Hat layer: flowing silver hair, open over the face.
        fill(40,0,8,8,HAIR_LIGHT); fill(48,0,8,8,HAIR_SHADOW);
        fill(32,8,8,8,HAIR); fill(48,8,8,8,HAIR); fill(56,8,8,8,HAIR_SHADOW);
        overlayPixels(40,8,new String[]{
            "HHHHHHHH","HhhhhhhH","Hh....hH","H......H",
            "H......H","H......H","H......H","h......h"
        });
        // Gold-and-ruby diadem on the visible overlay.
        set(43,8,GOLD); set(44,8,RUBY); set(45,8,GOLD); set(44,9,GOLD_LIGHT);
    }

    private static void torso() {
        fill(20,16,8,4,WHITE); fill(28,16,8,4,GOLD);
        fill(16,20,4,12,RED_DARK); fill(20,20,8,12,WHITE); fill(28,20,4,12,RED); fill(32,20,8,12,RED_DARK);
        for(int y=20;y<32;y++){ set(20,y,GOLD); set(27,y,GOLD); }
        for(int y=22;y<32;y++) set(23,y,RED);
        set(24,22,RUBY); set(24,23,RUBY); set(23,24,GOLD_LIGHT); set(24,24,GOLD_LIGHT);
        fill(22,30,4,2,RED_DARK);
    }

    private static void rightArm() {
        fill(44,16,4,4,WHITE); fill(48,16,4,4,GOLD);
        fill(40,20,4,12,RED); fill(44,20,4,12,WHITE); fill(48,20,4,12,GOLD); fill(52,20,4,12,RED_DARK);
        fill(44,27,4,2,RED); fill(44,29,4,1,GOLD_LIGHT); fill(44,30,4,2,SKIN);
    }

    private static void leftArm() {
        fill(36,48,4,4,WHITE); fill(40,48,4,4,GOLD);
        fill(32,52,4,12,RED_DARK); fill(36,52,4,12,WHITE); fill(40,52,4,12,GOLD); fill(44,52,4,12,RED);
        fill(36,59,4,2,RED); fill(36,61,4,1,GOLD_LIGHT); fill(36,62,4,2,SKIN);
    }

    private static void rightLeg() {
        fill(4,16,4,4,WHITE); fill(8,16,4,4,RED);
        fill(0,20,4,12,RED_DARK); fill(4,20,4,12,WHITE); fill(8,20,4,12,GOLD); fill(12,20,4,12,RED);
        for(int y=20;y<29;y++) set(7,y,RED);
        fill(4,29,4,1,GOLD_LIGHT); fill(4,30,4,2,RED_DARK);
    }

    private static void leftLeg() {
        fill(20,48,4,4,WHITE); fill(24,48,4,4,RED);
        fill(16,52,4,12,RED); fill(20,52,4,12,WHITE); fill(24,52,4,12,GOLD); fill(28,52,4,12,RED_DARK);
        for(int y=52;y<61;y++) set(20,y,RED);
        fill(20,61,4,1,GOLD_LIGHT); fill(20,62,4,2,RED_DARK);
    }

    private static void overlays() {
        // Robe/cape overlays. Transparent gaps preserve the readable humanoid silhouette.
        outline(20,36,8,12,GOLD); fill(21,37,6,10,RED);
        fill(23,37,2,9,WHITE); set(24,39,RUBY); set(24,42,GOLD_LIGHT);
        outline(44,36,4,12,GOLD); fill(45,37,2,8,RED_LIGHT);
        outline(4,36,4,12,GOLD); fill(5,37,2,9,RED);
        outline(52,52,4,12,GOLD); fill(53,53,2,8,RED_LIGHT);
        outline(4,52,4,12,GOLD); fill(5,53,2,9,RED);
    }

    private static void modelParts() {
        // Dedicated 64..127 area used only by TravelerModel additions.
        striped(64,0,20,13,RED_DARK,RED,GOLD);      // cloak
        striped(64,16,20,21,HAIR_SHADOW,HAIR,HAIR_LIGHT); // long back hair
        striped(64,40,8,15,RED_DARK,RED,GOLD);      // left ribbon
        striped(74,40,8,15,RED,RED_LIGHT,GOLD);     // right ribbon
        striped(84,40,36,12,GOLD,GOLD_LIGHT,RUBY);  // crown
        striped(88,0,8,8,GOLD,RUBY,GOLD_LIGHT);     // chest gem
        striped(96,0,6,32,GOLD,RED_DARK,GOLD_LIGHT);// staff shaft
        striped(104,0,20,12,GOLD,RED,RUBY);         // staff head
        striped(104,14,12,8,RUBY,RED_LIGHT,GOLD_LIGHT); // staff crystal
    }

    private static void pixels(int x,int y,String[] rows){
        for(int yy=0;yy<rows.length;yy++)for(int xx=0;xx<rows[yy].length();xx++){
            int c=switch(rows[yy].charAt(xx)){case 'h'->HAIR;case 'H'->HAIR_LIGHT;case 'd'->DARK;case 'e'->EYE;case 's'->SKIN_SHADOW;case 'm'->RED_LIGHT;default->SKIN;};
            set(x+xx,y+yy,c);
        }
    }
    private static void overlayPixels(int x,int y,String[] rows){
        for(int yy=0;yy<rows.length;yy++)for(int xx=0;xx<rows[yy].length();xx++){
            int c=switch(rows[yy].charAt(xx)){case 'h'->HAIR;case 'H'->HAIR_LIGHT;default->CLEAR;};
            set(x+xx,y+yy,c);
        }
    }
    private static void padNormalSkin(File file) throws Exception {
        BufferedImage original=ImageIO.read(file);
        if(original.getWidth()==128&&original.getHeight()==128)return;
        if(original.getWidth()!=64||original.getHeight()!=64)throw new IllegalArgumentException("normal skin must be 64x64 or 128x128");
        BufferedImage padded=new BufferedImage(128,128,BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics=padded.createGraphics();graphics.drawImage(original,0,0,null);graphics.dispose();
        ImageIO.write(padded,"png",file);
    }
    private static void striped(int x,int y,int w,int h,int a,int b,int accent){
        fill(x,y,w,h,a); for(int yy=1;yy<h;yy+=3)fill(x,y+yy,w,1,b); for(int xx=2;xx<w;xx+=7)for(int yy=0;yy<h;yy+=4)set(x+xx,y+yy,accent);
    }
    private static void outline(int x,int y,int w,int h,int c){fill(x,y,w,1,c);fill(x,y+h-1,w,1,c);fill(x,y,1,h,c);fill(x+w-1,y,1,h,c);}
    private static void fill(int x,int y,int w,int h,int c){for(int yy=y;yy<y+h;yy++)for(int xx=x;xx<x+w;xx++)set(xx,yy,c);}
    private static void set(int x,int y,int c){if(x>=0&&y>=0&&x<image.getWidth()&&y<image.getHeight())image.setRGB(x,y,c);}
    private static int argb(String rgb){return new Color(Integer.parseInt(rgb,16)).getRGB();}
}
