package jp.false_traveler;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CombatRulesTest {
    @Test void healthScalesForTheLockedStartingParty() {
        assertEquals(240, CombatRules.health(240, 1), .0001);
        assertEquals(420, CombatRules.health(240, 2), .0001);
        assertEquals(600, CombatRules.health(240, 3), .0001);
        assertEquals(780, CombatRules.health(240, 4), .0001);
        assertEquals(1860, CombatRules.health(240, 10), .0001);
        assertEquals(1860, CombatRules.health(240, 11), .0001);
        assertEquals(1.0,CombatRules.damageScale(1),.0001);
        assertEquals(1.54,CombatRules.damageScale(4),.0001);
        assertEquals(2.62,CombatRules.damageScale(10),.0001);
    }
    @Test void damageCanSkipOneThresholdButHealingNeverRewindsAPhase() {
        assertEquals(1, CombatRules.phase(147, 240, 1));
        assertEquals(2, CombatRules.phase(144, 240, 1));
        assertEquals(3, CombatRules.phase(72, 240, 1));
        assertEquals(3, CombatRules.phase(12, 240, 1));
        assertEquals(3, CombatRules.phase(240, 240, 3));
        assertEquals(2, CombatRules.phase(200, 240, 2));
    }
    @Test void DefeatIsNotReplacedByATransformation() {
        assertEquals(1, CombatRules.phase(0, 240, 1));
        assertEquals(2, CombatRules.phase(-50, 240, 2));
    }
    @Test void eachTelegraphAndPostCompletionCooldownMatchesTheSpecification() {
        int[] telegraph = {12, 20, 30, 40, 40};
        int[] cooldown = {40, 140, 200, 400, 300};
        for (int action = 1; action <= 5; action++) {
            assertEquals(telegraph[action - 1], CombatRules.windup(action));
            assertEquals(cooldown[action - 1], CombatRules.cooldown(action));
        }
        assertEquals(40, CombatRules.windup(6));
        assertEquals(16, CombatRules.recovery(1));
        assertEquals(16, CombatRules.recovery(2));
        assertEquals(12, CombatRules.recovery(3));
    }
    @Test void swordDamageAndDisplayedArcShareTheSameBoundary() {
        assertTrue(CombatRules.withinSword(0, 3, 0, 1));
        assertTrue(CombatRules.withinSword(3, 0, 0, 1));
        assertFalse(CombatRules.withinSword(0, 3.01, 0, 1));
        assertFalse(CombatRules.withinSword(0, -1, 0, 1));
        assertTrue(CombatRules.withinSword(-3, 0, -1, 0));
        assertFalse(CombatRules.withinSword(1, 0, -1, 0));
    }
    @Test void runeAndShockwaveHaveInclusiveFixedCircularEdges() {
        assertTrue(CombatRules.withinCircle(1.5, 2, 2.5));
        assertFalse(CombatRules.withinCircle(1.51, 2, 2.5));
        assertTrue(CombatRules.withinCircle(0, 7, 7));
        assertFalse(CombatRules.withinCircle(7, 7, 7));
    }
}
