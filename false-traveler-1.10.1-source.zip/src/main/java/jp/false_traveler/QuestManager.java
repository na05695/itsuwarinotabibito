package jp.false_traveler;

import com.google.gson.*;
import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.*;
import net.minecraft.world.phys.Vec3;

/** Story, authoritative menu sessions, cooperative readiness and atomic reward claims. */
public final class QuestManager {
    private record Session(int id,Stage stage,String mode,net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level> dimension,
                           int entityId,BlockPos pos,long expiry,Set<String> actions){}
    private static final Map<UUID,Session> SESSIONS=new HashMap<>();
    private static final Map<UUID,Long> LAST_ACTION=new HashMap<>();
    private static int nonce;
    private static long revealStarted,cleanupAt=-1,endingAt=-1;
    private static final Set<UUID> ENDING_RECIPIENTS=new HashSet<>();
    private static int revealPage=-1;
    public static boolean eligible(ServerPlayer p){return p.isAlive()&&!p.isCreative()&&!p.isSpectator();}
    public static boolean canTalk(ServerPlayer p){return p.isAlive()&&!p.isSpectator();}
    public static void notify(ServerPlayer p,String key){p.displayClientMessage(Component.translatable(key),false);}
    private static void tellAll(MinecraftServer s,String key){for(ServerPlayer p:s.getPlayerList().getPlayers())if(Valley.isValley(p.level()))notify(p,key);}
    public static void login(ServerPlayer p){
        QuestData d=QuestData.get(p.server);var r=d.player(p.getUUID());
        if(d.stage.ordinal()>=Stage.FRAGMENTS.ordinal()&&r.missionIndex<MissionManager.ordinaryCount()){r.missionIndex=MissionManager.ordinaryCount();d.setDirty();}
        if(!r.joined){r.joined=true;r.journalPending=true;d.setDirty();}
        if(r.journalPending)issueJournal(p);
        ensureGear(p,false);
        ensureBread(p);
        ensureVictoryItems(p);
        ensureSharedFinal(p);
        if(d.active()&&!d.alive.contains(p.getUUID())&&Valley.isValley(p.level()))Valley.safeEntry(p);
        sync(p);
    }
    public static void logout(ServerPlayer p){
        QuestData d=QuestData.get(p.server);d.alive.remove(p.getUUID());
        if(d.registered.remove(p.getUUID()))d.ready.clear();
        d.setDirty();SESSIONS.remove(p.getUUID());LAST_ACTION.remove(p.getUUID());
    }
    public static void issueJournal(ServerPlayer p){
        QuestData d=QuestData.get(p.server);var r=d.player(p.getUUID());
        if(p.getInventory().contains(new ItemStack(FalseTraveler.JOURNAL.get()))){r.journalPending=false;notify(p,"message.false_traveler.have_journal");}
        else if(InventoryGrant.give(p,new ItemStack(FalseTraveler.JOURNAL.get()))){r.journalPending=false;notify(p,"message.false_traveler.journal_received");}
        else {r.journalPending=true;notify(p,"message.false_traveler.inventory_full");}
        d.setDirty();
    }
    public static void openLuka(ServerPlayer p,LukaEntity luka){
        if(!Valley.isValley(p.level())||p.distanceToSqr(luka)>16||!canTalk(p))return;
        QuestData d=QuestData.get(p.server);
        if(d.active()){notify(p,"message.false_traveler.in_battle");return;}
        String body="dialogue.false_traveler."+d.stage.name().toLowerCase(Locale.ROOT);
        List<String> choices=switch(d.stage){
            case NOT_STARTED->List.of("accept","ai_talk","later");
            case SUPPLIES->List.of("deliver","ai_talk","later");
            case DEFENSE->List.of("missions","ai_talk","later");
            case FRAGMENTS->List.of("doubt","shrine_hint","ai_talk","later");
            case READY->List.of("altar_hint","doubt","ai_talk","later");
            case CLEARED->List.of("history","claim","ai_talk","later");
            default->List.of("later");
        };
        if(d.stage==Stage.READY)open(p,"dialogue","entity.false_traveler.luka",body,choices,luka.getId(),null,String.valueOf(d.registered.size()),String.valueOf(d.ready.size()),String.valueOf(ModConfig.MAX_PARTICIPANTS.get()));
        else open(p,"dialogue","entity.false_traveler.luka",body,choices,luka.getId(),null);
        p.playNotifySound(SoundEvents.AMETHYST_BLOCK_CHIME,SoundSource.PLAYERS,0.45F,1.1F);
    }
    public static void openJournal(ServerPlayer p){
        ensureGear(p,false);
        open(p,"journal","menu.false_traveler.journal","dialogue.false_traveler.journal",List.of("objective","missions","ai_hint","history","travel","return","claim"),-1,null);
    }
    public static void openAltar(ServerPlayer p){
        if(!Valley.isValley(p.level())||p.distanceToSqr(Vec3.atCenterOf(Valley.ALTAR_POS))>25)return;
        QuestData d=QuestData.get(p.server);
        if(d.stage!=Stage.READY){notify(p,d.stage==Stage.CLEARED?"message.false_traveler.completed":"message.false_traveler.altar_locked");return;}
        if(!eligible(p)){notify(p,"message.false_traveler.survival_only");return;}
        List<String> choices=d.registered.contains(p.getUUID())?List.of("ready","unregister","refresh"):List.of("register","refresh","later");
        open(p,"ready","menu.false_traveler.altar","dialogue.false_traveler.ready",choices,-1,Valley.ALTAR_POS,
             String.valueOf(d.registered.size()),String.valueOf(d.ready.size()),String.valueOf(ModConfig.MAX_PARTICIPANTS.get()));
    }
    private static void open(ServerPlayer p,String mode,String title,String body,List<String> actions,int entity,BlockPos pos,String...args){
        QuestData d=QuestData.get(p.server);int id=++nonce;
        SESSIONS.put(p.getUUID(),new Session(id,d.stage,mode,p.level().dimension(),entity,pos,p.server.overworld().getGameTime()+2400,Set.copyOf(actions)));
        JsonObject o=new JsonObject();o.addProperty("mode",mode);o.addProperty("session",id);o.addProperty("title",title);o.addProperty("body",body);
        o.addProperty("sourceId",entity);o.addProperty("stage",d.stage.ordinal());
        JsonArray a=new JsonArray();for(String s:args)a.add(s);o.add("args",a);
        JsonArray choices=new JsonArray();for(String s:actions){JsonObject c=new JsonObject();c.addProperty("id",s);c.addProperty("label","action.false_traveler."+s);choices.add(c);}o.add("choices",choices);
        Network.send(p,o);
    }
    static void openLiteral(ServerPlayer p,String mode,String title,String body,List<String> actions,int entity){
        QuestData d=QuestData.get(p.server);int id=++nonce;
        SESSIONS.put(p.getUUID(),new Session(id,d.stage,mode,p.level().dimension(),entity,null,p.server.overworld().getGameTime()+2400,Set.copyOf(actions)));
        JsonObject o=new JsonObject();o.addProperty("mode",mode);o.addProperty("session",id);o.addProperty("title",title);o.addProperty("body",body);o.addProperty("bodyLiteral",true);
        o.addProperty("sourceId",entity);o.addProperty("stage",d.stage.ordinal());o.add("args",new JsonArray());
        JsonArray choices=new JsonArray();for(String s:actions){JsonObject c=new JsonObject();c.addProperty("id",s);c.addProperty("label","action.false_traveler."+s);choices.add(c);}o.add("choices",choices);
        Network.send(p,o);
    }
    public static void openAiResult(ServerPlayer p,boolean lukaTalk,int sourceId,String text){
        String disclaimer="\n\n※AI の回答は必ずしも正しいとは限りません。重要な情報は確認するようにしてください。";
        openLiteral(p,lukaTalk?"dialogue":"journal",lukaTalk?"entity.false_traveler.luka":"menu.false_traveler.ai_hint",text+disclaimer,List.of(lukaTalk?"back_luka":"back","later"),lukaTalk?sourceId:-1);
    }
    public static void openAiPending(ServerPlayer p,boolean lukaTalk,int sourceId){
        openLiteral(p,lukaTalk?"dialogue":"journal",lukaTalk?"entity.false_traveler.luka":"menu.false_traveler.ai_hint","AIへ問い合わせています……\n通常は25秒以内に結果またはエラーが表示されます。",List.of(),lukaTalk?sourceId:-1);
    }
    public static void close(ServerPlayer p){SESSIONS.remove(p.getUUID());JsonObject o=new JsonObject();o.addProperty("mode","close");Network.send(p,o);}
    private static boolean valid(ServerPlayer p,Session s){
        if(s==null||p.server.overworld().getGameTime()>s.expiry||s.stage!=QuestData.get(p.server).stage||!s.dimension.equals(p.level().dimension()))return false;
        if(s.entityId>=0){Entity entity=p.level().getEntity(s.entityId);if(entity==null||p.distanceToSqr(entity)>64)return false;}
        if(s.pos!=null&&p.distanceToSqr(Vec3.atCenterOf(s.pos))>64)return false;
        return p.isAlive();
    }
    public static void action(ServerPlayer p,int id,String action){
        Session s=SESSIONS.get(p.getUUID());long now=p.server.overworld().getGameTime();
        if(!valid(p,s)||s.id!=id||!s.actions.contains(action))return;
        if(now-LAST_ACTION.getOrDefault(p.getUUID(),-100L)<4)return;
        LAST_ACTION.put(p.getUUID(),now);SESSIONS.remove(p.getUUID());
        QuestData d=QuestData.get(p.server);
        if(action.equals("skip")){
            if(d.stage==Stage.REVEAL&&d.alive.contains(p.getUUID())){d.skipped.add(p.getUUID());notify(p,"message.false_traveler.skip_voted");}return;
        }
        if(action.equals("later")){close(p);return;}
        if(s.mode.equals("journal")){
            if(!p.getInventory().contains(new ItemStack(FalseTraveler.JOURNAL.get())))return;
            switch(action){
                case "objective"->open(p,"journal","menu.false_traveler.objective",d.stage.objective(),List.of("back"),-1,null);
                case "missions"->MissionManager.open(p);
                case "mission_submit"->MissionManager.submit(p);
                case "mission_ai"->GroqService.askMission(p);
                case "ai_hint"->GroqService.ask(p,false,-1);
                case "history"->history(p);
                case "travel"->{close(p);Valley.enter(p);}
                case "return"->{close(p);Valley.leave(p);}
                case "claim"->{claim(p,true);openJournal(p);}
                case "back"->openJournal(p);
                default->{if(action.startsWith("history_"))historyPage(p,action);}
            }return;
        }
        if(s.mode.equals("ready")){readiness(p,action);return;}
        if(s.mode.equals("dialogue")){
            if(!canTalk(p))return;
            switch(action){
                case "accept"->{if(d.stage==Stage.NOT_STARTED){d.stage=Stage.SUPPLIES;d.setDirty();for(ServerPlayer q:p.server.getPlayerList().getPlayers())if(canTalk(q))ensureGear(q,q==p);tellAll(p.server,"message.false_traveler.quest_accepted");}reopenLuka(p,s);}
                case "deliver"->{deliver(p);reopenLuka(p,s);}
                case "missions"->MissionManager.open(p);
                case "ai_talk"->GroqService.ask(p,true,s.entityId);
                case "doubt"->open(p,"dialogue","entity.false_traveler.luka","dialogue.false_traveler.doubt",List.of("back_luka","later"),s.entityId,null);
                case "defense_hint","shrine_hint","altar_hint"->open(p,"dialogue","entity.false_traveler.luka","dialogue.false_traveler."+action,List.of("back_luka","later"),s.entityId,null);
                case "back_luka"->reopenLuka(p,s);
                case "history"->history(p);
                case "claim"->{claim(p,true);reopenLuka(p,s);}
            }
        }
    }
    private static void reopenLuka(ServerPlayer p,Session s){if(p.level().getEntity(s.entityId) instanceof LukaEntity l)openLuka(p,l);}
    private static void history(ServerPlayer p){
        QuestData d=QuestData.get(p.server);List<String> a=new ArrayList<>();
        if(d.stage!=Stage.NOT_STARTED)a.add("history_1");
        if(d.stage.ordinal()>=Stage.FRAGMENTS.ordinal())a.add("history_2");
        if(d.fragments!=0)a.add("history_3");
        if(d.revealed)a.add("history_4");
        if(d.stage==Stage.CLEARED)a.add("history_5");
        a.add("back");open(p,"journal","menu.false_traveler.history","dialogue.false_traveler.history",a,-1,null);
    }
    private static void historyPage(ServerPlayer p,String action){
        // Only a history action present in the current server-issued session reaches this method.
        open(p,"journal","menu.false_traveler.history","dialogue.false_traveler."+action,List.of("history","back"),-1,null);
    }
    private static void deliver(ServerPlayer p){
        QuestData d=QuestData.get(p.server);if(d.stage!=Stage.SUPPLIES)return;
        int amount=p.getInventory().countItem(Items.OAK_LOG);
        if(amount<16){notify(p,"message.false_traveler.need_logs");return;}
        // The log turn-in and its single reward are one atomic inventory transaction.
        if(!InventoryGrant.exchange(p,Items.OAK_LOG,16,new ItemStack(Items.BREAD,16))){notify(p,"message.false_traveler.inventory_full");return;}
        d.players.values().forEach(record->{record.breadEarned=true;record.logBonusEarned=false;record.logBonusClaimed=true;});
        for(ServerPlayer q:p.server.getPlayerList().getPlayers())if(canTalk(q)){
            var record=d.player(q.getUUID());record.breadEarned=true;record.logBonusEarned=false;record.logBonusClaimed=true;
            if(q==p)record.breadClaimed=true;
            else if(!record.breadClaimed&&InventoryGrant.give(q,new ItemStack(Items.BREAD,16))){record.breadClaimed=true;notify(q,"message.false_traveler.party_bread_received");}
            else if(!record.breadClaimed)notify(q,"message.false_traveler.inventory_full");
        }
        d.stage=Stage.DEFENSE;d.defenseKills=0;d.defenseParticipants.clear();
        d.setDirty();notify(p,"message.false_traveler.log_reward");tellAll(p.server,"message.false_traveler.missions_unlocked");
        missionsCompleted(p.server);
    }
    public static void onShadowKilled(ShadowEntity shadow){EncounterManager.onShadowKilled(shadow);}
    public static boolean missionsCompleted(MinecraftServer server){
        QuestData d=QuestData.get(server);if(d.stage!=Stage.DEFENSE)return false;
        boolean complete=MissionManager.ordinaryCount()==0||d.players.values().stream().anyMatch(record->record.missionIndex>=MissionManager.ordinaryCount());
        if(!complete)return false;
        d.players.values().forEach(record->record.missionIndex=MissionManager.ordinaryCount());
        for(ServerPlayer player:server.getPlayerList().getPlayers())d.player(player.getUUID()).missionIndex=MissionManager.ordinaryCount();
        d.stage=Stage.FRAGMENTS;d.defenseKills=0;d.defenseParticipants.clear();d.setDirty();
        EncounterManager.cleanup(server);Valley.revealShrines(server);tellAll(server,"message.false_traveler.missions_story_complete");return true;
    }
    public static void usePedestal(ServerPlayer p,int shrine){
        if(shrine<0||shrine>=3||!eligible(p)||!Valley.isValley(p.level())||p.distanceToSqr(Vec3.atCenterOf(Valley.SHRINES[shrine]))>25)return;
        QuestData d=QuestData.get(p.server);
        if((d.fragments&(1<<shrine))!=0){notify(p,"message.false_traveler.shrine_completed");return;}
        if(d.stage!=Stage.FRAGMENTS){notify(p,"message.false_traveler.shrine_locked");return;}
        if(!d.shrinesBuilt){notify(p,"message.false_traveler.shrine_appearing");return;}
        if(!EncounterManager.shrineClear(p.server,shrine)){EncounterManager.startShrine(p.server,shrine);notify(p,"message.false_traveler.shrine_fight");return;}
        d.fragments|=1<<shrine;
        if(Integer.bitCount(d.fragments)==2)tellAll(p.server,"dialogue.false_traveler.second_fragment");
        else tellAll(p.server,"message.false_traveler.fragment_found");
        if(d.fragments==7){d.stage=Stage.READY;tellAll(p.server,"message.false_traveler.altar_open");}
        d.setDirty();close(p);
    }
    private static void readiness(ServerPlayer p,String action){
        QuestData d=QuestData.get(p.server);if(d.stage!=Stage.READY||!eligible(p)||!Valley.inArena(p))return;
        if(p.server.getWorldData().getDifficulty()==Difficulty.PEACEFUL){notify(p,"message.false_traveler.peaceful");openAltar(p);return;}
        pruneRegistration(p.server,d);
        switch(action){
            case "register"->{if(d.registered.size()>=ModConfig.MAX_PARTICIPANTS.get()&&!d.registered.contains(p.getUUID()))notify(p,"message.false_traveler.party_full");else {d.registered.add(p.getUUID());d.ready.clear();}}
            case "unregister"->{d.registered.remove(p.getUUID());d.ready.clear();}
            case "ready"->{if(d.registered.contains(p.getUUID()))d.ready.add(p.getUUID());}
            case "refresh"->{}
        }
        if(!d.registered.isEmpty()&&d.ready.containsAll(d.registered)){beginReveal(p.server);return;}
        d.setDirty();openAltar(p);
    }
    private static void pruneRegistration(MinecraftServer s,QuestData d){
        boolean changed=d.registered.removeIf(id->{ServerPlayer p=s.getPlayerList().getPlayer(id);return p==null||!eligible(p)||!Valley.inArena(p);});
        if(changed)d.ready.clear();
    }
    private static void beginReveal(MinecraftServer s){
        QuestData d=QuestData.get(s);pruneRegistration(s,d);if(d.registered.isEmpty()||!d.ready.containsAll(d.registered))return;
        d.participants.clear();d.participants.addAll(d.registered);d.alive.clear();d.alive.addAll(d.participants);d.skipped.clear();
        boolean retry=d.revealed;d.revealed=true;d.stage=Stage.REVEAL;d.encounterId++;d.setDirty();
        revealStarted=s.overworld().getGameTime()-(retry?360:0);revealPage=-1;
        EncounterManager.setBattleBarrier(s,true);
        LukaEntity luka=EncounterManager.ensureLuka(s);if(luka!=null){luka.moveTo(0.5,Valley.ARENA.getY(),0.5,180,0);luka.beginReveal();}
        for(ServerPlayer p:s.getPlayerList().getPlayers())if(Valley.isValley(p.level()))close(p);
        tickReveal(s,d);
    }
    private static void tickReveal(MinecraftServer s,QuestData d){
        long elapsed=s.overworld().getGameTime()-revealStarted;
        if(!d.alive.isEmpty()&&d.skipped.containsAll(d.alive)&&elapsed<360){revealStarted=s.overworld().getGameTime()-360;elapsed=360;}
        if(elapsed>=420){startBattle(s);return;}
        int page=elapsed<360?(int)(elapsed/120):3+(int)((elapsed-360)/20);
        if(page==revealPage)return;int previous=revealPage;revealPage=page;
        if(previous<1&&page>=1){LukaEntity luka=EncounterManager.ensureLuka(s);if(luka!=null)luka.transformForReveal();}
        for(UUID id:d.participants){ServerPlayer p=s.getPlayerList().getPlayer(id);if(p==null)continue;
            String body=page<3?"dialogue.false_traveler.reveal_"+(page+1):"dialogue.false_traveler.countdown";
            open(p,"reveal",page<1?"entity.false_traveler.luka":"entity.false_traveler.luka_boss",body,page<3&&d.alive.contains(id)?List.of("skip"):List.of(),-1,null,String.valueOf(6-page));
        }
    }
    public static void startBattle(MinecraftServer s){
        QuestData d=QuestData.get(s);if(d.stage!=Stage.REVEAL)return;
        d.stage=Stage.BATTLE;d.setDirty();for(ServerPlayer p:s.getPlayerList().getPlayers())if(Valley.isValley(p.level()))close(p);
        for(UUID id:d.participants){ServerPlayer p=s.getPlayerList().getPlayer(id);if(p!=null)giveBattleItems(p);}
        EncounterManager.startBoss(s);tellAll(s,"message.false_traveler.battle_started");
    }
    public static void defeat(ServerPlayer p){
        QuestData d=QuestData.get(p.server);d.alive.remove(p.getUUID());d.ready.remove(p.getUUID());d.setDirty();
        p.stopUsingItem();p.clearFire();p.removeAllEffects();p.setHealth(p.getMaxHealth());p.getFoodData().setFoodLevel(20);p.getFoodData().setSaturation(5);
        p.fallDistance=0;p.invulnerableTime=100;close(p);Valley.safeEntry(p);notify(p,"message.false_traveler.defeated");
    }
    public static void failEncounter(MinecraftServer s){
        QuestData d=QuestData.get(s);if(!d.active())return;
        EncounterManager.cleanup(s);d.stage=Stage.READY;d.participants.clear();d.alive.clear();d.registered.clear();d.ready.clear();d.skipped.clear();d.setDirty();
        for(ServerPlayer p:s.getPlayerList().getPlayers())if(Valley.isValley(p.level())){close(p);Valley.safeEntry(p);p.setHealth(p.getMaxHealth());p.getFoodData().setFoodLevel(20);}
        EncounterManager.ensureLuka(s);tellAll(s,"message.false_traveler.retry");
    }
    public static void bossDefeated(LukaEntity luka){
        MinecraftServer s=luka.getServer();if(s==null)return;QuestData d=QuestData.get(s);if(d.stage!=Stage.BATTLE)return;
        d.stage=Stage.CLEARED;d.rewardShared=false;d.participants.forEach(id->{var record=d.player(id);record.rewardEarned=true;record.victoryEarned=true;});d.alive.clear();d.setDirty();
        ENDING_RECIPIENTS.clear();ENDING_RECIPIENTS.addAll(d.participants);endingAt=s.overworld().getGameTime()+100;
        cleanupAt=s.overworld().getGameTime()+30;
        for(UUID id:d.participants){
            ServerPlayer player=s.getPlayerList().getPlayer(id);if(player==null)continue;
            ensureVictoryItems(player);close(player);if(Valley.isValley(player.level()))Valley.leaveToOverworld(player);
        }
    }
    public static void claim(ServerPlayer p,boolean feedback){
        QuestData d=QuestData.get(p.server);var r=d.player(p.getUUID());boolean granted=false,full=false;
        if(r.journalPending)issueJournal(p);
        if(r.gearEarned&&!r.gearClaimed){if(InventoryGrant.give(p,new ItemStack(FalseTraveler.TRAVELER_SWORD.get()),new ItemStack(FalseTraveler.TRAVELER_HELMET.get()),new ItemStack(FalseTraveler.TRAVELER_CHESTPLATE.get()),new ItemStack(FalseTraveler.TRAVELER_LEGGINGS.get()),new ItemStack(FalseTraveler.TRAVELER_BOOTS.get()))){r.gearClaimed=true;autoEquipGear(p);granted=true;}else full=true;}
        if(r.breadEarned&&!r.breadClaimed){if(InventoryGrant.give(p,new ItemStack(Items.BREAD,16))){r.breadClaimed=true;granted=true;}else full=true;}
        if(feedback&&r.rewardEarned&&!r.rewardClaimed){
            d.rewardShared=true;
            for(ServerPlayer q:p.server.getPlayerList().getPlayers()){
                var other=d.player(q.getUUID());if(!other.rewardEarned||other.rewardClaimed)continue;
                if(InventoryGrant.give(q,new ItemStack(Items.EMERALD,32),new ItemStack(Items.DIAMOND,16),new ItemStack(Items.NETHERITE_INGOT,4),new ItemStack(Items.TOTEM_OF_UNDYING))){other.rewardClaimed=true;if(q==p)granted=true;else notify(q,"message.false_traveler.party_reward_received");}
                else {if(q==p)full=true;else notify(q,"message.false_traveler.inventory_full");}
            }
        }
        d.setDirty();if(granted&&feedback)notify(p,"message.false_traveler.reward_received");
        if(full)notify(p,"message.false_traveler.inventory_full");else if(feedback&&!granted)notify(p,"message.false_traveler.no_rewards");
    }
    private static void ensureGear(ServerPlayer p,boolean feedback){
        QuestData d=QuestData.get(p.server);if(d.stage==Stage.NOT_STARTED)return;var r=d.player(p.getUUID());
        if(!r.gearEarned){r.gearEarned=true;d.setDirty();}
        if(r.gearClaimed){autoEquipGear(p);return;}
        if(InventoryGrant.give(p,new ItemStack(FalseTraveler.TRAVELER_SWORD.get()),new ItemStack(FalseTraveler.TRAVELER_HELMET.get()),new ItemStack(FalseTraveler.TRAVELER_CHESTPLATE.get()),new ItemStack(FalseTraveler.TRAVELER_LEGGINGS.get()),new ItemStack(FalseTraveler.TRAVELER_BOOTS.get()))){
            r.gearClaimed=true;d.setDirty();autoEquipGear(p);if(feedback)notify(p,"message.false_traveler.gear_received");
        }else notify(p,"message.false_traveler.inventory_full");
    }
    private static void ensureBread(ServerPlayer p){
        QuestData d=QuestData.get(p.server);var r=d.player(p.getUUID());if(!r.breadEarned||r.breadClaimed)return;
        if(InventoryGrant.give(p,new ItemStack(Items.BREAD,16))){r.breadClaimed=true;d.setDirty();notify(p,"message.false_traveler.party_bread_received");}
        else notify(p,"message.false_traveler.inventory_full");
    }
    private static void ensureSharedFinal(ServerPlayer p){
        QuestData d=QuestData.get(p.server);var r=d.player(p.getUUID());if(!d.rewardShared||!r.rewardEarned||r.rewardClaimed)return;
        if(InventoryGrant.give(p,new ItemStack(Items.EMERALD,32),new ItemStack(Items.DIAMOND,16),new ItemStack(Items.NETHERITE_INGOT,4),new ItemStack(Items.TOTEM_OF_UNDYING))){r.rewardClaimed=true;d.setDirty();notify(p,"message.false_traveler.party_reward_received");}
        else notify(p,"message.false_traveler.inventory_full");
    }
    private static void ensureVictoryItems(ServerPlayer p){
        QuestData d=QuestData.get(p.server);var r=d.player(p.getUUID());if(!r.victoryEarned||r.victoryClaimed)return;
        giveOrDrop(p,new ItemStack(FalseTraveler.CHARM.get()));
        r.victoryClaimed=true;d.setDirty();notify(p,"message.false_traveler.victory_items_received");
    }
    private static void giveOrDrop(ServerPlayer p,ItemStack... rewards){
        for(ItemStack reward:rewards){ItemStack remaining=reward.copy();p.getInventory().add(remaining);if(!remaining.isEmpty())p.drop(remaining,false);}
        p.getInventory().setChanged();p.containerMenu.broadcastChanges();
    }
    private static void autoEquipGear(ServerPlayer p){
        swapEquipment(p,FalseTraveler.TRAVELER_HELMET.get(),EquipmentSlot.HEAD);
        swapEquipment(p,FalseTraveler.TRAVELER_CHESTPLATE.get(),EquipmentSlot.CHEST);
        swapEquipment(p,FalseTraveler.TRAVELER_LEGGINGS.get(),EquipmentSlot.LEGS);
        swapEquipment(p,FalseTraveler.TRAVELER_BOOTS.get(),EquipmentSlot.FEET);
        swapEquipment(p,FalseTraveler.TRAVELER_SWORD.get(),EquipmentSlot.MAINHAND);
        p.getInventory().setChanged();p.containerMenu.broadcastChanges();
    }
    private static void swapEquipment(ServerPlayer p,Item item,EquipmentSlot slot){
        if(p.getItemBySlot(slot).is(item))return;
        for(int i=0;i<p.getInventory().items.size();i++)if(p.getInventory().items.get(i).is(item)){
            ItemStack replacement=p.getInventory().items.get(i).copy();ItemStack previous=p.getItemBySlot(slot).copy();
            p.setItemSlot(slot,replacement);p.getInventory().items.set(i,previous);return;
        }
    }
    public static void useCharm(ServerPlayer p){
        QuestData d=QuestData.get(p.server);var r=d.player(p.getUUID());long now=p.server.overworld().getGameTime();
        if(now<r.charmReadyAt){p.displayClientMessage(Component.translatable("message.false_traveler.charm_cooldown",(r.charmReadyAt-now+19)/20),true);return;}
        if(p.hasEffect(MobEffects.ABSORPTION)){notify(p,"message.false_traveler.charm_active");return;}
        r.charmReadyAt=now+1200;d.setDirty();p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,200,0));
        p.getCooldowns().addCooldown(FalseTraveler.CHARM.get(),1200);p.playNotifySound(SoundEvents.AMETHYST_BLOCK_CHIME,SoundSource.PLAYERS,0.7F,1.35F);
    }
    public static void tick(MinecraftServer s){
        QuestData d=QuestData.get(s);long now=s.overworld().getGameTime();
        if(cleanupAt>=0&&now>=cleanupAt){cleanupAt=-1;EncounterManager.cleanup(s);}
        if(endingAt>=0&&now>=endingAt){
            endingAt=-1;tellAll(s,"message.false_traveler.ending");JsonObject credits=new JsonObject();credits.addProperty("mode","end_roll");
            for(UUID id:ENDING_RECIPIENTS){ServerPlayer p=s.getPlayerList().getPlayer(id);if(p!=null)Network.send(p,credits);}ENDING_RECIPIENTS.clear();
        }
        if(d.active()){
            boolean removed=d.alive.removeIf(id->{ServerPlayer p=s.getPlayerList().getPlayer(id);return p==null||!eligible(p)||!Valley.inArena(p);});
            if(removed)d.setDirty();
            if(d.alive.isEmpty()){failEncounter(s);return;}
            if(d.stage==Stage.REVEAL)tickReveal(s,d);
        }else if(d.stage==Stage.READY)pruneRegistration(s,d);
        if(d.stage==Stage.DEFENSE&&now%20==0)missionsCompleted(s);
        for(ServerPlayer p:s.getPlayerList().getPlayers()){
            Session session=SESSIONS.get(p.getUUID());if(session!=null&&!valid(p,session))close(p);
            if(now%20==0){sync(p);var r=d.player(p.getUUID());if(r.charmReadyAt>now&&!p.getCooldowns().isOnCooldown(FalseTraveler.CHARM.get()))p.getCooldowns().addCooldown(FalseTraveler.CHARM.get(),(int)Math.min(1200,r.charmReadyAt-now));}
        }
    }
    public static void sync(ServerPlayer p){
        QuestData d=QuestData.get(p.server);JsonObject o=new JsonObject();o.addProperty("mode","hud");o.addProperty("stage",d.stage.ordinal());o.addProperty("fragments",d.fragments);o.addProperty("defenseKills",d.defenseKills);
        o.addProperty("objective",d.stage.objective());o.addProperty("inValley",Valley.isValley(p.level()));
        o.addProperty("groqEnabled",ModConfig.GROQ_ENABLED.get());o.addProperty("groqConfigured",!ModConfig.groqKeys().isEmpty());o.addProperty("missionCount",MissionManager.count());
        MissionManager.addHud(o,p);
        BlockPos target=null;String name="";
        if(d.stage==Stage.FRAGMENTS){int shrine=MissionManager.nearestShrine(d,p);if(shrine>=0){target=Valley.SHRINES[shrine];name="location.false_traveler.shrine_"+(shrine+1);}}
        else if(d.stage==Stage.READY){target=Valley.ALTAR_POS;name="menu.false_traveler.altar";}
        else if(d.stage.ordinal()<Stage.FRAGMENTS.ordinal()){target=Valley.CAMP;name="location.false_traveler.camp";}
        if(target!=null){o.addProperty("targetX",target.getX()+0.5);o.addProperty("targetZ",target.getZ()+0.5);o.addProperty("targetName",name);}
        Network.send(p,o);
    }
    public static void recover(MinecraftServer s){
        QuestData d=QuestData.get(s);if(d.active())failEncounter(s);else EncounterManager.recover(s);
        d.registered.clear();d.ready.clear();d.setDirty();
    }
    public static void serverStarted(MinecraftServer s){
        SESSIONS.clear();LAST_ACTION.clear();cleanupAt=-1;endingAt=-1;ENDING_RECIPIENTS.clear();revealPage=-1;
        if(ModConfig.BOSS_BASE_HEALTH.get()<=480.001){ModConfig.BOSS_BASE_HEALTH.set(1200.0);ModConfig.BOSS_BASE_HEALTH.save();}
        if(ModConfig.BOSS_DAMAGE_MULTIPLIER.get()<=1.001){ModConfig.BOSS_DAMAGE_MULTIPLIER.set(1.75);ModConfig.BOSS_DAMAGE_MULTIPLIER.save();}
        if(ModConfig.MAX_PARTICIPANTS.get()<10){ModConfig.MAX_PARTICIPANTS.set(10);ModConfig.MAX_PARTICIPANTS.save();}
        QuestData d=QuestData.get(s);if(d.valleyBuilt){Valley.ensure(s);recover(s);}else if(d.active()){d.stage=Stage.READY;d.alive.clear();d.participants.clear();d.setDirty();}
    }
    public static void reset(MinecraftServer s){
        QuestData d=QuestData.get(s);EncounterManager.cleanup(s);Valley.hideShrines(s);d.stage=Stage.NOT_STARTED;d.fragments=0;d.defenseKills=0;d.revealed=false;d.rewardShared=false;
        d.participants.clear();d.alive.clear();d.registered.clear();d.ready.clear();d.skipped.clear();d.defenseParticipants.clear();
        d.players.values().forEach(r->{r.breadEarned=false;r.breadClaimed=false;r.ironEarned=false;r.ironClaimed=false;r.rewardEarned=false;r.rewardClaimed=false;r.gearEarned=false;r.gearClaimed=false;r.logBonusEarned=false;r.logBonusClaimed=false;r.victoryEarned=false;r.victoryClaimed=false;r.missionIndex=0;});
        d.encounterId++;d.setDirty();SESSIONS.clear();EncounterManager.reset(s);
    }
    private static void giveBattleItems(ServerPlayer p){
        Item[] items={FalseTraveler.GEOMETRY_SIGIL.get(),FalseTraveler.DAWN_FLASK.get(),FalseTraveler.AEGIS_BELL.get(),FalseTraveler.RIFT_FEATHER.get(),FalseTraveler.BINDING_HOURGLASS.get()};
        boolean full=false;for(Item item:items)if(!p.getInventory().contains(new ItemStack(item))&&!InventoryGrant.give(p,new ItemStack(item)))full=true;
        giveOrDrop(p,new ItemStack(Items.ENCHANTED_GOLDEN_APPLE,6));
        if(full)notify(p,"message.false_traveler.inventory_full");else notify(p,"message.false_traveler.battle_items_received");
    }
    private QuestManager(){}
}
