package jp.false_traveler;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

public final class CombatDamage {
    public static final ResourceKey<DamageType> STRIKE = ResourceKey.create(Registries.DAMAGE_TYPE, FalseTraveler.id("strike"));
    public static final ResourceKey<DamageType> ARROW = ResourceKey.create(Registries.DAMAGE_TYPE, FalseTraveler.id("shadow_arrow"));
    public static final ResourceKey<DamageType> ARCANE = ResourceKey.create(Registries.DAMAGE_TYPE, FalseTraveler.id("arcane"));
    private CombatDamage() {}
    public static DamageSource source(Entity owner, ResourceKey<DamageType> type, Vec3 origin) {
        return new DamageSource(owner.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(type), owner, owner, origin);
    }
    public static float difficulty(Entity entity) { return switch (entity.level().getDifficulty()) { case EASY -> .75f; case HARD -> 1.25f; case PEACEFUL -> 0; default -> 1; }; }
}
