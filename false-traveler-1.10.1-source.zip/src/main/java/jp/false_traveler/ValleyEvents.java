package jp.false_traveler;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.SolidBucketItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.util.TriState;
import net.neoforged.neoforge.event.entity.EntityTeleportEvent;
import net.neoforged.neoforge.event.entity.EntityTravelToDimensionEvent;
import net.neoforged.neoforge.event.entity.living.MobSpawnEvent;
import net.neoforged.neoforge.event.entity.player.BonemealEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.level.ExplosionEvent;

/** Protection applies equally to survival and creative; no per-player game mode changes are needed. */
public final class ValleyEvents {
    private ValleyEvents() {}
    public static void register() {
        NeoForge.EVENT_BUS.addListener(ValleyEvents::breakBlock);
        NeoForge.EVENT_BUS.addListener(ValleyEvents::placeBlock);
        NeoForge.EVENT_BUS.addListener(ValleyEvents::fluidBlock);
        NeoForge.EVENT_BUS.addListener(ValleyEvents::portal);
        NeoForge.EVENT_BUS.addListener(ValleyEvents::tool);
        NeoForge.EVENT_BUS.addListener(ValleyEvents::trample);
        NeoForge.EVENT_BUS.addListener(ValleyEvents::bonemeal);
        NeoForge.EVENT_BUS.addListener(ValleyEvents::rightClickBlock);
        NeoForge.EVENT_BUS.addListener(ValleyEvents::rightClickItem);
        NeoForge.EVENT_BUS.addListener(ValleyEvents::explosion);
        NeoForge.EVENT_BUS.addListener(ValleyEvents::travel);
        NeoForge.EVENT_BUS.addListener(ValleyEvents::teleport);
        NeoForge.EVENT_BUS.addListener(ValleyEvents::naturalSpawn);
    }
    private static boolean protectedLevel(LevelAccessor level) { return level instanceof Level actual && Valley.isValley(actual); }
    private static void breakBlock(BlockEvent.BreakEvent event) { if(protectedLevel(event.getLevel()))event.setCanceled(true); }
    private static void placeBlock(BlockEvent.EntityPlaceEvent event) { if(protectedLevel(event.getLevel()))event.setCanceled(true); }
    private static void fluidBlock(BlockEvent.FluidPlaceBlockEvent event) { if(protectedLevel(event.getLevel()))event.setCanceled(true); }
    private static void portal(BlockEvent.PortalSpawnEvent event) { if(protectedLevel(event.getLevel()))event.setCanceled(true); }
    private static void tool(BlockEvent.BlockToolModificationEvent event) { if(protectedLevel(event.getLevel()))event.setCanceled(true); }
    private static void trample(BlockEvent.FarmlandTrampleEvent event) { if(protectedLevel(event.getLevel()))event.setCanceled(true); }
    private static void bonemeal(BonemealEvent event) { if(Valley.isValley(event.getLevel()))event.setCanceled(true); }
    private static void explosion(ExplosionEvent.Start event) { if(Valley.isValley(event.getLevel()))event.setCanceled(true); }

    private static void rightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if(!Valley.isValley(event.getLevel()))return;
        var state=event.getLevel().getBlockState(event.getPos());
        boolean questBlock=state.is(FalseTraveler.ALTAR.get()) || state.is(FalseTraveler.PEDESTAL.get());
        // Furnishings are scenery; quest blocks retain only their dedicated interactions.
        event.setUseBlock(questBlock?TriState.TRUE:TriState.FALSE);
        event.setUseItem(TriState.FALSE);
    }
    private static void rightClickItem(PlayerInteractEvent.RightClickItem event) {
        if(Valley.isValley(event.getLevel()) && (event.getItemStack().getItem() instanceof BucketItem
                || event.getItemStack().getItem() instanceof SolidBucketItem)) {
            event.setCancellationResult(InteractionResult.FAIL);
            event.setCanceled(true);
        }
    }
    private static void travel(EntityTravelToDimensionEvent event) {
        if((Valley.isValley(event.getEntity().level()) || event.getDimension().equals(Valley.KEY))
                && !Valley.transferAllowed(event.getEntity()))event.setCanceled(true);
    }
    private static void teleport(EntityTeleportEvent event) {
        if(!(event.getEntity() instanceof ServerPlayer player) || !Valley.isValley(player.level()) || Valley.transferAllowed(player))return;
        double x=event.getTargetX()-.5,z=event.getTargetZ()-.5;
        QuestData data=QuestData.get(player.server);
        boolean participant=data.active()&&data.alive.contains(player.getUUID());
        double maximum=participant?20:90;
        if(x*x+z*z>maximum*maximum || event.getTargetY()<64 || event.getTargetY()>108
            || (data.active()&&!participant&&x*x+z*z<23*23))event.setCanceled(true);
    }
    private static void naturalSpawn(MobSpawnEvent.PositionCheck event) {
        if(Valley.isValley(event.getLevel().getLevel()) && (event.getSpawnType()==MobSpawnType.NATURAL
            || event.getSpawnType()==MobSpawnType.CHUNK_GENERATION || event.getSpawnType()==MobSpawnType.PATROL))
            event.setResult(MobSpawnEvent.PositionCheck.Result.FAIL);
    }
}
