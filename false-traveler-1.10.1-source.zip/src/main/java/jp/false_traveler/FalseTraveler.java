package jp.false_traveler;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig.Type;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.RegisterGameTestsEvent;
import net.neoforged.neoforge.registries.*;
import java.util.List;
import java.util.Map;

@Mod(FalseTraveler.MOD_ID)
public final class FalseTraveler {
    public static final String MOD_ID="false_traveler";
    public static ResourceLocation id(String name){return ResourceLocation.fromNamespaceAndPath(MOD_ID,name);}
    public static final DeferredRegister.Items ITEMS=DeferredRegister.createItems(MOD_ID);
    public static final DeferredRegister.Blocks BLOCKS=DeferredRegister.createBlocks(MOD_ID);
    public static final DeferredRegister<ArmorMaterial> ARMOR_MATERIALS=DeferredRegister.create(Registries.ARMOR_MATERIAL,MOD_ID);
    public static final DeferredRegister<EntityType<?>> ENTITIES=DeferredRegister.create(BuiltInRegistries.ENTITY_TYPE,MOD_ID);
    public static final DeferredHolder<EntityType<?>,EntityType<LukaEntity>> LUKA=ENTITIES.register("luka",()->EntityType.Builder.of(LukaEntity::new,MobCategory.CREATURE).sized(0.6F,1.95F).clientTrackingRange(12).build(id("luka").toString()));
    public static final DeferredHolder<EntityType<?>,EntityType<ShadowEntity>> SHADOW=ENTITIES.register("shadow",()->EntityType.Builder.of(ShadowEntity::new,MobCategory.MONSTER).sized(0.6F,1.95F).clientTrackingRange(10).build(id("shadow").toString()));
    public static final DeferredItem<Item> JOURNAL=ITEMS.register("journal",()->new QuestItem(false,new Item.Properties().stacksTo(1)));
    public static final DeferredItem<Item> CHARM=ITEMS.register("dawn_charm",()->new QuestItem(true,new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
    public static final DeferredItem<Item> GEOMETRY_SIGIL=ITEMS.register("geometry_sigil",()->new GeometrySigilItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));
    public static final DeferredItem<Item> DAWN_FLASK=ITEMS.register("dawn_flask",()->new BattleRelicItem(BattleRelicItem.Kind.HEAL,new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));
    public static final DeferredItem<Item> AEGIS_BELL=ITEMS.register("aegis_bell",()->new BattleRelicItem(BattleRelicItem.Kind.BARRIER,new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));
    public static final DeferredItem<Item> RIFT_FEATHER=ITEMS.register("rift_feather",()->new BattleRelicItem(BattleRelicItem.Kind.BLINK,new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));
    public static final DeferredItem<Item> BINDING_HOURGLASS=ITEMS.register("binding_hourglass",()->new BattleRelicItem(BattleRelicItem.Kind.BIND,new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));
    public static final DeferredHolder<ArmorMaterial,ArmorMaterial> TRAVELER_ARMOR=ARMOR_MATERIALS.register("traveler",()->new ArmorMaterial(
        Map.of(ArmorItem.Type.HELMET,3,ArmorItem.Type.CHESTPLATE,8,ArmorItem.Type.LEGGINGS,6,ArmorItem.Type.BOOTS,3,ArmorItem.Type.BODY,8),
        18,SoundEvents.ARMOR_EQUIP_NETHERITE,()->Ingredient.of(Items.DIAMOND),List.of(new ArmorMaterial.Layer(id("traveler"))),3.0F,0.1F));
    public static final DeferredItem<SwordItem> TRAVELER_SWORD=ITEMS.register("traveler_sword",()->new SwordItem(Tiers.DIAMOND,new Item.Properties().rarity(Rarity.EPIC).durability(2048).attributes(SwordItem.createAttributes(Tiers.DIAMOND,6,-2.2F))));
    public static final DeferredItem<ArmorItem> TRAVELER_HELMET=ITEMS.register("traveler_helmet",()->new ArmorItem(TRAVELER_ARMOR,ArmorItem.Type.HELMET,new Item.Properties().rarity(Rarity.RARE).durability(ArmorItem.Type.HELMET.getDurability(37))));
    public static final DeferredItem<ArmorItem> TRAVELER_CHESTPLATE=ITEMS.register("traveler_chestplate",()->new ArmorItem(TRAVELER_ARMOR,ArmorItem.Type.CHESTPLATE,new Item.Properties().rarity(Rarity.RARE).durability(ArmorItem.Type.CHESTPLATE.getDurability(37))));
    public static final DeferredItem<ArmorItem> TRAVELER_LEGGINGS=ITEMS.register("traveler_leggings",()->new ArmorItem(TRAVELER_ARMOR,ArmorItem.Type.LEGGINGS,new Item.Properties().rarity(Rarity.RARE).durability(ArmorItem.Type.LEGGINGS.getDurability(37))));
    public static final DeferredItem<ArmorItem> TRAVELER_BOOTS=ITEMS.register("traveler_boots",()->new ArmorItem(TRAVELER_ARMOR,ArmorItem.Type.BOOTS,new Item.Properties().rarity(Rarity.RARE).durability(ArmorItem.Type.BOOTS.getDurability(37))));
    public static final DeferredBlock<Block> ALTAR=BLOCKS.register("altar",()->new QuestBlock(true,BlockBehaviour.Properties.ofFullCopy(Blocks.CHISELED_DEEPSLATE).strength(-1,3600000).lightLevel(s->8)));
    public static final DeferredBlock<Block> PEDESTAL=BLOCKS.register("pedestal",()->new QuestBlock(false,BlockBehaviour.Properties.ofFullCopy(Blocks.CHISELED_STONE_BRICKS).strength(-1,3600000).lightLevel(s->7)));
    public static final DeferredBlock<Block> VALLEY_STONE=BLOCKS.registerSimpleBlock("valley_stone",BlockBehaviour.Properties.ofFullCopy(Blocks.STONE_BRICKS).strength(-1,3600000));
    static { ITEMS.registerSimpleBlockItem(ALTAR);ITEMS.registerSimpleBlockItem(PEDESTAL);ITEMS.registerSimpleBlockItem(VALLEY_STONE); }
    public FalseTraveler(IEventBus bus,ModContainer container){
        ARMOR_MATERIALS.register(bus);ITEMS.register(bus);BLOCKS.register(bus);ENTITIES.register(bus);
        bus.addListener(Network::register);bus.addListener(FalseTraveler::attributes);
        bus.addListener(FalseTraveler::gameTests);
        container.registerConfig(Type.SERVER,ModConfig.SERVER);
        container.registerConfig(Type.CLIENT,ModConfig.CLIENT);
        NeoForge.EVENT_BUS.register(QuestEvents.class);
        ValleyEvents.register();
    }
    private static void attributes(EntityAttributeCreationEvent e){e.put(LUKA.get(),LukaEntity.createAttributes().build());e.put(SHADOW.get(),ShadowEntity.createAttributes().build());}
    private static void gameTests(RegisterGameTestsEvent e){e.register(FalseTravelerGameTests.class);}
}
