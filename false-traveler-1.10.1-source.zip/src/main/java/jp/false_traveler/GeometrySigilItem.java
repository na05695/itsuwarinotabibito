package jp.false_traveler;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Draws one of three visible seals and damages only non-player living entities inside it. */
public final class GeometrySigilItem extends Item {
    private static final double RADIUS=5.0;
    public GeometrySigilItem(Properties properties){super(properties);}

    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand){
        ItemStack stack=player.getItemInHand(hand);
        if(level instanceof ServerLevel server&&player instanceof ServerPlayer user){
            int shape=server.random.nextInt(3);
            draw(server,user,shape);
            int hits=0;
            for(LivingEntity target:server.getEntitiesOfClass(LivingEntity.class,user.getBoundingBox().inflate(6,3,6),e->e.isAlive()&&!(e instanceof Player))){
                double dx=target.getX()-user.getX(),dz=target.getZ()-user.getZ();
                if(inside(shape,dx,dz)&&target.hurt(server.damageSources().playerAttack(user),20.0F))hits++;
            }
            user.getCooldowns().addCooldown(this,15*20);
            user.playNotifySound(SoundEvents.EVOKER_CAST_SPELL,SoundSource.PLAYERS,1.0F,shape==0?1.25F:shape==1?0.9F:1.05F);
            user.displayClientMessage(Component.translatable("message.false_traveler.geometry_used",Component.translatable("shape.false_traveler."+(shape==0?"circle":shape==1?"triangle":"square")),hits),true);
        }
        return InteractionResultHolder.sidedSuccess(stack,level.isClientSide);
    }

    private static boolean inside(int shape,double x,double z){
        if(shape==0)return x*x+z*z<=RADIUS*RADIUS;
        if(shape==2)return Math.abs(x)<=4.5&&Math.abs(z)<=4.5;
        return sameSide(x,z,0,-5,-4.5,3,4.5,3)&&sameSide(x,z,-4.5,3,4.5,3,0,-5)&&sameSide(x,z,4.5,3,0,-5,-4.5,3);
    }
    private static boolean sameSide(double px,double pz,double ax,double az,double bx,double bz,double ox,double oz){
        double point=(bx-ax)*(pz-az)-(bz-az)*(px-ax);
        double opposite=(bx-ax)*(oz-az)-(bz-az)*(ox-ax);
        return point==0||Math.signum(point)==Math.signum(opposite);
    }
    private static void draw(ServerLevel level,ServerPlayer player,int shape){
        double y=player.getY()+0.15;
        if(shape==0){
            for(int i=0;i<72;i++){double a=Math.PI*2*i/72;particle(level,player.getX()+Math.cos(a)*RADIUS,y,player.getZ()+Math.sin(a)*RADIUS);}
        }else if(shape==1){
            line(level,player,y,0,-5,-4.5,3);line(level,player,y,-4.5,3,4.5,3);line(level,player,y,4.5,3,0,-5);
        }else{
            line(level,player,y,-4.5,-4.5,4.5,-4.5);line(level,player,y,4.5,-4.5,4.5,4.5);
            line(level,player,y,4.5,4.5,-4.5,4.5);line(level,player,y,-4.5,4.5,-4.5,-4.5);
        }
    }
    private static void line(ServerLevel level,ServerPlayer player,double y,double ax,double az,double bx,double bz){
        for(int i=0;i<=24;i++){double t=i/24.0;particle(level,player.getX()+ax+(bx-ax)*t,y,player.getZ()+az+(bz-az)*t);}
    }
    private static void particle(ServerLevel level,double x,double y,double z){
        level.sendParticles(ParticleTypes.END_ROD,x,y,z,1,0.01,0.04,0.01,0.0);
        level.sendParticles(ParticleTypes.WITCH,x,y+0.55,z,1,0.02,0.05,0.02,0.0);
    }
}
