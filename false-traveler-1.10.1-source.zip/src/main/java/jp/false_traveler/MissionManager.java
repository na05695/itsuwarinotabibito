package jp.false_traveler;

import com.google.gson.JsonObject;
import java.util.List;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Configurable mission route. Its last three entries are always the west, east and north shrines. */
public final class MissionManager {
    public record Mission(String name,Item item,int count){}
    private static final int SHRINE_COUNT=3;
    private static final List<Mission> MISSIONS=List.of(
        new Mission("建築用の板材",Items.OAK_PLANKS,32),
        new Mission("石材の調達",Items.COBBLESTONE,32),
        new Mission("明かりの準備",Items.TORCH,16),
        new Mission("食料のリンゴ",Items.APPLE,4),
        new Mission("小麦の収穫",Items.WHEAT,16),
        new Mission("保存食のパン",Items.BREAD,8),
        new Mission("燃料の木炭",Items.CHARCOAL,8),
        new Mission("石レンガの加工",Items.STONE_BRICKS,16),
        new Mission("革の調達",Items.LEATHER,8),
        new Mission("矢羽の準備",Items.FEATHER,12),
        new Mission("石炭の採掘",Items.COAL,16),
        new Mission("鉄鉱石の採掘",Items.RAW_IRON,12),
        new Mission("鉄インゴットの精錬",Items.IRON_INGOT,8),
        new Mission("盾の製作",Items.SHIELD,1),
        new Mission("鉄のつるはしの製作",Items.IRON_PICKAXE,1),
        new Mission("鉄の剣の製作",Items.IRON_SWORD,1),
        new Mission("バケツの製作",Items.BUCKET,1),
        new Mission("コンパスの製作",Items.COMPASS,1),
        new Mission("時計の製作",Items.CLOCK,1),
        new Mission("鎖の製作",Items.CHAIN,4),
        new Mission("紙の製作",Items.PAPER,16),
        new Mission("本の製作",Items.BOOK,8),
        new Mission("ガラスの精錬",Items.GLASS,16),
        new Mission("魂のランタンの製作",Items.SOUL_LANTERN,4),
        new Mission("地図の製作",Items.MAP,1),
        new Mission("望遠鏡の製作",Items.SPYGLASS,1),
        new Mission("アメジストの採取",Items.AMETHYST_SHARD,12)
    );
    private static final String[] SHRINE_NAMES={"西の祠の欠片","東の祠の欠片","北の祠の欠片"};
    private static final String[] SHRINE_DIRECTIONS={"野営地から西へ進む","野営地から東へ進む","野営地から北へ進む"};

    public static int minimum(){return SHRINE_COUNT;}
    public static int maximum(){return MISSIONS.size()+SHRINE_COUNT;}
    /** Total configured missions, including the final three shrines. */
    public static int count(){return Math.max(minimum(),Math.min(maximum(),ModConfig.MISSION_COUNT.get()));}
    public static int ordinaryCount(){return count()-SHRINE_COUNT;}
    public static int nextShrine(QuestData data){for(int i=0;i<SHRINE_COUNT;i++)if((data.fragments&(1<<i))==0)return i;return -1;}
    public static int nearestShrine(QuestData data,ServerPlayer player){
        int best=-1;double distance=Double.MAX_VALUE;
        for(int i=0;i<SHRINE_COUNT;i++)if((data.fragments&(1<<i))==0){double candidate=player.distanceToSqr(Vec3.atCenterOf(Valley.SHRINES[i]));if(candidate<distance){distance=candidate;best=i;}}
        return best;
    }
    public static int progress(QuestData data,ServerPlayer player){
        if(data.stage.ordinal()>=Stage.READY.ordinal())return count();
        int ordinary=Math.max(0,Math.min(ordinaryCount(),data.player(player.getUUID()).missionIndex));
        return ordinary+Integer.bitCount(data.fragments&7);
    }

    public static void open(ServerPlayer player){
        QuestData data=QuestData.get(player.server);
        if(data.stage.ordinal()<Stage.DEFENSE.ordinal()){
            QuestManager.openLiteral(player,"journal","menu.false_traveler.missions","最初に物語の依頼「オークの原木16個」を完了してください。その後、設定された総ミッションが始まります。",List.of("back"),-1);
            return;
        }
        if(data.stage.ordinal()>=Stage.FRAGMENTS.ordinal()&&data.player(player.getUUID()).missionIndex<ordinaryCount()){
            data.player(player.getUUID()).missionIndex=ordinaryCount();data.setDirty();
        }
        if(data.stage==Stage.FRAGMENTS){
            int shrine=nearestShrine(data,player);
            if(shrine>=0){
                int number=ordinaryCount()+Integer.bitCount(data.fragments&7)+1;
                String body="ミッション "+number+" / "+count()+"\n"+SHRINE_NAMES[shrine]+"\n"+SHRINE_DIRECTIONS[shrine]+"。番人を倒し、台座をもう一度調べて欠片を回収する。\n報酬: 最後の3つを集めると中央祭壇が開く";
                QuestManager.openLiteral(player,"journal","menu.false_traveler.missions",body,List.of("mission_ai","back"),-1);
                return;
            }
        }
        if(data.stage.ordinal()>=Stage.READY.ordinal()){
            QuestManager.openLiteral(player,"journal","menu.false_traveler.missions","設定された全"+count()+"ミッション（最後の祠3件を含む）を達成しました。",List.of("back"),-1);
            return;
        }
        int index=Math.max(0,Math.min(ordinaryCount(),data.player(player.getUUID()).missionIndex));
        if(index>=ordinaryCount()){
            QuestManager.missionsCompleted(player.server);open(player);return;
        }
        Mission mission=MISSIONS.get(index);int held=player.getInventory().countItem(mission.item());int emeralds=reward(index);
        String body="ミッション "+(index+1)+" / "+count()+"\n"+mission.name()+"\n必要: "+mission.count()+"個　所持: "+held+"個\n報酬: エメラルド "+emeralds+"個 + 経験値 "+xp(index);
        QuestManager.openLiteral(player,"journal","menu.false_traveler.missions",body,List.of("mission_submit","mission_ai","back"),-1);
    }

    public static void submit(ServerPlayer player){
        QuestData data=QuestData.get(player.server);QuestData.PlayerRecord record=data.player(player.getUUID());
        if(data.stage!=Stage.DEFENSE){open(player);return;}
        int index=Math.max(0,Math.min(ordinaryCount(),record.missionIndex));if(index>=ordinaryCount()){QuestManager.missionsCompleted(player.server);open(player);return;}
        Mission mission=MISSIONS.get(index);
        if(player.getInventory().countItem(mission.item())<mission.count()){
            QuestManager.notify(player,"message.false_traveler.mission_missing");open(player);return;
        }
        if(!InventoryGrant.exchange(player,mission.item(),mission.count(),new ItemStack(Items.EMERALD,reward(index)))){
            QuestManager.notify(player,"message.false_traveler.inventory_full");open(player);return;
        }
        player.giveExperiencePoints(xp(index));record.missionIndex=index+1;data.setDirty();
        if(index+1==ordinaryCount())player.displayClientMessage(net.minecraft.network.chat.Component.translatable("message.false_traveler.ordinary_missions_complete",ordinaryCount()),false);
        else QuestManager.notify(player,"message.false_traveler.mission_complete");
        QuestManager.missionsCompleted(player.server);open(player);
    }

    public static int skip(ServerPlayer player,boolean all){
        QuestData data=QuestData.get(player.server);QuestData.PlayerRecord record=data.player(player.getUUID());
        if(data.stage!=Stage.DEFENSE&&data.stage!=Stage.FRAGMENTS)return 0;
        int before=progress(data,player);
        if(all){
            record.missionIndex=ordinaryCount();data.players.values().forEach(r->r.missionIndex=ordinaryCount());
            data.fragments=7;data.stage=Stage.READY;data.setDirty();
            QuestManager.notify(player,"message.false_traveler.altar_open");
            return count()-before;
        }
        if(data.stage==Stage.DEFENSE){
            record.missionIndex=Math.min(ordinaryCount(),record.missionIndex+1);data.setDirty();QuestManager.missionsCompleted(player.server);
        }else{
            int shrine=nearestShrine(data,player);if(shrine<0)return 0;
            data.fragments|=1<<shrine;
            if(data.fragments==7){data.stage=Stage.READY;QuestManager.notify(player,"message.false_traveler.altar_open");}
            data.setDirty();
        }
        return progress(data,player)-before;
    }

    public static String aiContext(ServerPlayer player){
        QuestData data=QuestData.get(player.server);
        if(data.stage.ordinal()<Stage.DEFENSE.ordinal())return "現在は最初の物語依頼。必要品=オークの原木16個。設定ミッションはまだ開始前";
        if(data.stage==Stage.FRAGMENTS){
            int shrine=nearestShrine(data,player);return shrine<0?"全"+count()+"ミッション達成済み":"ミッション"+(progress(data,player)+1)+"/"+count()+"、内容="+SHRINE_NAMES[shrine]+"、現在地から最も近い未達成の祠。番人を倒した後に台座を再度調べる";
        }
        if(data.stage.ordinal()>=Stage.READY.ordinal())return "全"+count()+"ミッション（祠3件を含む）達成済み";
        int total=count();int ordinary=ordinaryCount();int index=Math.max(0,Math.min(ordinary,data.player(player.getUUID()).missionIndex));
        if(index>=ordinary)return "通常納品は完了。未達成の祠は好きな順番で回収でき、案内は現在地から最も近い祠を示す";
        Mission mission=MISSIONS.get(index);int held=player.getInventory().countItem(mission.item());
        return "ミッション"+(index+1)+"/"+total+"、内容="+mission.name()+"、必要品="+mission.item().getDescription().getString()+" "+mission.count()+"個、現在の所持数="+held+"個";
    }
    public static void addHud(JsonObject hud,ServerPlayer player){
        QuestData data=QuestData.get(player.server);
        if(data.stage==Stage.DEFENSE){
            int index=Math.max(0,Math.min(ordinaryCount(),data.player(player.getUUID()).missionIndex));
            if(index<ordinaryCount()){
                Mission mission=MISSIONS.get(index);hud.addProperty("missionType","supply");hud.addProperty("missionNumber",index+1);hud.addProperty("missionTotal",count());
                hud.addProperty("missionItem",mission.item().getDescriptionId());hud.addProperty("missionRequired",mission.count());hud.addProperty("missionHeld",player.getInventory().countItem(mission.item()));
            }
        }else if(data.stage==Stage.FRAGMENTS){
            int shrine=nearestShrine(data,player);if(shrine>=0){hud.addProperty("missionType","shrine");hud.addProperty("missionNumber",progress(data,player)+1);hud.addProperty("missionTotal",count());hud.addProperty("missionShrine","location.false_traveler.shrine_"+(shrine+1));}
        }
    }
    private static int reward(int index){return 1+index/10;}
    private static int xp(int index){return 8+(index/5)*3;}
    private MissionManager(){}
}
