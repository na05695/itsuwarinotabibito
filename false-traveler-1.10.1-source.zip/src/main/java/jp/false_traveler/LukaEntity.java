package jp.false_traveler;

import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** A single actor switches from reliable ally to an explicitly telegraphed boss. */
public class LukaEntity extends PathfinderMob {
    private static final EntityDataAccessor<Boolean> HOSTILE = SynchedEntityData.defineId(LukaEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> PHASE = SynchedEntityData.defineId(LukaEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> ATTACK = SynchedEntityData.defineId(LukaEntity.class, EntityDataSerializers.INT);
    private final ServerBossEvent bossBar = new ServerBossEvent(Component.translatable("entity.false_traveler.false_guide"), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);
    private final long[] nextAttack = new long[7];
    private final List<ShadowBolt> bolts = new ArrayList<>();
    private int castRemaining;
    private int transformationTicks;
    private long recoverUntil, targetLockedUntil,nextTeleport;
    private Vec3 castCenter = Vec3.ZERO;
    private Vec3 castFacing = new Vec3(0, 0, 1);
    private float damageMultiplier = 1;
    private boolean deathReported;

    public LukaEntity(EntityType<? extends LukaEntity> type, Level level) {
        super(type, level); setPersistenceRequired(); xpReward = 0; setCustomNameVisible(true);
        setCustomName(Component.translatable("entity.false_traveler.luka"));
    }
    public static AttributeSupplier.Builder createAttributes() {
        return createMobAttributes().add(Attributes.MAX_HEALTH, 40).add(Attributes.ATTACK_DAMAGE, 4).add(Attributes.ARMOR,0).add(Attributes.ARMOR_TOUGHNESS,0)
            .add(Attributes.MOVEMENT_SPEED, .3).add(Attributes.FOLLOW_RANGE, 48).add(Attributes.KNOCKBACK_RESISTANCE, .9);
    }
    @Override protected void registerGoals() { goalSelector.addGoal(0, new FloatGoal(this)); }
    @Override protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder); builder.define(HOSTILE, false); builder.define(PHASE, 1); builder.define(ATTACK, 0);
    }
    public boolean isHostile() { return entityData.get(HOSTILE); }
    public int getPhase() { return entityData.get(PHASE); }
    public int getAttackKind() { return entityData.get(ATTACK); }
    public boolean isTransforming() { return getAttackKind() == 6; }
    public void setHostile(boolean hostile) {
        boolean changed=isHostile()!=hostile;
        entityData.set(HOSTILE, hostile);
        if(changed)refreshDimensions();
        setCustomName(Component.translatable(hostile ? "entity.false_traveler.false_guide" : "entity.false_traveler.luka"));
        if (!hostile) bossBar.removeAllPlayers();
    }
    @Override public void onSyncedDataUpdated(EntityDataAccessor<?> key){super.onSyncedDataUpdated(key);if(HOSTILE.equals(key))refreshDimensions();}
    @Override protected EntityDimensions getDefaultDimensions(Pose pose){return isHostile()?super.getDefaultDimensions(pose).scale(1.4F):super.getDefaultDimensions(pose);}
    public void beginReveal() { clearCombat(); setHostile(false); }
    public void transformForReveal(){
        clearCombat();setHostile(true);transformationTicks=80;entityData.set(ATTACK,6);tell("transform");
        if(level() instanceof ServerLevel level){
            level.sendParticles(ParticleTypes.PORTAL,getX(),getY()+1.2,getZ(),220,1.4,1.8,1.4,.45);
            level.sendParticles(ParticleTypes.END_ROD,getX(),getY()+1.2,getZ(),140,1.0,1.5,1.0,.2);
            level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,getX(),getY()+1,getZ(),90,.9,1.2,.9,.12);
            level.playSound(null,blockPosition(),SoundEvents.WARDEN_SONIC_BOOM,SoundSource.HOSTILE,1.2F,.65F);
        }
    }
    public void beginBattle(int players, double baseHealth, double multiplier) {
        clearCombat(); setHostile(true); entityData.set(PHASE, 1); deathReported = false;
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(CombatRules.health(baseHealth, players)); setHealth(getMaxHealth());
        getAttribute(Attributes.ARMOR).setBaseValue(18+players*3);getAttribute(Attributes.ARMOR_TOUGHNESS).setBaseValue(10);
        damageMultiplier = (float)(multiplier*CombatRules.damageScale(players)) * CombatDamage.difficulty(this);
        recoverUntil = level().getGameTime();nextTeleport=recoverUntil+180;
        for (int i = 0; i < nextAttack.length; i++) nextAttack[i] = level().getGameTime();
        bossBar.setProgress(1); bossBar.setVisible(true);
    }
    public void stagger(int ticks){entityData.set(ATTACK,0);castRemaining=0;recoverUntil=Math.max(recoverUntil,level().getGameTime()+ticks);getNavigation().stop();}
    public void clearCombat() { bolts.clear(); entityData.set(ATTACK, 0); castRemaining = 0; transformationTicks=0;setTarget(null); getNavigation().stop(); bossBar.removeAllPlayers(); }
    public void resetFriendly() {
        clearCombat(); setHostile(false); entityData.set(PHASE, 1); getAttribute(Attributes.MAX_HEALTH).setBaseValue(40);getAttribute(Attributes.ARMOR).setBaseValue(0);getAttribute(Attributes.ARMOR_TOUGHNESS).setBaseValue(0); setHealth(40); clearFire(); removeAllEffects();
    }
    @Override public boolean removeWhenFarAway(double distance) { return false; }
    @Override public boolean canBeLeashed() { return false; }
    @Override public boolean isPushable() { return isHostile(); }
    @Override protected void dropAllDeathLoot(ServerLevel level, DamageSource source) {}
    @Override protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (player instanceof ServerPlayer serverPlayer && player.distanceToSqr(this) <= 16) QuestManager.openLuka(serverPlayer, this);
        return InteractionResult.sidedSuccess(level().isClientSide);
    }
    @Override public boolean hurt(DamageSource source, float amount) {
        if (level().isClientSide || !isHostile() || isTransforming()) return false;
        QuestData quest = QuestData.get(level().getServer());
        if (quest.stage != Stage.BATTLE || !(source.getEntity() instanceof ServerPlayer player) || !EncounterManager.isLiveParticipant(player)) return false;
        boolean hit = super.hurt(source, amount);
        if (hit && isAlive()) {
            int phase = CombatRules.phase(getHealth(), getMaxHealth(), getPhase());
            if (phase > getPhase()) {
                int interrupted = getAttackKind();
                if (interrupted > 0 && interrupted < 6) nextAttack[interrupted] = level().getGameTime() + CombatRules.cooldown(interrupted);
                entityData.set(PHASE, phase); bolts.clear(); getNavigation().stop(); entityData.set(ATTACK, 6); castRemaining = 40;
                tell("transform");
            }
        }
        return hit;
    }
    @Override public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide && isHostile() && !deathReported) {
            deathReported = true; clearCombat();
            ((ServerLevel)level()).sendParticles(ParticleTypes.END_ROD, getX(), getY() + 1, getZ(), 80, .7, 1, .7, .12);
            QuestManager.bossDefeated(this);
        }
    }
    @Override public void remove(Entity.RemovalReason reason) { bossBar.removeAllPlayers(); super.remove(reason); }
    @Override public void tick() {
        super.tick();
        if (!(level() instanceof ServerLevel serverLevel) || !isAlive()) return;
        QuestData quest = QuestData.get(serverLevel.getServer());
        if (!isHostile()) { tickAlly(serverLevel, quest); return; }
        // Track a real player during casting and reveal as well as while moving.
        Player facingPlayer = getTarget() instanceof Player p ? p : serverLevel.getNearestPlayer(this, 48);
        if (facingPlayer != null) getLookControl().setLookAt(facingPlayer, 45, 40);
        if(transformationTicks>0){
            if(tickCount%2==0){serverLevel.sendParticles(ParticleTypes.PORTAL,getX(),getY()+1.2,getZ(),32,1.1,1.5,1.1,.22);serverLevel.sendParticles(ParticleTypes.END_ROD,getX(),getY()+1,getZ(),18,.8,1.2,.8,.1);}
            if(--transformationTicks==0)entityData.set(ATTACK,0);
            if(quest.stage!=Stage.BATTLE)return;
        }
        if (quest.stage != Stage.BATTLE) { getNavigation().stop(); return; }
        bossBar.setProgress(Math.max(0, Math.min(1, getHealth() / getMaxHealth())));
        if (tickCount % 20 == 0) {
            for (ServerPlayer old : List.copyOf(bossBar.getPlayers())) if (old.level() != level()) bossBar.removePlayer(old);
            for (ServerPlayer player : serverLevel.players()) bossBar.addPlayer(player);
            selectTarget();
        }
        tickBolts(serverLevel);
        if (getAttackKind() != 0) {
            getNavigation().stop(); setDeltaMovement(getDeltaMovement().multiply(0, 1, 0));
            drawTelegraph(serverLevel);
            if (--castRemaining <= 0) finishAttack(serverLevel);
            return;
        }
        if (!(getTarget() instanceof ServerPlayer target) || !EncounterManager.isLiveParticipant(target)) { selectTarget(); return; }
        getLookControl().setLookAt(target, 30, 30);
        long now = level().getGameTime();
        if (now < recoverUntil) { getNavigation().stop(); return; }
        if(now>=nextTeleport){teleportClash(serverLevel,target);nextTeleport=now+200;recoverUntil=now+12;return;}
        int action = chooseAttack(now, target);
        if (action != 0) beginAttack(action, target);
        else if (distanceToSqr(target) > 2.3 * 2.3) getNavigation().moveTo(target, 1.0);
        else getNavigation().stop();
    }
    private void selectTarget() {
        long now = level().getGameTime();
        if (getTarget() instanceof ServerPlayer current && EncounterManager.isLiveParticipant(current) && now < targetLockedUntil) return;
        ServerPlayer nearest = EncounterManager.liveParticipants((ServerLevel)level()).stream()
            .min(Comparator.comparingDouble((ServerPlayer p) -> p.distanceToSqr(this)).thenComparing(p -> p.getUUID().toString())).orElse(null);
        if (getTarget() != nearest) { setTarget(nearest); targetLockedUntil = now + 60; }
    }
    private int chooseAttack(long now, ServerPlayer target) {
        if (getPhase() >= 3 && now >= nextAttack[5]) return 5;
        if (getPhase() >= 2 && now >= nextAttack[4] && EncounterManager.bossMinionCount(level().getServer()) <= 2) return 4;
        if (getPhase() >= 2 && now >= nextAttack[3]) return 3;
        if (now >= nextAttack[2] && distanceToSqr(target) > 2.5 * 2.5) return 2;
        if (now >= nextAttack[1] && distanceToSqr(target) <= 3 * 3) return 1;
        if (now >= nextAttack[2]) return 2;
        return 0;
    }
    private void beginAttack(int action, ServerPlayer target) {
        entityData.set(ATTACK, action); castRemaining = CombatRules.windup(action); getNavigation().stop();
        castCenter = action == 3 ? target.position() : position();
        Vec3 difference = target.position().subtract(position()).multiply(1, 0, 1);
        castFacing = difference.lengthSqr() < .001 ? new Vec3(0, 0, 1) : difference.normalize();
        float yaw = (float)(Math.atan2(-castFacing.x, castFacing.z) * 180 / Math.PI); setYRot(yaw); yBodyRot = yaw; yHeadRot = yaw;
        if (action == 1) swing(InteractionHand.MAIN_HAND);
        tell(switch (action) { case 1 -> "sword"; case 2 -> "arrows"; case 3 -> "rune"; case 4 -> "summon"; default -> "shockwave"; });
    }
    private void tell(String action) {
        JsonObject cue = new JsonObject(); cue.addProperty("mode", "cue");
        cue.addProperty("sound", action.equals("transform") ? "transform" : "warning");
        cue.addProperty("body", "combat.false_traveler." + action);
        for (ServerPlayer player : ((ServerLevel)level()).players()) if (player.distanceToSqr(this) <= 64 * 64) Network.send(player, cue);
    }
    private void teleportClash(ServerLevel level,ServerPlayer target){
        if(random.nextBoolean()){teleportInFront(level,target);return;}
        level.sendParticles(ParticleTypes.PORTAL,target.getX(),target.getY()+1,target.getZ(),70,.6,1,.6,.3);
        Vec3 away=target.position().subtract(position()).multiply(1,0,1);if(away.lengthSqr()<.001)away=new Vec3(0,0,1);else away=away.normalize();
        Vec3 destination=position().add(away.scale(2.5));target.teleportTo(destination.x,target.getY(),destination.z);target.setDeltaMovement(Vec3.ZERO);
        level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,target.getX(),target.getY()+1,target.getZ(),60,.6,1,.6,.12);tell("teleport_pull");
    }
    private void teleportInFront(ServerLevel level,ServerPlayer target){
        Vec3 look=target.getLookAngle().multiply(1,0,1);if(look.lengthSqr()<.001)look=new Vec3(0,0,1);else look=look.normalize();
        Vec3 destination=target.position().add(look.scale(2.4));double dx=destination.x-Valley.ARENA.getX()-.5,dz=destination.z-Valley.ARENA.getZ()-.5;
        if(dx*dx+dz*dz>17*17)destination=target.position().subtract(look.scale(2.4));
        level.sendParticles(ParticleTypes.PORTAL,getX(),getY()+1,getZ(),70,.6,1,.6,.3);
        teleportTo(destination.x,target.getY(),destination.z);setDeltaMovement(Vec3.ZERO);
        level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,getX(),getY()+1,getZ(),60,.6,1,.6,.12);
        getLookControl().setLookAt(target,90,90);tell("teleport");
    }
    private void finishAttack(ServerLevel level) {
        int action = getAttackKind();
        if (action == 1) {
            swing(InteractionHand.MAIN_HAND);
            for (ServerPlayer player : EncounterManager.liveParticipants(level)) {
                Vec3 difference = player.position().subtract(castCenter);
                if (Math.abs(difference.y) <= 2 && CombatRules.withinSword(difference.x, difference.z, castFacing.x, castFacing.z))
                    player.hurt(CombatDamage.source(this, CombatDamage.STRIKE, castCenter), 6 * damageMultiplier);
            }
            level.playSound(null, blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.HOSTILE, 1, .8f);
        } else if (action == 2) {
            Vec3 origin = position().add(0, 1.2, 0);
            for (int fan = -1; fan <= 1; fan++) bolts.add(new ShadowBolt(origin, castFacing.yRot((float)Math.toRadians(fan * 12)).scale(.65)));
            level.playSound(null, blockPosition(), SoundEvents.SKELETON_SHOOT, SoundSource.HOSTILE, 1, .8f);
        } else if (action == 3 || action == 5) {
            double radius = action == 3 ? 2.5 : 7;
            for (ServerPlayer player : EncounterManager.liveParticipants(level)) {
                Vec3 difference = player.position().subtract(castCenter);
                if (Math.abs(difference.y) <= 2.5 && CombatRules.withinCircle(difference.x, difference.z, radius))
                    player.hurt(CombatDamage.source(this, CombatDamage.ARCANE, castCenter), (action == 3 ? 8 : 10) * damageMultiplier);
            }
            level.sendParticles(ParticleTypes.SOUL, castCenter.x, castCenter.y + .3, castCenter.z, 65, radius / 2, .3, radius / 2, .04);
            level.playSound(null, blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.HOSTILE, .6f, action == 3 ? 1.4f : .9f);
        } else if (action == 4) EncounterManager.summonBossMinions(level.getServer(), position());
        nextAttack[action] = level.getGameTime() + CombatRules.cooldown(action);
        recoverUntil = level.getGameTime() + CombatRules.recovery(getPhase()); entityData.set(ATTACK, 0);
    }
    private void drawTelegraph(ServerLevel level) {
        if (tickCount % 3 != 0) return;
        int action = getAttackKind();
        if (action == 6 || action == 4) {
            level.sendParticles(action == 6 ? ParticleTypes.END_ROD : ParticleTypes.ENCHANT, getX(), getY() + 1, getZ(), 12, .8, 1, .8, .02); return;
        }
        if (action == 2) {
            for (int fan = -1; fan <= 1; fan++) {
                Vec3 direction = castFacing.yRot((float)Math.toRadians(fan * 12));
                for (int distance = 1; distance <= 5; distance++) particle(level, castCenter.add(direction.scale(distance)).add(0, .1, 0));
            }
            return;
        }
        double radius = action == 1 ? 3 : action == 3 ? 2.5 : 7;
        for (int point = 0; point < 64; point++) {
            double angle = point * Math.PI * 2 / 64, dx = Math.sin(angle) * radius, dz = Math.cos(angle) * radius;
            if (action != 1 || dx * castFacing.x + dz * castFacing.z >= -.01) particle(level, castCenter.add(dx, .08, dz));
        }
        // Cross/radial markings distinguish the fixed rune and shockwave without color.
        for (double step = -radius; step <= radius; step += .5) {
            if (action == 1) particle(level, castCenter.add(castFacing.z * step, .08, -castFacing.x * step));
            else { particle(level, castCenter.add(step, .08, 0)); particle(level, castCenter.add(0, .08, step)); }
        }
    }
    private static void particle(ServerLevel level, Vec3 point) { level.sendParticles(ParticleTypes.END_ROD, point.x, point.y, point.z, 1, 0, 0, 0, 0); }
    private void tickBolts(ServerLevel level) {
        Iterator<ShadowBolt> iterator = bolts.iterator();
        while (iterator.hasNext()) {
            ShadowBolt bolt = iterator.next(); Vec3 start = bolt.position, end = start.add(bolt.velocity);
            HitResult blockHit = level.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
            if (blockHit.getType() != HitResult.Type.MISS) end = blockHit.getLocation();
            ServerPlayer hit = null; double bestDistance = Double.MAX_VALUE;
            for (ServerPlayer player : EncounterManager.liveParticipants(level)) {
                var intersection = player.getBoundingBox().inflate(.2).clip(start, end);
                if (intersection.isPresent() && intersection.get().distanceToSqr(start) < bestDistance) { hit = player; bestDistance = intersection.get().distanceToSqr(start); }
            }
            for (int part = 0; part < 4; part++) {
                Vec3 trail = start.lerp(end, part / 4.0); level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, trail.x, trail.y, trail.z, 1, 0, 0, 0, 0);
            }
            if (hit != null) hit.hurt(CombatDamage.source(this, CombatDamage.ARROW, start), 4 * damageMultiplier);
            bolt.position = end;
            if (hit != null || blockHit.getType() != HitResult.Type.MISS || --bolt.life <= 0) iterator.remove();
        }
    }
    private void tickAlly(ServerLevel level, QuestData quest) {
        // Friendly Luka remains at camp while players complete the configured mission sequence.
        getNavigation().stop();
    }
    @Override public void addAdditionalSaveData(CompoundTag tag) { super.addAdditionalSaveData(tag); tag.putBoolean("Hostile", isHostile()); tag.putInt("Phase", getPhase()); }
    @Override public void readAdditionalSaveData(CompoundTag tag) { super.readAdditionalSaveData(tag); setHostile(tag.getBoolean("Hostile")); entityData.set(PHASE, Math.max(1, Math.min(3, tag.getInt("Phase")))); }
    private static final class ShadowBolt {
        Vec3 position; final Vec3 velocity; int life = 60;
        ShadowBolt(Vec3 position, Vec3 velocity) { this.position = position; this.velocity = velocity; }
    }
}
