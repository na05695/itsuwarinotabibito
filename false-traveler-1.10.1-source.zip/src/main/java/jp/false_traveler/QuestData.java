package jp.false_traveler;

import java.util.*;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** One story per world. All mutations happen on the authoritative server thread. */
public final class QuestData extends SavedData {
    public static final int SCHEMA_VERSION = 4;
    public Stage stage = Stage.NOT_STARTED;
    public int fragments, defenseKills;
    public boolean valleyBuilt, shrinesBuilt, revealed, rewardShared;
    public int valleyBuildVersion;
    public UUID lukaId;
    public long encounterId;
    public final Set<UUID> participants = new LinkedHashSet<>(), alive = new LinkedHashSet<>(),
        registered = new LinkedHashSet<>(), ready = new HashSet<>(), skipped = new HashSet<>(),
        defenseParticipants = new HashSet<>();
    public final Map<UUID, PlayerRecord> players = new HashMap<>();
    public static QuestData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(new Factory<>(QuestData::new, QuestData::load), "false_traveler_quest");
    }
    public boolean active() { return stage.active(); }
    public PlayerRecord player(UUID id) { return players.computeIfAbsent(id, k -> new PlayerRecord()); }
    public static final class PlayerRecord {
        public boolean joined, journalPending, breadEarned, breadClaimed, ironEarned, ironClaimed, rewardEarned, rewardClaimed,
            gearEarned, gearClaimed, logBonusEarned, logBonusClaimed, victoryEarned, victoryClaimed;
        public int missionIndex;
        public long charmReadyAt;
    }
    private static QuestData load(CompoundTag n, HolderLookup.Provider registries) {
        QuestData d = new QuestData();
        try { d.stage = Stage.valueOf(n.getString("stage")); } catch (IllegalArgumentException ignored) { }
        d.fragments = n.getInt("fragments") & 7;
        d.defenseKills = Math.max(0, Math.min(3, n.getInt("defenseKills")));
        d.valleyBuilt = n.getBoolean("valleyBuilt");d.shrinesBuilt=n.getBoolean("shrinesBuilt");d.valleyBuildVersion=n.getInt("valleyBuildVersion");d.revealed = n.getBoolean("revealed");
        d.rewardShared=n.getBoolean("rewardShared");
        if (n.hasUUID("luka")) d.lukaId = n.getUUID("luka");
        d.encounterId = n.getLong("encounterId");
        readIds(n,"participants",d.participants); readIds(n,"alive",d.alive);
        readIds(n,"defenseParticipants",d.defenseParticipants);
        ListTag list = n.getList("players", Tag.TAG_COMPOUND);
        for (Tag t : list) {
            CompoundTag p=(CompoundTag)t; if (!p.hasUUID("id")) continue;
            PlayerRecord r = d.player(p.getUUID("id"));
            r.joined=p.getBoolean("joined"); r.journalPending=p.getBoolean("journalPending");
            r.breadEarned=p.getBoolean("breadEarned"); r.breadClaimed=p.getBoolean("breadClaimed");
            r.ironEarned=p.getBoolean("ironEarned"); r.ironClaimed=p.getBoolean("ironClaimed");
            r.rewardEarned=p.getBoolean("rewardEarned"); r.rewardClaimed=p.getBoolean("rewardClaimed");
            r.gearEarned=p.getBoolean("gearEarned"); r.gearClaimed=p.getBoolean("gearClaimed");
            r.logBonusEarned=p.getBoolean("logBonusEarned"); r.logBonusClaimed=p.getBoolean("logBonusClaimed");
            r.victoryEarned=p.getBoolean("victoryEarned");r.victoryClaimed=p.getBoolean("victoryClaimed");
            r.missionIndex=Math.max(0,Math.min(MissionManager.ordinaryCount(),p.getInt("missionIndex")));
            r.charmReadyAt=p.getLong("charmReadyAt");
        }
        return d;
    }
    @Override public CompoundTag save(CompoundTag n, HolderLookup.Provider registries) {
        n.putInt("schemaVersion", SCHEMA_VERSION); n.putString("stage",stage.name());
        n.putInt("fragments",fragments); n.putInt("defenseKills",defenseKills);
        n.putBoolean("valleyBuilt",valleyBuilt);n.putBoolean("shrinesBuilt",shrinesBuilt);n.putInt("valleyBuildVersion",valleyBuildVersion);n.putBoolean("revealed",revealed);
        n.putBoolean("rewardShared",rewardShared);
        if(lukaId!=null)n.putUUID("luka",lukaId);
        n.putLong("encounterId",encounterId);
        writeIds(n,"participants",participants); writeIds(n,"alive",alive); writeIds(n,"defenseParticipants",defenseParticipants);
        ListTag list=new ListTag();
        players.forEach((id,r)->{
            CompoundTag p=new CompoundTag();p.putUUID("id",id);
            p.putBoolean("joined",r.joined);p.putBoolean("journalPending",r.journalPending);
            p.putBoolean("breadEarned",r.breadEarned);p.putBoolean("breadClaimed",r.breadClaimed);
            p.putBoolean("ironEarned",r.ironEarned);p.putBoolean("ironClaimed",r.ironClaimed);
            p.putBoolean("rewardEarned",r.rewardEarned);p.putBoolean("rewardClaimed",r.rewardClaimed);
            p.putBoolean("gearEarned",r.gearEarned);p.putBoolean("gearClaimed",r.gearClaimed);
            p.putBoolean("logBonusEarned",r.logBonusEarned);p.putBoolean("logBonusClaimed",r.logBonusClaimed);
            p.putBoolean("victoryEarned",r.victoryEarned);p.putBoolean("victoryClaimed",r.victoryClaimed);
            p.putInt("missionIndex",r.missionIndex);
            p.putLong("charmReadyAt",r.charmReadyAt);list.add(p);
        });n.put("players",list);return n;
    }
    private static void readIds(CompoundTag n,String key,Set<UUID> out) {
        for(Tag t:n.getList(key,Tag.TAG_INT_ARRAY))try{out.add(NbtUtils.loadUUID(t));}catch(IllegalArgumentException ignored){}
    }
    private static void writeIds(CompoundTag n,String key,Set<UUID> ids) {
        ListTag list=new ListTag();ids.forEach(id->list.add(NbtUtils.createUUID(id)));n.put(key,list);
    }
}
