package jp.false_traveler;

public enum Stage {
    NOT_STARTED, SUPPLIES, DEFENSE, FRAGMENTS, READY, REVEAL, BATTLE, CLEARED;
    public boolean active() { return this == REVEAL || this == BATTLE; }
    public String objective() { return "objective.false_traveler." + name().toLowerCase(java.util.Locale.ROOT); }
}
