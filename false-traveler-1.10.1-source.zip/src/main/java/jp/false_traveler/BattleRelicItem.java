package jp.false_traveler;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Four reusable boss tools; together with the geometry sigil the encounter grants five items. */
public final class BattleRelicItem extends Item {
    public enum Kind { HEAL, BARRIER, BLINK, BIND }
    private final Kind kind;
    public BattleRelicItem(Kind kind,Properties properties){super(properties);this.kind=kind;}

    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand){
        ItemStack stack=player.getItemInHand(hand);
        if(level instanceof ServerLevel server&&player instanceof ServerPlayer user){
            int cooldown=switch(kind){
                case HEAL->{user.heal(12);user.addEffect(new MobEffectInstance(MobEffects.REGENERATION,160,1));server.sendParticles(ParticleTypes.HEART,user.getX(),user.getY()+1,user.getZ(),24,.7,1,.7,.08);yield 500;}
                case BARRIER->{user.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,240,3));user.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,120,1));server.sendParticles(ParticleTypes.ENCHANT,user.getX(),user.getY()+1,user.getZ(),80,1.2,1.2,1.2,.15);yield 700;}
                case BLINK->{
                    Vec3 look=user.getLookAngle().multiply(1,0,1);if(look.lengthSqr()<.001)look=new Vec3(0,0,1);else look=look.normalize();
                    Vec3 destination=user.position().add(look.scale(10));double dx=destination.x-.5,dz=destination.z-.5,dist=Math.hypot(dx,dz);if(dist>17)destination=new Vec3(.5+dx*17/dist,user.getY(),.5+dz*17/dist);
                    server.sendParticles(ParticleTypes.PORTAL,user.getX(),user.getY()+1,user.getZ(),45,.4,.8,.4,.2);user.teleportTo(destination.x,user.getY(),destination.z);server.sendParticles(ParticleTypes.END_ROD,user.getX(),user.getY()+1,user.getZ(),35,.4,.8,.4,.08);yield 240;
                }
                case BIND->{
                    LukaEntity boss=server.getEntitiesOfClass(LukaEntity.class,user.getBoundingBox().inflate(14),LukaEntity::isHostile).stream().findFirst().orElse(null);
                    if(boss==null){user.displayClientMessage(Component.translatable("message.false_traveler.relic_no_target"),true);yield 20;}
                    boss.stagger(80);boss.hurt(server.damageSources().playerAttack(user),30);server.sendParticles(ParticleTypes.REVERSE_PORTAL,boss.getX(),boss.getY()+1,boss.getZ(),100,1.5,1.5,1.5,.2);yield 800;
                }
            };
            user.getCooldowns().addCooldown(this,cooldown);user.playNotifySound(SoundEvents.AMETHYST_BLOCK_RESONATE,SoundSource.PLAYERS,1,1.1F);
            user.displayClientMessage(Component.translatable("message.false_traveler.relic_used",Component.translatable("item.false_traveler."+switch(kind){case HEAL->"dawn_flask";case BARRIER->"aegis_bell";case BLINK->"rift_feather";case BIND->"binding_hourglass";})),true);
        }
        return InteractionResultHolder.sidedSuccess(stack,level.isClientSide);
    }
}
