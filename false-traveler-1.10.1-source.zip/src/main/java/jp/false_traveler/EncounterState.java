package jp.false_traveler;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Persistent wave identities prevent unrelated or restarted waves from advancing quests. */
public final class EncounterState extends SavedData {
    long nextId = 1;
    long defenseId;
    boolean defenseHealUsed;
    final long[] shrineIds = new long[3];
    final int[] shrineKills = new int[3];
    int shrineCleared;
    public static EncounterState get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(new Factory<>(EncounterState::new, EncounterState::load), "false_traveler_encounters");
    }
    private static EncounterState load(CompoundTag tag, HolderLookup.Provider registries) {
        EncounterState state = new EncounterState();
        state.nextId = Math.max(1, tag.getLong("NextId"));
        state.defenseId = tag.getLong("DefenseId");
        state.defenseHealUsed = tag.getBoolean("DefenseHealUsed");
        state.shrineCleared = tag.getInt("ShrineCleared") & 7;
        for (int i = 0; i < 3; i++) { state.shrineIds[i] = tag.getLong("ShrineId" + i); state.shrineKills[i] = tag.getInt("ShrineKills" + i); }
        return state;
    }
    long allocate() { setDirty(); return nextId++; }
    @Override public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putLong("NextId", nextId); tag.putLong("DefenseId", defenseId); tag.putBoolean("DefenseHealUsed", defenseHealUsed); tag.putInt("ShrineCleared", shrineCleared);
        for (int i = 0; i < 3; i++) { tag.putLong("ShrineId" + i, shrineIds[i]); tag.putInt("ShrineKills" + i, shrineKills[i]); }
        return tag;
    }
}
