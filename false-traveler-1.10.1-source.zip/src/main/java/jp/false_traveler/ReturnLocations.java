package jp.false_traveler;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;

/** Personal return coordinates live in world data and survive death, logout and server restart. */
final class ReturnLocations extends SavedData {
    record ReturnPoint(ResourceKey<Level> dimension, double x, double y, double z, float yaw, float pitch) {}
    private final Map<UUID, ReturnPoint> entries = new HashMap<>();
    static ReturnLocations get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(new SavedData.Factory<>(ReturnLocations::new, ReturnLocations::load), "false_traveler_return_locations");
    }
    void remember(ServerPlayer player) {
        entries.put(player.getUUID(), new ReturnPoint(player.level().dimension(), player.getX(), player.getY(), player.getZ(), player.getYRot(), player.getXRot()));
        setDirty();
    }
    ReturnPoint find(UUID player) { return entries.get(player); }
    private static ReturnLocations load(CompoundTag tag, HolderLookup.Provider registries) {
        ReturnLocations result = new ReturnLocations();
        ListTag entries = tag.getList("returns", Tag.TAG_COMPOUND);
        for (int i=0; i<entries.size(); i++) {
            CompoundTag entry = entries.getCompound(i);
            if (!entry.hasUUID("player")) continue;
            ResourceLocation dimension = ResourceLocation.tryParse(entry.getString("dimension"));
            if (dimension == null) continue;
            result.entries.put(entry.getUUID("player"), new ReturnPoint(ResourceKey.create(Registries.DIMENSION, dimension),
                entry.getDouble("x"), entry.getDouble("y"), entry.getDouble("z"), entry.getFloat("yaw"), entry.getFloat("pitch")));
        }
        return result;
    }
    @Override public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag list = new ListTag();
        entries.forEach((uuid, point) -> {
            CompoundTag entry = new CompoundTag();
            entry.putUUID("player",uuid); entry.putString("dimension",point.dimension().location().toString());
            entry.putDouble("x",point.x()); entry.putDouble("y",point.y()); entry.putDouble("z",point.z());
            entry.putFloat("yaw",point.yaw()); entry.putFloat("pitch",point.pitch()); list.add(entry);
        });
        tag.putInt("schemaVersion",1); tag.put("returns",list); return tag;
    }
}
