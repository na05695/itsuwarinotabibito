package jp.false_traveler;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.protocol.game.ClientboundSetTimePacket;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** The adventure is built only in its own void dimension; normal worlds are never edited. */
public final class Valley {
    public static final ResourceKey<Level> KEY = ResourceKey.create(Registries.DIMENSION, FalseTraveler.id("valley"));
    public static final BlockPos ENTRY = new BlockPos(0, 65, 122);
    public static final BlockPos CAMP = new BlockPos(-48, 65, 92);
    public static final BlockPos ARENA = new BlockPos(0, 65, 0);
    public static final BlockPos ALTAR_POS = new BlockPos(0, 65, -18);
    public static final BlockPos[] SHRINES = {
        new BlockPos(-116, 65, -18), new BlockPos(116, 65, -18), new BlockPos(0, 65, -126)
    };
    public static final BlockPos SPECTATOR = new BlockPos(29, 70, 0);
    private static final int RADIUS = 150, BUILD_VERSION=5;
    private static final Set<UUID> TRANSFERRING = new HashSet<>();
    private static ServerLevel initializedLevel;
    private static long shrineRevealStartedAt=-1,shrineRevealAt=-1,nextValleyChatAt=-1;
    private static int shrineRevealStep=-1,valleyChatIndex;

    private Valley() {}

    public static boolean isValley(Level level) { return level.dimension().equals(KEY); }
    public static boolean inside(Entity entity) {
        return isValley(entity.level()) && horizontalDistance(entity.getX(), entity.getZ(), 0.5, 0.5) <= RADIUS * RADIUS
            && entity.getY() >= 59 && entity.getY() <= 108;
    }
    public static boolean inArena(Entity entity) {
        return isValley(entity.level()) && horizontalDistance(entity.getX(), entity.getZ(), 0.5, 0.5) <= 20 * 20
            && entity.getY() >= 64 && entity.getY() <= 71;
    }
    private static double horizontalDistance(double x, double z, double cx, double cz) {
        return (x - cx) * (x - cx) + (z - cz) * (z - cz);
    }
    static boolean transferAllowed(Entity entity) { return TRANSFERRING.contains(entity.getUUID()); }

    public static ServerLevel ensure(MinecraftServer server) {
        ServerLevel level = server.getLevel(KEY);
        if (level == null) throw new IllegalStateException("The false_traveler:valley dimension data is missing");
        QuestData data = QuestData.get(server);
        if (initializedLevel != level) {
            // A small, contiguous loaded area lets recovery find the existing NPC by UUID even after restart.
            for (int x = -6; x <= 5; x++) for (int z = -6; z <= 5; z++) {
                level.setChunkForced(x, z, true);
                level.getChunk(x, z);
            }
            nextValleyChatAt=-1;valleyChatIndex=0;
            shrineRevealStartedAt=-1;shrineRevealAt=-1;shrineRevealStep=-1;
            initializedLevel = level;
        }
        if(!data.valleyBuilt||data.valleyBuildVersion<BUILD_VERSION){
            build(level,data.valleyBuilt);
            data.valleyBuilt = true;
            data.valleyBuildVersion=BUILD_VERSION;
            data.shrinesBuilt=false;
            data.setDirty();
        }
        if(data.stage.ordinal()>=Stage.FRAGMENTS.ordinal()&&!data.shrinesBuilt)revealShrines(server);
        return level;
    }

    public static void enter(ServerPlayer player) {
        if (isValley(player.level())) {
            QuestManager.notify(player, "message.false_traveler.already_valley");
            return;
        }
        ServerLevel valley = ensure(player.server);
        ReturnLocations.get(player.server).remember(player);
        BlockPos destination = QuestData.get(player.server).active() ? SPECTATOR : ENTRY;
        move(player, valley, destination.getX() + 0.5, destination.getY(), destination.getZ() + 0.5, 180, 0);
        updateSky(player, QuestData.get(player.server));
        QuestManager.notify(player, destination.equals(SPECTATOR)
            ? "message.false_traveler.spectator" : "message.false_traveler.welcome_valley");
    }

    public static void leave(ServerPlayer player) {
        if (!isValley(player.level())) return;
        QuestData data = QuestData.get(player.server);
        if (data.active() && data.alive.contains(player.getUUID())) {
            QuestManager.notify(player, "message.false_traveler.no_combat_travel");
            return;
        }
        ReturnLocations.ReturnPoint saved = ReturnLocations.get(player.server).find(player.getUUID());
        if (saved != null) {
            ServerLevel target = player.server.getLevel(saved.dimension());
            if (target != null && !isValley(target) && safeReturn(target, saved.x(), saved.y(), saved.z())) {
                move(player, target, saved.x(), saved.y(), saved.z(), saved.yaw(), saved.pitch());
                return;
            }
        }
        // Search existing terrain only: never build a platform or replace a block in somebody's base.
        ServerLevel overworld = player.server.overworld();
        BlockPos spawn = overworld.getSharedSpawnPos();
        BlockPos safe = findSafeSpawn(overworld, spawn);
        if (safe == null) {
            QuestManager.notify(player, "message.false_traveler.return_unavailable");
            return;
        }
        move(player, overworld, safe.getX() + 0.5, safe.getY(), safe.getZ() + 0.5, overworld.getSharedSpawnAngle(), 0);
    }

    /** Boss victories always end in the Overworld, even when the journal was opened elsewhere. */
    public static void leaveToOverworld(ServerPlayer player) {
        if (!isValley(player.level())) return;
        ServerLevel overworld = player.server.overworld();
        ReturnLocations.ReturnPoint saved = ReturnLocations.get(player.server).find(player.getUUID());
        if (saved != null && saved.dimension().equals(Level.OVERWORLD)
            && safeReturn(overworld, saved.x(), saved.y(), saved.z())) {
            move(player, overworld, saved.x(), saved.y(), saved.z(), saved.yaw(), saved.pitch());
            return;
        }
        BlockPos safe = findSafeSpawn(overworld, overworld.getSharedSpawnPos());
        if (safe == null) {
            QuestManager.notify(player, "message.false_traveler.return_unavailable");
            return;
        }
        move(player, overworld, safe.getX() + 0.5, safe.getY(), safe.getZ() + 0.5, overworld.getSharedSpawnAngle(), 0);
    }

    public static void safeEntry(ServerPlayer player) {
        ServerLevel valley = ensure(player.server);
        move(player, valley, ENTRY.getX() + 0.5, ENTRY.getY(), ENTRY.getZ() + 0.5, 180, 0);
    }

    private static void move(ServerPlayer player, ServerLevel level, double x, double y, double z, float yaw, float pitch) {
        TRANSFERRING.add(player.getUUID());
        try {
            player.stopRiding();
            player.teleportTo(level, x, y, z, Set.of(), yaw, pitch);
            player.setDeltaMovement(Vec3.ZERO);
            player.fallDistance = 0;
            player.clearFire();
        } finally { TRANSFERRING.remove(player.getUUID()); }
    }

    private static boolean safeReturn(ServerLevel level, double x, double y, double z) {
        if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z)) return false;
        BlockPos pos = BlockPos.containing(x, y, z);
        if (!level.getWorldBorder().isWithinBounds(pos) || y < level.getMinBuildHeight() + 1 || y > level.getMaxBuildHeight() - 2) return false;
        level.getChunkAt(pos);
        return level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()
            && level.getBlockState(pos.above()).getCollisionShape(level, pos.above()).isEmpty()
            && level.getFluidState(pos).isEmpty() && level.getFluidState(pos.above()).isEmpty()
            && level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP)
            && !level.getBlockState(pos.below()).is(Blocks.MAGMA_BLOCK)
            && !level.getBlockState(pos).is(Blocks.FIRE) && !level.getBlockState(pos).is(Blocks.SOUL_FIRE);
    }

    private static BlockPos findSafeSpawn(ServerLevel level, BlockPos origin) {
        for (int radius = 0; radius <= 64; radius++) {
            for (int dx = -radius; dx <= radius; dx++) for (int dz = -radius; dz <= radius; dz++) {
                if (Math.max(Math.abs(dx), Math.abs(dz)) != radius) continue;
                int x = origin.getX() + dx, z = origin.getZ() + dz;
                if (!level.getWorldBorder().isWithinBounds(new BlockPos(x, 64, z))) continue;
                int y = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
                if (safeReturn(level, x + 0.5, y, z + 0.5)) return new BlockPos(x, y, z);
            }
        }
        // A custom void world may have no safe surface. Keep the player in the valley in that case.
        return null;
    }

    public static void tick(MinecraftServer server) {
        ServerLevel level = server.getLevel(KEY);
        if (level == null) return;
        QuestData data = QuestData.get(server);
        if (data.valleyBuilt && initializedLevel != level) ensure(server);
        tickValleyChat(level,data);
        if(shrineRevealAt>=0){
            long now=level.getGameTime();
            if(now%3==0)for(BlockPos shrine:SHRINES){
                level.sendParticles(ParticleTypes.END_ROD,shrine.getX()+.5,65.4,shrine.getZ()+.5,35,7,.8,7,.03);
                level.sendParticles(ParticleTypes.PORTAL,shrine.getX()+.5,68,shrine.getZ()+.5,45,8,3,8,.12);
            }
            int targetStep=(int)Math.min(5,(now-shrineRevealStartedAt)/20);
            while(shrineRevealStep<targetStep){
                shrineRevealStep++;
                for(int i=0;i<SHRINES.length;i++)revealShrineStep(level,SHRINES[i],i,shrineRevealStep);
            }
            if(now>=shrineRevealAt){
                shrineRevealStartedAt=-1;shrineRevealAt=-1;shrineRevealStep=-1;
                for(int i=0;i<SHRINES.length;i++){shrine(level,SHRINES[i],i);level.sendParticles(ParticleTypes.FLASH,SHRINES[i].getX()+.5,68,SHRINES[i].getZ()+.5,8,5,3,5,0);}
                data.shrinesBuilt=true;data.setDirty();
                for(ServerPlayer player:level.players())QuestManager.notify(player,"message.false_traveler.shrines_appeared");
            }
        }
        for (ServerPlayer player : level.players()) {
            if (data.active() && data.alive.contains(player.getUUID())) {
                double x = player.getX() - .5, z = player.getZ() - .5;
                double distance = Math.sqrt(x*x + z*z);
                if (distance > 19.75 || player.getY() < 64 || player.getY() > 71) {
                    double scale = distance > 19 ? 19 / distance : 1;
                    move(player, level, .5 + x*scale, 65, .5 + z*scale, player.getYRot(), player.getXRot());
                }
            }
            if (!inside(player)) {
                if (data.active() && data.alive.contains(player.getUUID())) {
                    move(player, level, 0.5, 65, 16.5, player.getYRot(), 0);
                } else safeEntry(player);
            }
            if (data.active() && !data.alive.contains(player.getUUID())
                    && horizontalDistance(player.getX(), player.getZ(), 0.5, 0.5) < 23 * 23) {
                move(player, level, SPECTATOR.getX() + 0.5, SPECTATOR.getY(), SPECTATOR.getZ() + 0.5, 180, 15);
            }
            if (server.getTickCount() % 20 == 0) updateSky(player, data);
        }
    }

    private static void updateSky(ServerPlayer player, QuestData data) {
        // Personal time packets give this dimension an evening-to-dawn ending without changing overworld time.
        player.connection.send(new ClientboundSetTimePacket(player.serverLevel().getGameTime(), data.stage == Stage.CLEARED ? 6000 : 13000, false));
    }

    private static void tickValleyChat(ServerLevel level,QuestData data){
        long now=level.getGameTime();
        if(level.players().isEmpty()){nextValleyChatAt=now+600;return;}
        if(data.stage==Stage.CLEARED){nextValleyChatAt=now+600;return;}
        if(nextValleyChatAt<0){nextValleyChatAt=now+600;return;}
        if(now<nextValleyChatAt)return;
        nextValleyChatAt=now+600;
        String key;
        if(data.stage==Stage.BATTLE)key="combat.false_traveler.taunt_"+(valleyChatIndex++%6+1);
        else{
            String phase=switch(data.stage){
                case NOT_STARTED->"welcome";
                case SUPPLIES->"supplies";
                case DEFENSE->"missions";
                case FRAGMENTS->"shrines";
                case READY->"altar";
                case REVEAL->"reveal";
                case CLEARED->"cleared";
                default->"welcome";
            };
            key="chat.false_traveler."+phase+"_"+(valleyChatIndex++%3+1);
        }
        Component line=Component.translatable(key);
        for(ServerPlayer player:level.players())player.sendSystemMessage(line);
    }

    private static void build(ServerLevel level,boolean clearExisting) {
        if(clearExisting)clearBuildArea(level);
        for (int x = -150; x <= 150; x++) for (int z = -150; z <= 150; z++) {
            int ax=Math.abs(x),az=Math.abs(z);
            int edge=Math.min(146-Math.max(ax,az),(190-ax-az)/2);
            if(edge<0)continue;
            put(level, x, 60, z, Blocks.BEDROCK);
            put(level,x,61,z,Blocks.STONE);
            put(level,x,62,z,Blocks.STONE);
            put(level,x,63,z,Blocks.DIRT);
            int streamCenter=(int)Math.round(Math.sin(z*.045)*12);
            boolean stream=Math.abs(x-streamCenter)<=3&&z<106&&z>-111;
            if(stream){
                put(level,x,63,z,Math.floorMod(z,17)==0?Blocks.SEA_LANTERN:Blocks.CLAY);
                put(level,x,64,z,Blocks.WATER);
            }else put(level,x,64,z,Blocks.GRASS_BLOCK);
            if(edge<=10){
                int height=4+(10-edge)+(int)Math.round(2*Math.sin(x*.13)+2*Math.cos(z*.11));
                height=Math.max(3,height);
                for(int y=65;y<=64+height;y++)put(level,x,y,z,y==64+height?Blocks.DIRT:Blocks.STONE);
            }
            if(edge<=1)for(int y=65;y<=112;y++)put(level,x,y,z,Blocks.BARRIER);
        }
        // No shrine or shrine road exists in the opening version of the valley.
        path(level, ENTRY, ARENA, 2);
        path(level,CAMP,new BlockPos(0,65,105),2);
        arena(level);
        camp(level);
        spectator(level);
        arrivalDeck(level);
        steppedSpring(level,new BlockPos(-78,65,52));
        steppedSpring(level,new BlockPos(77,65,63));
        crystalTerrace(level,new BlockPos(-78,65,-73));
        crystalTerrace(level,new BlockPos(82,65,-76));
        int[][] groves={{-103,82},{-83,101},{-72,22},{-96,-42},{-50,-96},{-18,-113},
            {26,-106},{55,-92},{94,-55},{105,21},{94,89},{64,104},{-34,83},{40,76}};
        for(int i=0;i<groves.length;i++)tree(level,groves[i][0],groves[i][1],i%2==0);
        for (int x = -132; x <= 132; x++) for (int z = -132; z <= 132; z++) {
            int hash=x*73428767^z*912931;
            if(Math.floorMod(hash,97)!=0)continue;
            if (level.getBlockState(new BlockPos(x,64,z)).is(Blocks.GRASS_BLOCK)
                && level.getBlockState(new BlockPos(x,65,z)).isAir()) {
                put(level,x,65,z,Math.floorMod(hash,3)==0?Blocks.ALLIUM:Math.floorMod(hash,3)==1?Blocks.CORNFLOWER:Blocks.SHORT_GRASS);
            }
        }
        put(level, ALTAR_POS, FalseTraveler.ALTAR.get().defaultBlockState());
    }

    public static void revealShrines(MinecraftServer server){
        QuestData data=QuestData.get(server);ServerLevel level=server.getLevel(KEY);
        if(level==null||data.shrinesBuilt||shrineRevealAt>=0)return;
        shrineRevealStartedAt=level.getGameTime();shrineRevealAt=shrineRevealStartedAt+120;shrineRevealStep=-1;
        for(BlockPos shrine:SHRINES)level.sendParticles(ParticleTypes.REVERSE_PORTAL,shrine.getX()+.5,66,shrine.getZ()+.5,100,8,2,8,.25);
    }
    public static void hideShrines(MinecraftServer server){
        ServerLevel level=server.getLevel(KEY);if(level==null)return;shrineRevealStartedAt=-1;shrineRevealAt=-1;shrineRevealStep=-1;
        build(level,true);
        QuestData data=QuestData.get(server);data.shrinesBuilt=false;data.setDirty();
    }
    private static void clearBuildArea(ServerLevel level){
        BlockPos.MutableBlockPos pos=new BlockPos.MutableBlockPos();
        for(int x=-156;x<=156;x++)for(int z=-156;z<=156;z++){
            if(x*x+z*z>156*156)continue;
            for(int y=60;y<=112;y++){
                pos.set(x,y,z);
                if(!level.getBlockState(pos).isAir())level.setBlock(pos,Blocks.AIR.defaultBlockState(),Block.UPDATE_CLIENTS);
            }
        }
    }
    private static void clearShrine(ServerLevel level,BlockPos center){
        for(int dx=-11;dx<=11;dx++)for(int dz=-11;dz<=11;dz++)for(int dy=-1;dy<=10;dy++){
            BlockPos pos=center.offset(dx,dy,dz);if(dy==-1)put(level,pos,Blocks.GRASS_BLOCK.defaultBlockState());else level.removeBlock(pos,false);
        }
    }
    private static void arrivalDeck(ServerLevel level){
        for(int x=-7;x<=7;x++)for(int z=116;z<=129;z++)put(level,x,64,z,Blocks.SPRUCE_PLANKS);
        for(int x:new int[]{-7,7})for(int z=116;z<=129;z++)put(level,x,65,z,Blocks.SPRUCE_FENCE);
        for(int x:new int[]{-6,6})for(int z:new int[]{118,126}){
            put(level,x,65,z,Blocks.STRIPPED_SPRUCE_LOG.defaultBlockState());
            put(level,x,66,z,Blocks.LANTERN.defaultBlockState());
        }
        for(int x=-3;x<=3;x++)put(level,x,64,115,Blocks.SMOOTH_STONE);
    }

    private static void steppedSpring(ServerLevel level,BlockPos center){
        for(int tier=0;tier<3;tier++)for(int dx=-7+tier;dx<=7-tier;dx++)for(int dz=-5+tier;dz<=5-tier;dz++){
            boolean rim=Math.abs(dx)==7-tier||Math.abs(dz)==5-tier;
            put(level,center.offset(dx,tier-1,dz),rim?Blocks.SMOOTH_STONE.defaultBlockState():Blocks.WATER.defaultBlockState());
        }
        for(int dz=-4;dz<=4;dz+=2){
            put(level,center.offset(-9,0,dz),Blocks.CHERRY_LOG.defaultBlockState());
            put(level,center.offset(9,0,dz),Blocks.CHERRY_LOG.defaultBlockState());
        }
        put(level,center.offset(0,-1,0),Blocks.SEA_LANTERN.defaultBlockState());
    }

    private static void crystalTerrace(ServerLevel level,BlockPos center){
        for(int tier=0;tier<4;tier++)for(int dx=-8+tier;dx<=8-tier;dx++)for(int dz=-6+tier;dz<=6-tier;dz++){
            if(Math.abs(dx)!=8-tier&&Math.abs(dz)!=6-tier)continue;
            put(level,center.offset(dx,tier-1,dz),tier%2==0?Blocks.CALCITE.defaultBlockState():Blocks.SMOOTH_BASALT.defaultBlockState());
        }
        for(int[] p:new int[][]{{-5,-3},{4,-2},{-2,3},{6,3},{0,0}}){
            BlockPos crystal=center.offset(p[0],0,p[1]);put(level,crystal,Blocks.AMETHYST_BLOCK.defaultBlockState());
            put(level,crystal.above(),Blocks.AMETHYST_CLUSTER.defaultBlockState());
        }
    }

    private static void arena(ServerLevel level) {
        for(int x=-23;x<=23;x++)for(int z=-23;z<=23;z++){
            int ax=Math.abs(x),az=Math.abs(z);if(ax+az>39)continue;
            int hash=x*92821^z*68917;
            Block floor=ax+az>=37?Blocks.OBSIDIAN
                :(x%8==0||z%8==0)?Blocks.GILDED_BLACKSTONE
                :Math.floorMod(hash,17)==0?Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS:Blocks.POLISHED_BLACKSTONE_BRICKS;
            if(ax<=3&&az<=3)floor=Blocks.CHISELED_POLISHED_BLACKSTONE;
            put(level,x,64,z,floor);
        }
        for(int[] p:new int[][]{{-18,-18},{18,-18},{-18,18},{18,18}}){
            for(int y=65;y<=68;y++)put(level,p[0],y,p[1],Blocks.POLISHED_BASALT);
            put(level,p[0],69,p[1],Blocks.SOUL_LANTERN);
        }
    }

    private static void camp(ServerLevel level) {
        for(int x=-54;x<=-30;x++)for(int z=82;z<=102;z++)
            put(level,x,64,z,(x==-54||x==-30||z==82||z==102)?Blocks.SMOOTH_STONE:Blocks.DIRT);
        // A permanent trail lodge replaces the old canvas camp.
        for(int x=-69;x<=-57;x++)for(int z=86;z<=100;z++){
            put(level,x,64,z,Blocks.STONE_BRICKS);
            boolean wall=x==-69||x==-57||z==86||z==100;
            if(wall)for(int y=65;y<=69;y++){
                boolean window=y==67&&(z==86||z==100)&&x>-67&&x<-59;
                put(level,x,y,z,window?Blocks.LIGHT_BLUE_STAINED_GLASS:Blocks.STRIPPED_DARK_OAK_LOG);
            }
            put(level,x,70,z,Blocks.DARK_OAK_PLANKS);
        }
        for(int y=65;y<=67;y++)put(level,-57,y,93,Blocks.AIR);
        put(level,-63,65,93,Blocks.LECTERN);put(level,-66,65,97,Blocks.BARREL);put(level,-65,65,97,Blocks.CHEST);
        put(level,-48,64,88,Blocks.SEA_LANTERN);put(level,-48,65,88,Blocks.CAMPFIRE);
        for(Direction d:Direction.Plane.HORIZONTAL)put(level,new BlockPos(-48,65,88).relative(d),Blocks.SMOOTH_STONE_SLAB.defaultBlockState());
        for(int x=-43;x<=-40;x++)put(level,x,65,99,Blocks.SPRUCE_SLAB);
        // The eastern court is kept open for the training encounter at CAMP + (12, 0, 0).
        for(int x=-43;x<=-29;x++)for(int z=85;z<=99;z++){
            double r=Math.hypot(x+36,z-92);if(r<=7)put(level,x,64,z,r>6?Blocks.SMOOTH_STONE:Blocks.PACKED_MUD);
        }
        waystone(level,new BlockPos(-53,65,106));
    }

    private static void revealShrineStep(ServerLevel level,BlockPos center,int style,int step){
        Block brick=style==0?Blocks.CUT_COPPER:style==1?Blocks.MUD_BRICKS:Blocks.POLISHED_BLACKSTONE_BRICKS;
        Block trim=style==0?Blocks.QUARTZ_BRICKS:style==1?Blocks.PACKED_MUD:Blocks.PURPUR_BLOCK;
        if(step==0){
            path(level,ARENA,center,2);
        }else if(step==1){
            for(int dx=-8;dx<=8;dx++)for(int dz=-8;dz<=8;dz++)if(Math.abs(dx)+Math.abs(dz)<=13)
                put(level,center.offset(dx,-1,dz),(Math.abs(dx)+Math.abs(dz)>=11?trim:brick).defaultBlockState());
        }else if(step==2){
            for(int dx:new int[]{-6,6})for(int dz:new int[]{-5,5})for(int dy=0;dy<=2;dy++)put(level,center.offset(dx,dy,dz),brick.defaultBlockState());
        }else if(step==3){
            for(int dx=-3;dx<=3;dx++)for(int dy=0;dy<=3;dy++)put(level,center.offset(dx,dy,-6),trim.defaultBlockState());
        }else if(step==4){
            for(int dx=-2;dx<=2;dx++)for(int dy=4;dy<=8;dy++)put(level,center.offset(dx,dy,-6),brick.defaultBlockState());
        }else shrine(level,center,style);
        level.sendParticles(ParticleTypes.END_ROD,center.getX()+.5,65+Math.min(step,4)*1.5,center.getZ()+.5,55,8,1.5,8,.08);
    }

    private static void shrine(ServerLevel level, BlockPos center, int style) {
        Block brick=style==0?Blocks.CUT_COPPER:style==1?Blocks.MUD_BRICKS:Blocks.POLISHED_BLACKSTONE_BRICKS;
        Block trim=style==0?Blocks.QUARTZ_BRICKS:style==1?Blocks.PACKED_MUD:Blocks.PURPUR_BLOCK;
        for(int dx=-8;dx<=8;dx++)for(int dz=-8;dz<=8;dz++)if(Math.abs(dx)+Math.abs(dz)<=13)
            put(level,center.offset(dx,-1,dz),(Math.abs(dx)+Math.abs(dz)>=11?trim:brick).defaultBlockState());
        for(int dx:new int[]{-6,6})for(int dz:new int[]{-5,5}){
            for(int dy=0;dy<=5;dy++)put(level,center.offset(dx,dy,dz),brick.defaultBlockState());
            put(level,center.offset(dx,6,dz),style==2?Blocks.SOUL_LANTERN.defaultBlockState():Blocks.END_ROD.defaultBlockState());
        }
        for(int dx=-3;dx<=3;dx++)for(int dy=0;dy<=3;dy++)put(level,center.offset(dx,dy,-6),trim.defaultBlockState());
        for(int dx=-2;dx<=2;dx++)for(int dy=4;dy<=8;dy++)put(level,center.offset(dx,dy,-6),brick.defaultBlockState());
        for(int dy=2;dy<=7;dy+=2)put(level,center.offset(0,dy,-5),style==0?Blocks.SEA_LANTERN.defaultBlockState():style==1?Blocks.OCHRE_FROGLIGHT.defaultBlockState():Blocks.CRYING_OBSIDIAN.defaultBlockState());
        put(level,center,FalseTraveler.PEDESTAL.get().defaultBlockState());
        put(level,center.below(),Blocks.SEA_LANTERN.defaultBlockState());
        for(int dx:new int[]{-4,4}){
            put(level,center.offset(dx,0,-2),trim.defaultBlockState());
            put(level,center.offset(dx,1,-2),style==2?Blocks.SOUL_LANTERN.defaultBlockState():Blocks.LANTERN.defaultBlockState());
        }
    }

    private static void spectator(ServerLevel level) {
        for(int x=26;x<=34;x++)for(int z=-8;z<=8;z++){
            put(level,x,69,z,(z%4==0)?Blocks.AMETHYST_BLOCK:Blocks.QUARTZ_BRICKS);
            if(x==34||Math.abs(z)==8)put(level,x,70,z,Blocks.TINTED_GLASS);
        }
        for(int step=0;step<5;step++)for(int z=-2;z<=2;z++){
            for(int y=65;y<65+step;y++)put(level,39-step,y,z,Blocks.QUARTZ_BRICKS);
            put(level,39-step,65+step,z,Blocks.QUARTZ_STAIRS.defaultBlockState().setValue(StairBlock.FACING,Direction.WEST));
        }
        for(int z:new int[]{-7,7}){put(level,28,70,z,Blocks.QUARTZ_PILLAR);put(level,28,71,z,Blocks.END_ROD);}
    }

    private static void path(ServerLevel level,BlockPos from,BlockPos to,int width) {
        int steps=Math.max(Math.abs(to.getX()-from.getX()),Math.abs(to.getZ()-from.getZ()));
        for(int i=0;i<=steps;i++){
            double t=(double)i/Math.max(1,steps);int x=(int)Math.round(from.getX()+(to.getX()-from.getX())*t),z=(int)Math.round(from.getZ()+(to.getZ()-from.getZ())*t);
            for(int dx=-width;dx<=width;dx++)for(int dz=-width;dz<=width;dz++)if(dx*dx+dz*dz<=width*width)
                put(level,x+dx,64,z+dz,i%18<3?Blocks.SMOOTH_STONE:Blocks.PACKED_MUD);
            if(i>10&&i<steps-10&&i%24==0)waystone(level,new BlockPos(x+width+2,65,z));
        }
    }
    private static void waystone(ServerLevel level,BlockPos p){
        put(level,p,Blocks.QUARTZ_BRICKS.defaultBlockState());put(level,p.above(),Blocks.COPPER_GRATE.defaultBlockState());
        put(level,p.above(2),Blocks.END_ROD.defaultBlockState());
    }
    private static void tree(ServerLevel level,int x,int z,boolean tall){
        int h=tall?8:6;
        for(int y=65;y<65+h;y++)put(level,x,y,z,(tall?Blocks.CHERRY_LOG:Blocks.BIRCH_LOG).defaultBlockState().setValue(RotatedPillarBlock.AXIS,Direction.Axis.Y));
        for(int dy=h-3;dy<=h+1;dy++)for(int dx=-3;dx<=3;dx++)for(int dz=-3;dz<=3;dz++){
            int radius=dy>=h?1:3;if(Math.abs(dx)+Math.abs(dz)>radius+1||Math.abs(dx)>radius||Math.abs(dz)>radius)continue;
            BlockPos p=new BlockPos(x+dx,65+dy,z+dz);if(level.getBlockState(p).isAir())
                put(level,p,(tall?Blocks.CHERRY_LEAVES:Blocks.BIRCH_LEAVES).defaultBlockState().setValue(LeavesBlock.PERSISTENT,true));
        }
    }
    private static void put(ServerLevel level,int x,int y,int z,Block block){put(level,new BlockPos(x,y,z),block.defaultBlockState());}
    private static void put(ServerLevel level,int x,int y,int z,BlockState state){put(level,new BlockPos(x,y,z),state);}
    private static void put(ServerLevel level,BlockPos pos,BlockState state){level.setBlock(pos,state,Block.UPDATE_CLIENTS);}
}
