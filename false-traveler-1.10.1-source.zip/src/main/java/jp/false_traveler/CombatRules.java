package jp.false_traveler;

/** Pure combat arithmetic shared by the encounter state machine and its tests. */
public final class CombatRules {
    private CombatRules() {}
    public static double health(double base, int players) { return base * (1.0 + .75 * (Math.max(1, Math.min(10, players)) - 1)); }
    public static double damageScale(int players){return 1.0+.18*(Math.max(1,Math.min(10,players))-1);}
    public static int phase(float health, float maxHealth, int previous) {
        if (health <= 0) return previous; // Defeat always takes precedence over transformation.
        return Math.max(previous, health <= maxHealth * .3f ? 3 : health <= maxHealth * .6f ? 2 : 1);
    }
    public static int windup(int action) { return switch (action) { case 1 -> 12; case 2 -> 20; case 3 -> 30; case 4, 5, 6 -> 40; default -> 0; }; }
    public static int cooldown(int action) { return switch (action) { case 1 -> 40; case 2 -> 140; case 3 -> 200; case 4 -> 400; case 5 -> 300; default -> 0; }; }
    public static int recovery(int phase) { return phase == 3 ? 12 : 16; }
    public static boolean withinCircle(double dx, double dz, double radius) { return dx * dx + dz * dz <= radius * radius; }
    public static boolean withinSword(double dx, double dz, double facingX, double facingZ) {
        return withinCircle(dx, dz, 3) && dx * facingX + dz * facingZ >= 0;
    }
}
