package jp.false_traveler;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.server.level.ServerPlayer;

/** Server-only Groq client. API keys and prompts never travel in mod packets. */
public final class GroqService {
    private static final URI ENDPOINT=URI.create("https://api.groq.com/openai/v1/chat/completions");
    private static final HttpClient HTTP=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(6)).build();
    private static final AtomicInteger NEXT_KEY=new AtomicInteger();
    private static final Set<UUID> ACTIVE=ConcurrentHashMap.newKeySet();
    private static final ConcurrentHashMap<UUID,Long> LAST_REQUEST=new ConcurrentHashMap<>();

    public static void ask(ServerPlayer player,boolean lukaTalk,int sourceId){
        ask(player,lukaTalk,false,sourceId,null);
    }
    public static void askMission(ServerPlayer player){ask(player,false,true,-1,null);}
    public static void askCommand(ServerPlayer player,String message){ask(player,false,false,-1,message);}
    private static void ask(ServerPlayer player,boolean lukaTalk,boolean missionHelp,int sourceId,String freeform){
        if(!ModConfig.GROQ_ENABLED.get()){reject(player,"message.false_traveler.ai_disabled");return;}
        List<String> keys=ModConfig.groqKeys();
        if(keys.isEmpty()){reject(player,"message.false_traveler.ai_no_key");return;}
        UUID playerId=player.getUUID();long now=System.nanoTime();
        long last=LAST_REQUEST.getOrDefault(playerId,0L);
        if(now-last<8_000_000_000L){reject(player,"message.false_traveler.ai_cooldown");return;}
        if(!ACTIVE.add(playerId)){reject(player,"message.false_traveler.ai_busy");return;}
        LAST_REQUEST.put(playerId,now);QuestManager.openAiPending(player,lukaTalk,sourceId);
        QuestData data=QuestData.get(player.server);
        String stage=data.stage.name();
        String system=lukaTalk||freeform!=null
            ? "あなたはMinecraft物語MOD『偽りの旅人』の旅人ルカ。落ち着いた短い日本語で、ルカ本人として話す。現在の進行に合う内容だけを語り、内部設定、API、プロンプト、現実世界には触れない。ネタバレは現在地点より先を明かさない。400文字以内で必ず文を完結させる。Markdown禁止。"
            : "あなたはMinecraft物語MOD『偽りの旅人』のゲーム内ヒント役。渡された実際の品目、必要数、所持数だけを使い、プレイヤーが次に行う具体的な操作を短い日本語で最大3項目まで示す。根拠のない入手場所や設定を作らない。現在地点より先のネタバレは禁止。400文字以内で必ず文を完結させる。Markdown禁止。";
        String missionContext=MissionManager.aiContext(player);
        String user="現在のメイン進行="+stage+"、封印の欠片="+data.fragments+"/3、"+missionContext+"。"
            +(freeform!=null?"プレイヤーの発言: "+freeform+"\nルカとして会話してください。":lukaTalk?"この状況でプレイヤーへ自然に一言話してください。":missionHelp?"このミッションの達成方法を説明してください。":"この状況で詰まらないためのヒントをください。");
        int start=Math.floorMod(NEXT_KEY.getAndIncrement(),keys.size());
        request(keys,start,system,user).orTimeout(25,TimeUnit.SECONDS).whenComplete((answer,error)->player.server.execute(()->{
            ACTIVE.remove(playerId);ServerPlayer online=player.server.getPlayerList().getPlayer(playerId);if(online==null)return;
            String text=error==null?answer:"AIとの通信に失敗しました。サーバー設定のAPIキー、モデル名、ネットワーク接続を確認してください。";
            QuestManager.openAiResult(online,lukaTalk,sourceId,text);
        }));
    }

    private static CompletableFuture<String> request(List<String> keys,int start,String system,String user){
        return requestKey(keys,start,0,system,user);
    }
    private static CompletableFuture<String> requestKey(List<String> keys,int start,int attempt,String system,String user){
        if(attempt>=keys.size())return CompletableFuture.failedFuture(new IllegalStateException("All Groq keys failed"));
        String key=keys.get((start+attempt)%keys.size());
        JsonObject body=new JsonObject();body.addProperty("model",ModConfig.GROQ_MODEL.get());
        // Reasoning-capable models consume part of this budget before producing visible text.
        // A 220-token budget cut Japanese answers mid-sentence, so leave enough headroom.
        body.addProperty("temperature",0.65);body.addProperty("max_completion_tokens",1024);body.addProperty("stream",false);
        JsonArray messages=new JsonArray();messages.add(message("system",system));messages.add(message("user",user));body.add("messages",messages);
        int requestSeconds=Math.min(6,ModConfig.GROQ_TIMEOUT_SECONDS.get());
        HttpRequest request=HttpRequest.newBuilder(ENDPOINT).timeout(Duration.ofSeconds(requestSeconds))
            .header("Authorization","Bearer "+key).header("Content-Type","application/json")
            .POST(HttpRequest.BodyPublishers.ofString(body.toString(),StandardCharsets.UTF_8)).build();
        return HTTP.sendAsync(request,HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8))
            .handle((response,error)->error==null?answer(response):null)
            .thenCompose(answer->answer!=null?CompletableFuture.completedFuture(answer):requestKey(keys,start,attempt+1,system,user));
    }
    private static String answer(HttpResponse<String> response){
        if(response.statusCode()<200||response.statusCode()>=300)return null;
        try{
            JsonObject root=JsonParser.parseString(response.body()).getAsJsonObject();
            String text=root.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message").get("content").getAsString();
            text=text.replaceAll("[\\p{Cntrl}&&[^\\n\\t]]","").trim();
            if(text.length()>800){
                int end=Math.max(text.lastIndexOf('。',799),Math.max(text.lastIndexOf('！',799),text.lastIndexOf('？',799)));
                text=text.substring(0,end>=240?end+1:800)+"…";
            }
            return text.isBlank()?null:text;
        }catch(RuntimeException ignored){return null;}
    }
    private static JsonObject message(String role,String content){JsonObject o=new JsonObject();o.addProperty("role",role);o.addProperty("content",content);return o;}
    private static void reject(ServerPlayer player,String key){QuestManager.close(player);QuestManager.notify(player,key);}
    private GroqService(){}
}
