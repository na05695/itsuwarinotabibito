package jp.false_traveler;

import com.google.gson.JsonObject;
import java.util.function.Consumer;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

/** The common side has no client class references, including in handler lambdas. */
public final class Network {
    public static Consumer<String> CLIENT_HANDLER = ignored -> {};
    public record Ui(String json) implements CustomPacketPayload {
        public static final Type<Ui> TYPE=new Type<>(FalseTraveler.id("ui"));
        public static final StreamCodec<RegistryFriendlyByteBuf,Ui> CODEC=StreamCodec.of((b,p)->b.writeUtf(p.json,32767), b->new Ui(b.readUtf(32767)));
        @Override public Type<Ui> type(){return TYPE;}
    }
    public record Action(int session,String action) implements CustomPacketPayload {
        public static final Type<Action> TYPE=new Type<>(FalseTraveler.id("action"));
        public static final StreamCodec<RegistryFriendlyByteBuf,Action> CODEC=StreamCodec.of((b,p)->{b.writeVarInt(p.session);b.writeUtf(p.action,48);},b->new Action(b.readVarInt(),b.readUtf(48)));
        @Override public Type<Action> type(){return TYPE;}
    }
    public record ConfigRequest(boolean open) implements CustomPacketPayload {
        public static final Type<ConfigRequest> TYPE=new Type<>(FalseTraveler.id("config_request"));
        public static final StreamCodec<RegistryFriendlyByteBuf,ConfigRequest> CODEC=StreamCodec.of((b,p)->b.writeBoolean(p.open),b->new ConfigRequest(b.readBoolean()));
        @Override public Type<ConfigRequest> type(){return TYPE;}
    }
    public record ConfigUpdate(String json) implements CustomPacketPayload {
        public static final Type<ConfigUpdate> TYPE=new Type<>(FalseTraveler.id("config_update"));
        public static final StreamCodec<RegistryFriendlyByteBuf,ConfigUpdate> CODEC=StreamCodec.of((b,p)->b.writeUtf(p.json,8192),b->new ConfigUpdate(b.readUtf(8192)));
        @Override public Type<ConfigUpdate> type(){return TYPE;}
    }
    public static void register(RegisterPayloadHandlersEvent e){
        var r=e.registrar("1");
        r.playToClient(Ui.TYPE,Ui.CODEC,(p,c)->c.enqueueWork(()->CLIENT_HANDLER.accept(p.json)));
        r.playToServer(Action.TYPE,Action.CODEC,(p,c)->c.enqueueWork(()->{if(c.player() instanceof ServerPlayer s)QuestManager.action(s,p.session,p.action);}));
        r.playToServer(ConfigRequest.TYPE,ConfigRequest.CODEC,(p,c)->c.enqueueWork(()->{if(c.player() instanceof ServerPlayer s)ServerSettingsManager.open(s);}));
        r.playToServer(ConfigUpdate.TYPE,ConfigUpdate.CODEC,(p,c)->c.enqueueWork(()->{if(c.player() instanceof ServerPlayer s)ServerSettingsManager.update(s,p.json);}));
    }
    public static void send(ServerPlayer p,JsonObject o){PacketDistributor.sendToPlayer(p,new Ui(o.toString()));}
    public static void sendAction(int session,String action){PacketDistributor.sendToServer(new Action(session,action));}
    public static void requestServerSettings(){PacketDistributor.sendToServer(new ConfigRequest(true));}
    public static void updateServerSettings(String json){PacketDistributor.sendToServer(new ConfigUpdate(json));}
    private Network(){}
}
