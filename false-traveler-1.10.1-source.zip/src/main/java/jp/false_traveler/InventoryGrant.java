package jp.false_traveler;

import java.util.*;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Simulates the entire bundle before touching inventory: no partial or dropped rewards. */
public final class InventoryGrant {
    public static boolean give(ServerPlayer p,ItemStack... bundle){
        List<ItemStack> result=new ArrayList<>();p.getInventory().items.forEach(s->result.add(s.copy()));
        if(!insert(p,result,bundle))return false;
        commit(p,result);return true;
    }
    /** Atomically removes an objective bundle and inserts its reward. */
    public static boolean exchange(ServerPlayer p,Item objective,int count,ItemStack... reward){
        List<ItemStack> result=new ArrayList<>();p.getInventory().items.forEach(s->result.add(s.copy()));
        int needed=count;
        for(ItemStack stack:result)if(stack.is(objective)){
            int remove=Math.min(needed,stack.getCount());stack.shrink(remove);needed-=remove;if(needed==0)break;
        }
        if(needed!=0||!insert(p,result,reward))return false;
        commit(p,result);return true;
    }
    private static boolean insert(ServerPlayer p,List<ItemStack> result,ItemStack... bundle){
        for(ItemStack source:bundle){
            ItemStack remaining=source.copy();
            for(ItemStack slot:result){
                if(!slot.isEmpty() && ItemStack.isSameItemSameComponents(slot,remaining)){
                    int count=Math.min(remaining.getCount(),Math.min(slot.getMaxStackSize(),p.getInventory().getMaxStackSize())-slot.getCount());
                    if(count>0){slot.grow(count);remaining.shrink(count);}if(remaining.isEmpty())break;
                }
            }
            for(int i=0;i<result.size()&&!remaining.isEmpty();i++)if(result.get(i).isEmpty()){
                int count=Math.min(remaining.getCount(),Math.min(remaining.getMaxStackSize(),p.getInventory().getMaxStackSize()));
                result.set(i,remaining.copyWithCount(count));remaining.shrink(count);
            }
            if(!remaining.isEmpty())return false;
        }
        return true;
    }
    private static void commit(ServerPlayer p,List<ItemStack> result){
        for(int i=0;i<result.size();i++)p.getInventory().items.set(i,result.get(i));
        p.getInventory().setChanged();p.containerMenu.broadcastChanges();
    }
    private InventoryGrant(){}
}
