package jp.false_traveler;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;

public final class QuestItem extends Item {
    private final boolean charm;
    public QuestItem(boolean charm,Properties properties){super(properties);this.charm=charm;}
    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand){
        if(player instanceof ServerPlayer p){if(charm)QuestManager.useCharm(p);else QuestManager.openJournal(p);}
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand),level.isClientSide);
    }
}
