package jp.false_traveler;

import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;
import java.util.UUID;

/** Small dedicated-server smoke tests. The normal client run does not execute these. */
@GameTestHolder(FalseTraveler.MOD_ID)
@PrefixGameTestTemplate(false)
public final class FalseTravelerGameTests {
    @GameTest(templateNamespace = FalseTraveler.MOD_ID, template = "empty", timeoutTicks = 40)
    public static void registriesAndValleyLoadOnDedicatedServer(GameTestHelper helper) {
        var server = helper.getLevel().getServer();
        // GameTestServer intentionally instantiates only the three vanilla levels. Check the
        // underlying dynamic registries and the raw level-stem resource instead.
        var dimensionTypes = helper.getLevel().registryAccess().registryOrThrow(Registries.DIMENSION_TYPE);
        helper.assertTrue(dimensionTypes.containsKey(FalseTraveler.id("valley")),
            "Valley dimension type was not loaded");
        var biomes = helper.getLevel().registryAccess().registryOrThrow(Registries.BIOME);
        helper.assertTrue(biomes.containsKey(FalseTraveler.id("forgotten_valley")),
            "Forgotten Valley biome was not loaded");
        helper.assertTrue(server.getResourceManager().getResource(FalseTraveler.id("dimension/valley.json")).isPresent(),
            "Valley level-stem JSON was not in the active data pack");
        helper.assertTrue(FalseTraveler.LUKA.isBound() && FalseTraveler.SHADOW.isBound(),
            "Encounter entity types were not registered");
        helper.assertTrue(FalseTraveler.JOURNAL.isBound() && FalseTraveler.CHARM.isBound() && FalseTraveler.GEOMETRY_SIGIL.isBound()
                && FalseTraveler.DAWN_FLASK.isBound() && FalseTraveler.AEGIS_BELL.isBound()
                && FalseTraveler.RIFT_FEATHER.isBound() && FalseTraveler.BINDING_HOURGLASS.isBound(),
            "Quest items were not registered");
        helper.assertTrue(FalseTraveler.TRAVELER_SWORD.isBound() && FalseTraveler.TRAVELER_HELMET.isBound()
                && FalseTraveler.TRAVELER_CHESTPLATE.isBound() && FalseTraveler.TRAVELER_LEGGINGS.isBound()
                && FalseTraveler.TRAVELER_BOOTS.isBound(), "Traveler combat gear was not registered");
        helper.assertTrue(FalseTraveler.TRAVELER_ARMOR.isBound(),"Traveler armor material was not registered");
        helper.assertTrue(MissionManager.maximum() == 30, "The total mission route must allow exactly thirty entries");
        helper.assertTrue(MissionManager.count() >= 3 && MissionManager.count() <= 30, "Configured mission count must stay in the 3-30 range");
        helper.assertTrue(MissionManager.ordinaryCount()==MissionManager.count()-3,"The final three configured missions must be shrines");
        QuestData quest=QuestData.get(server);UUID testPlayer=UUID.fromString("00000000-0000-0000-0000-000000000130");
        quest.stage=Stage.DEFENSE;quest.player(testPlayer).missionIndex=Math.max(0,MissionManager.ordinaryCount()-1);
        helper.assertTrue(!QuestManager.missionsCompleted(server)&&quest.stage==Stage.DEFENSE,"Shrines unlocked before all configured missions were complete");
        quest.player(testPlayer).missionIndex=MissionManager.ordinaryCount();
        helper.assertTrue(QuestManager.missionsCompleted(server)&&quest.stage==Stage.FRAGMENTS,"Completing configured missions did not unlock fragment collection");
        quest.players.remove(testPlayer);quest.stage=Stage.NOT_STARTED;quest.fragments=0;quest.setDirty();
        var damageTypes = helper.getLevel().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE);
        helper.assertTrue(damageTypes.containsKey(CombatDamage.STRIKE.location()),
            "Strike damage type was not loaded");
        helper.assertTrue(damageTypes.containsKey(CombatDamage.ARROW.location()),
            "Shadow-arrow damage type was not loaded");
        helper.assertTrue(damageTypes.containsKey(CombatDamage.ARCANE.location()),
            "Arcane damage type was not loaded");
        helper.succeed();
    }

    private FalseTravelerGameTests() {}
}
