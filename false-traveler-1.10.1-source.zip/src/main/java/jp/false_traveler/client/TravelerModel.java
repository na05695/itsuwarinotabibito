package jp.false_traveler.client;

import java.util.List;
import jp.false_traveler.FalseTraveler;
import jp.false_traveler.LukaEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;

/** Humanoid traveler model whose hostile form becomes a ruby-and-gold celestial sorceress. */
public final class TravelerModel<T extends Mob> extends HumanoidModel<T> {
    public static final ModelLayerLocation LAYER=new ModelLayerLocation(FalseTraveler.id("traveler"),"main");
    private final ModelPart cloak,backHair,leftRibbon,rightRibbon,crown,chestGem,staff;
    private final List<ModelPart> bossParts;

    public TravelerModel(ModelPart root){
        super(root);
        cloak=body.getChild("cloak");backHair=body.getChild("back_hair");leftRibbon=body.getChild("left_ribbon");
        rightRibbon=body.getChild("right_ribbon");crown=head.getChild("crown");chestGem=body.getChild("chest_gem");
        staff=rightArm.getChild("staff");bossParts=List.of(backHair,leftRibbon,rightRibbon,crown,chestGem,staff);
    }

    public static LayerDefinition createLayer(){
        MeshDefinition mesh=HumanoidModel.createMesh(CubeDeformation.NONE,0);var root=mesh.getRoot();var body=root.getChild("body");
        body.addOrReplaceChild("cloak",CubeListBuilder.create().texOffs(64,0)
            .addBox(-4.5F,0,2,9,12,1,new CubeDeformation(.12F)),PartPose.ZERO);
        body.addOrReplaceChild("back_hair",CubeListBuilder.create().texOffs(64,16)
            .addBox(-4.5F,-7.5F,2.15F,9,20,1,new CubeDeformation(.08F)),PartPose.ZERO);
        body.addOrReplaceChild("left_ribbon",CubeListBuilder.create().texOffs(64,40)
            .addBox(-5.1F,0,2.15F,2,14,1,new CubeDeformation(.04F)),PartPose.rotation(0,0,-.10F));
        body.addOrReplaceChild("right_ribbon",CubeListBuilder.create().texOffs(74,40)
            .addBox(3.1F,0,2.15F,2,14,1,new CubeDeformation(.04F)),PartPose.rotation(0,0,.10F));
        root.getChild("head").addOrReplaceChild("crown",CubeListBuilder.create().texOffs(84,40)
            .addBox(-1F,-12F,-1F,2F,4F,2F,new CubeDeformation(.04F))
            .texOffs(96,40).addBox(-4F,-10.5F,-1F,2F,2.5F,2F,new CubeDeformation(.04F))
            .texOffs(108,40).addBox(2F,-10.5F,-1F,2F,2.5F,2F,new CubeDeformation(.04F)),PartPose.ZERO);
        body.addOrReplaceChild("chest_gem",CubeListBuilder.create().texOffs(88,0)
            .addBox(-1F,2.5F,-2.8F,2F,3F,1F,new CubeDeformation(.04F)),PartPose.rotation(0,0,(float)Math.PI/4));
        root.getChild("right_arm").addOrReplaceChild("staff",CubeListBuilder.create().texOffs(96,0)
            .addBox(-.75F,-12F,-.75F,1.5F,28F,1.5F,new CubeDeformation(.02F))
            .texOffs(104,0).addBox(-3F,-17F,-2F,6F,5F,3F,new CubeDeformation(.06F))
            .texOffs(104,14).addBox(-1.5F,-20F,-1.5F,3F,3F,3F,new CubeDeformation(.08F)),PartPose.offset(0,0,0));
        return LayerDefinition.create(mesh,128,128);
    }

    @Override public void setupAnim(T entity,float walk,float speed,float age,float yaw,float pitch){
        super.setupAnim(entity,walk,speed,age,yaw,pitch);
        boolean hostile=entity instanceof LukaEntity luka&&luka.isHostile();
        cloak.visible=true;body.skipDraw=false;
        head.visible=hat.visible=rightArm.visible=leftArm.visible=rightLeg.visible=leftLeg.visible=true;
        for(ModelPart part:bossParts)part.visible=hostile;
        body.y=0;body.yRot=0;
        if(hostile){
            float sway=Mth.sin(age*.06F)*.08F;leftRibbon.zRot=-.16F-sway;rightRibbon.zRot=.16F+sway;
            backHair.xRot=.035F+Mth.sin(age*.04F)*.025F;cloak.xRot=.09F+Mth.sin(age*.055F)*.045F;
            rightArm.xRot=-.38F+Mth.sin(age*.035F)*.05F;rightArm.zRot=.12F;
            leftArm.xRot=-.18F;leftArm.zRot=-.16F;
            crown.y=Mth.sin(age*.08F)*.12F;chestGem.z=Mth.sin(age*.1F)*.08F;
        }else cloak.xRot=.06F+Mth.sin(age*.065F)*.035F+speed*.18F;
    }
}
