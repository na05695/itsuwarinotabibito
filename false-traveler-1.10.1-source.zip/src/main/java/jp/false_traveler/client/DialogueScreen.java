package jp.false_traveler.client;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import jp.false_traveler.Network;
import jp.false_traveler.FalseTraveler;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;

/** Local-only presentation: all choices are revalidated by the server. */
public final class DialogueScreen extends Screen {
    private final JsonObject data;
    private final List<List<FormattedCharSequence>> pages = new ArrayList<>();
    private final List<JsonObject> choices = new ArrayList<>();
    private int page, panelX, panelY, panelW, panelH, linesPerPage, choiceRows;
    private ResourceKey<Level> origin;
    private float lastHealth;
    private int lastHurt;

    public DialogueScreen(JsonObject data) {
        super(ClientEvents.component(data, "title"));
        this.data = data;
        if (data.has("choices")) for (JsonElement choice : data.getAsJsonArray("choices")) choices.add(choice.getAsJsonObject());
    }

    @Override
    protected void init() {
        panelW = Math.max(150, Math.min(536, width - 20));
        panelX = (width - panelW) / 2;
        panelH = Math.min(height - 18, Math.max(202, height * 2 / 3));
        panelY = height - panelH - 9;
        choiceRows = panelW < 420 ? Math.min(3, Math.max(1, choices.size())) : 1;
        linesPerPage = Math.max(1, (panelH - 79 - choiceRows * 23) / 12);
        List<FormattedCharSequence> lines = font.split(ClientEvents.component(data, "body"), panelW - 32);
        pages.clear();
        for (int i = 0; i < lines.size(); i += linesPerPage) pages.add(new ArrayList<>(lines.subList(i, Math.min(lines.size(), i + linesPerPage))));
        if (pages.isEmpty()) pages.add(List.of());
        page = Math.min(page, totalPages() - 1);
        if (minecraft != null && minecraft.player != null && origin == null) {
            origin = minecraft.player.level().dimension();
            lastHealth = minecraft.player.getHealth();
            lastHurt = minecraft.player.hurtTime;
        }
        buttons();
    }

    private int totalPages() { return pages.size() + Math.max(0, (choices.size() - 1) / 3); }

    private void buttons() {
        clearWidgets();
        int y = panelY + panelH - 29 - choiceRows * 23;
        int navY = panelY + panelH - 25;
        if (page < pages.size() - 1) {
            addRenderableWidget(Button.builder(Component.translatable("ui.false_traveler.next"), b -> { page++; buttons(); })
                    .bounds(panelX + 16, y, panelW - 32, 20).build());
        } else {
            int choicePage = Math.max(0, page - pages.size() + 1), start = choicePage * 3;
            int count = Math.min(3, choices.size() - start);
            int gap = 5, bw = choiceRows > 1 || count == 0 ? panelW - 32 : (panelW - 32 - gap * (count - 1)) / count;
            for (int i = 0; i < count; i++) {
                JsonObject choice = choices.get(start + i);
                String action = ClientEvents.string(choice, "id", "");
                addRenderableWidget(Button.builder(ClientEvents.component(choice, "label"), b -> {
                    Network.sendAction(ClientEvents.integer(data, "session", 0), action);
                    onClose();
                }).bounds(panelX + 16 + (choiceRows > 1 ? 0 : i * (bw + gap)), y + (choiceRows > 1 ? i * 23 : 0), bw, 20).build());
            }
            if (page < totalPages() - 1) addRenderableWidget(Button.builder(Component.translatable("ui.false_traveler.more"), b -> { page++; buttons(); })
                    .bounds(panelX + panelW - 106, navY, 90, 20).build());
        }
        if (page > 0) addRenderableWidget(Button.builder(Component.translatable("ui.false_traveler.previous"), b -> { page--; buttons(); })
                .bounds(panelX + 16, navY, 70, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("ui.false_traveler.close"), b -> onClose())
                .bounds(panelX + panelW - 68, panelY + 8, 52, 20).build());
        if (ClientEvents.string(data, "mode", "").equals("journal")) {
            addRenderableWidget(Button.builder(Component.translatable("ui.false_traveler.settings"), b -> minecraft.setScreen(new StorySettingsScreen(this)))
                    .bounds(panelX + panelW - 125, panelY + 8, 52, 20).build());
        }
    }

    @Override
    public void tick() {
        if (minecraft == null || minecraft.player == null || minecraft.level == null) { onClose(); return; }
        if (!minecraft.level.dimension().equals(origin) || minecraft.player.getHealth() < lastHealth || minecraft.player.hurtTime > lastHurt) { onClose(); return; }
        lastHealth = minecraft.player.getHealth();
        lastHurt = minecraft.player.hurtTime;
        int id = ClientEvents.integer(data, "sourceId", -1);
        if (id >= 0) {
            Entity source = minecraft.level.getEntity(id);
            if (source == null || minecraft.player.distanceToSqr(source) > 64) onClose();
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        // Deliberately do not blur the world: this screen never pauses the encounter.
        g.fill(panelX + 3, panelY + 3, panelX + panelW + 3, panelY + panelH + 3, 0x66000000);
        g.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xEF141E2B);
        g.fill(panelX, panelY, panelX + panelW, panelY + 2, 0xFFBBA575);
        g.fill(panelX, panelY + 33, panelX + panelW, panelY + 34, 0xFF384753);
        g.blit(FalseTraveler.id("textures/gui/sigil.png"), panelX + 10, panelY + 9, 0, 0, 16, 16, 16, 16);
        g.drawString(font, title, panelX + 31, panelY + 15, 0xE8D8AC, false);
        List<FormattedCharSequence> shown = pages.get(Math.min(page, pages.size() - 1));
        int y = panelY + 43;
        for (FormattedCharSequence line : shown) { g.drawString(font, line, panelX + 16, y, 0xF1F3EC, false); y += 12; }
        String pageText = (page + 1) + " / " + totalPages();
        g.drawCenteredString(font, pageText, panelX + panelW / 2, panelY + panelH - 19, 0x91A3AF);
        super.render(g, mouseX, mouseY, partialTick);
    }

    /**
     * Screen.render normally applies Minecraft's full-screen blur here. Because this method is
     * reached from super.render after our title and body were drawn, that blur affected only the
     * story text while the buttons stayed sharp. The panel already supplies its own readable
     * backdrop, so keep the live world and every layer of this UI unblurred.
     */
    @Override public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {}

    @Override public boolean isPauseScreen() { return false; }
    @Override public boolean shouldCloseOnEsc() { return true; }
}
