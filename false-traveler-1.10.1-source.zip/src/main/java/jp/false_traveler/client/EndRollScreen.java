package jp.false_traveler.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Ninety-second story epilogue. The credits deliberately travel from the top toward the bottom. */
final class EndRollScreen extends Screen {
    private static final long DURATION_MS=90_000L;
    private static final String[] KEYS={
        "credits.false_traveler.01","credits.false_traveler.02","",
        "credits.false_traveler.03","credits.false_traveler.04","credits.false_traveler.05","credits.false_traveler.06","",
        "credits.false_traveler.07","credits.false_traveler.08","credits.false_traveler.09","credits.false_traveler.10","",
        "credits.false_traveler.11","credits.false_traveler.12","credits.false_traveler.13","credits.false_traveler.14","",
        "credits.false_traveler.15","credits.false_traveler.16","credits.false_traveler.17","",
        "credits.false_traveler.18","credits.false_traveler.19","credits.false_traveler.20","credits.false_traveler.21","",
        "credits.false_traveler.22","credits.false_traveler.23","credits.false_traveler.24","",
        "credits.false_traveler.25"
    };
    private final long startedAt=System.currentTimeMillis();
    private final List<Component> lines=new ArrayList<>();

    EndRollScreen(){super(Component.translatable("credits.false_traveler.01"));for(String key:KEYS)lines.add(key.isEmpty()?Component.empty():Component.translatable(key));}
    @Override public void tick(){if(System.currentTimeMillis()-startedAt>=DURATION_MS&&minecraft!=null)minecraft.setScreen(null);}
    @Override public void render(GuiGraphics graphics,int mouseX,int mouseY,float partialTick){
        graphics.fill(0,0,width,height,0xFF05030D);
        long elapsed=Math.min(DURATION_MS,System.currentTimeMillis()-startedAt);
        float progress=elapsed/(float)DURATION_MS;
        int spacing=22,total=lines.size()*spacing;
        float y=-18+progress*(height+total);
        for(int i=0;i<lines.size();i++){
            int lineY=Math.round(y-i*spacing);
            if(lineY>-20&&lineY<height+20){
                int color=i==0||i==1||i==lines.size()-1?0xFFD36B:0xE8EEF7;
                graphics.drawCenteredString(font,lines.get(i),width/2,lineY,color);
            }
        }
        graphics.fill(0,0,width,18,0xC805030D);graphics.fill(0,height-18,width,height,0xC805030D);
        graphics.drawString(font,Component.translatable("credits.false_traveler.skip"),8,height-14,0x75808D,false);
        super.render(graphics,mouseX,mouseY,partialTick);
    }
    @Override public void renderBackground(GuiGraphics graphics,int mouseX,int mouseY,float partialTick){}
    @Override public boolean isPauseScreen(){return false;}
}
