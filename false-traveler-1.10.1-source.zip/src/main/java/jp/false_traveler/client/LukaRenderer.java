package jp.false_traveler.client;

import com.mojang.blaze3d.vertex.PoseStack;
import jp.false_traveler.FalseTraveler;
import jp.false_traveler.LukaEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public final class LukaRenderer extends HumanoidMobRenderer<LukaEntity, TravelerModel<LukaEntity>> {
    private static final ResourceLocation NORMAL = FalseTraveler.id("textures/entity/luka.png");
    private static final ResourceLocation AWAKENED = FalseTraveler.id("textures/entity/luka_awakened.png");
    public LukaRenderer(EntityRendererProvider.Context ctx) { super(ctx, new TravelerModel<>(ctx.bakeLayer(TravelerModel.LAYER)), .45F); }
    @Override public ResourceLocation getTextureLocation(LukaEntity entity) { return entity.isHostile() ? AWAKENED : NORMAL; }
    @Override protected void scale(LukaEntity entity,PoseStack pose,float partialTick){
        float scale=entity.isHostile()?1.45F:1.0F;pose.scale(scale,scale,scale);super.scale(entity,pose,partialTick);
    }
}
