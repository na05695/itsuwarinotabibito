package jp.false_traveler.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import jp.false_traveler.FalseTraveler;

/** Curved, independently animated geometry; never uses the player skin cube mesh. */
final class SeraphMesh {
    private static final int WHITE=0xfff7eef2, HAIR=0xffe4dce9, GOLD=0xffe2b550, RED=0xffa31335, RUBY=0xffff244c, SKIN=0xfff3d6cb, DARK=0xff361b31;
    private final VertexConsumer out;
    private final PoseStack.Pose pose;
    private final int light;
    private SeraphMesh(PoseStack stack,MultiBufferSource buffers,int light){
        this.pose=stack.last();this.light=light;
        out=buffers.getBuffer(RenderType.entityCutoutNoCull(FalseTraveler.id("textures/entity/luka_awakened.png")));
    }
    static void render(PoseStack stack,MultiBufferSource buffers,int light,float time,int phase){
        SeraphMesh m=new SeraphMesh(stack,buffers,light);
        // World-up coordinates; the front of the character faces negative Z.
        m.ellipsoid(0,2.58,0,.245,.32,.225,SKIN);
        m.ellipsoid(0,2.31,0,.095,.15,.09,SKIN);
        m.ellipsoid(0,1.97,0,.26,.36,.145,WHITE);
        m.ellipsoid(0,1.63,.02,.22,.16,.15,GOLD);
        m.ellipsoid(0,2.68,.09,.265,.27,.20,HAIR);
        // Sculpted nose, lips, separate sclera, ruby irises, pupils and highlights.
        m.ellipsoid(0,2.56,-.228,.024,.055,.037,SKIN);
        m.ellipsoid(0,2.45,-.217,.052,.012,.011,RED);
        for(int side:new int[]{-1,1}){
            double x=side*.09;
            m.ellipsoid(x,2.61,-.210,.065,.031,.018,DARK);
            m.ellipsoid(x,2.608,-.225,.052,.022,.011,WHITE);
            m.ellipsoid(x,2.608,-.237,.023,.024,.007,RUBY);
            m.ellipsoid(x,2.608,-.244,.009,.019,.004,DARK);
            m.ellipsoid(x-.007,2.619,-.249,.006,.006,.003,WHITE);
            m.segment(x-.055,2.665,-.218,x+.05,2.67,-.218,.009,DARK);
            m.ellipsoid(side*.244,2.49,0,.033,.07,.025,GOLD);
            m.gem(side*.245,2.39,-.015,.04,.095,RUBY);
            // Shoulder, upper arm, elbow, forearm and individual fingers.
            double elbow=side*.40, hand=side*.53;
            m.ellipsoid(side*.28,2.15,0,.14,.12,.14,GOLD);
            m.segment(side*.29,2.12,0,elbow,1.87,-.025,.095,WHITE);
            m.segment(elbow,1.87,-.025,hand,1.72,-.12,.074,SKIN);
            m.ellipsoid(hand,1.72,-.12,.073,.09,.04,SKIN);
            for(int f=0;f<4;f++)m.segment(hand+(f-1.5)*.026,1.70,-.13,hand+(f-1.5)*.028,1.59,-.14,.012,SKIN);
            m.segment(hand-side*.055,1.73,-.11,hand-side*.09,1.66,-.15,.017,SKIN);
            m.ellipsoid(elbow,1.88,-.025,.106,.045,.105,GOLD);
        }
        // Numerous curved locks frame the face without an opaque face overlay.
        for(int lock=0;lock<26;lock++){
            double a=lock*Math.PI*2/26;
            if(Math.sin(a)<-.45)continue;
            double px=Math.cos(a)*.22,py=2.82,pz=Math.sin(a)*.17;
            for(int j=1;j<=12;j++){
                double t=j/12.0;
                double x=Math.cos(a)*(.23+.20*t)+Math.sin(t*8+lock+time*.035)*.065*t;
                double y=2.82-1.63*t,z=.08+Math.sin(a)*.18+.23*t;
                m.segment(px,py,pz,x,y,z,.033*(1-.65*t),lock%3==0?WHITE:HAIR);px=x;py=y;pz=z;
            }
        }
        // Layered flowing skirt, with gold seams and red outer mantle.
        for(int panel=0;panel<16;panel++){
            double a=panel*Math.PI*2/16;
            m.cloth(a,time,panel%3==0?RED:WHITE,panel);
        }
        for(int side:new int[]{-1,1}){
            m.segment(side*.12,.72,0,side*.13,.20,-.035,.072,SKIN);
            m.ellipsoid(side*.13,.15,-.075,.085,.15,.12,GOLD);
            m.gem(side*.13,.25,-.15,.035,.07,RUBY);
        }
        // Diadem with branching gold spires and suspended ruby facets.
        for(int i=0;i<11;i++){
            double a=i*Math.PI*2/11,x=Math.cos(a)*.24,z=Math.sin(a)*.20;
            m.segment(x,2.83,z,x*1.16,2.96+(i%2)*.09,z*1.16,.018,GOLD);
            m.gem(x*1.16,2.98+(i%2)*.09,z*1.16,.024,.055,RUBY);
        }
        m.gem(0,2.80,-.24,.055,.10,RUBY);
        m.gem(0,2.17,-.155,.065,.11,RUBY);
        m.gem(0,1.66,-.16,.065,.10,RUBY);
        for(int side:new int[]{-1,1})for(int j=0;j<7;j++){
            double y=1.72+j*.057,x=side*(.045+j*.026);
            m.segment(x,y,-.15,x+side*.035,y+.055,-.145,.008,GOLD);
        }
        // Ornate staff with a large multifaceted crystal inside a golden orbit.
        m.segment(-.57,.12,-.12,-.57,2.95,-.12,.026,GOLD);
        m.gem(-.57,2.84,-.12,.135,.24,RUBY);
        m.ring(-.57,2.84,-.12,.235,0,GOLD);
        m.ring(-.57,2.84,-.12,.29,time*.015,RED);
        // Nonhuman, floating halo and six independently orbiting ruby shards.
        m.ring(0,2.72,.30,.52,time*.007,GOLD);
        for(int i=0;i<6;i++){
            double a=time*.016+i*Math.PI/3;
            m.gem(Math.cos(a)*(.76+phase*.035),2.10+Math.sin(a)*.42,.26+Math.sin(a)*.16,.058,.15,RUBY);
        }
    }
    private void cloth(double a,float time,int color,int index){
        for(int j=0;j<15;j++){
            double t=j/15.0,u=(j+1)/15.0;
            double[] p=hem(a-.105,t,time,index),q=hem(a+.105,t,time,index),r=hem(a+.105,u,time,index),s=hem(a-.105,u,time,index);
            quad(p,q,r,s,color);
            segment(p[0],p[1],p[2],s[0],s[1],s[2],.006,GOLD);
        }
    }
    private double[] hem(double a,double t,float time,int index){
        double radius=.22+.36*t+.035*Math.sin(t*8+time*.045+index)*t;
        return new double[]{Math.cos(a)*radius,1.67-1.40*t,Math.sin(a)*radius+.06};
    }
    private void ring(double x,double y,double z,double radius,double spin,int color){
        for(int i=0;i<40;i++){
            double a=i*Math.PI/20+spin,b=(i+1)*Math.PI/20+spin;
            segment(x+Math.cos(a)*radius,y+Math.sin(a)*radius,z,x+Math.cos(b)*radius,y+Math.sin(b)*radius,z,.012,color);
        }
    }
    private void gem(double x,double y,double z,double radius,double height,int color){
        for(int i=0;i<8;i++){
            double a=i*Math.PI/4,b=(i+1)*Math.PI/4;
            double[] p={x+Math.cos(a)*radius,y,z+Math.sin(a)*radius},q={x+Math.cos(b)*radius,y,z+Math.sin(b)*radius};
            quad(new double[]{x,y+height,z},q,p,p,color);
            quad(new double[]{x,y-height,z},p,q,q,color);
        }
    }
    private void ellipsoid(double x,double y,double z,double rx,double ry,double rz,int color){
        for(int j=0;j<12;j++)for(int i=0;i<20;i++){
            double a=i*Math.PI/10,b=(i+1)*Math.PI/10,c=-Math.PI/2+j*Math.PI/12,d=c+Math.PI/12;
            quad(surface(x,y,z,rx,ry,rz,a,c),surface(x,y,z,rx,ry,rz,a,d),surface(x,y,z,rx,ry,rz,b,d),surface(x,y,z,rx,ry,rz,b,c),color);
        }
    }
    private static double[] surface(double x,double y,double z,double rx,double ry,double rz,double a,double b){return new double[]{x+rx*Math.cos(a)*Math.cos(b),y+ry*Math.sin(b),z+rz*Math.sin(a)*Math.cos(b)};}
    private void segment(double x,double y,double z,double X,double Y,double Z,double radius,int color){
        double dx=X-x,dy=Y-y,dz=Z-z,len=Math.sqrt(dx*dx+dy*dy+dz*dz);if(len<.00001)return;
        double ux=-dy,uy=dx,uz=0,l=Math.sqrt(ux*ux+uy*uy);if(l<.00001){ux=1;uy=0;l=1;}ux/=l;uy/=l;
        double vx=-dz*uy/len,vy=dz*ux/len,vz=(dx*uy-dy*ux)/len;
        for(int i=0;i<8;i++){
            double a=i*Math.PI/4,b=(i+1)*Math.PI/4;
            double ax=radius*(ux*Math.cos(a)+vx*Math.sin(a)),ay=radius*(uy*Math.cos(a)+vy*Math.sin(a)),az=radius*(uz*Math.cos(a)+vz*Math.sin(a));
            double bx=radius*(ux*Math.cos(b)+vx*Math.sin(b)),by=radius*(uy*Math.cos(b)+vy*Math.sin(b)),bz=radius*(uz*Math.cos(b)+vz*Math.sin(b));
            quad(new double[]{x+ax,y+ay,z+az},new double[]{x+bx,y+by,z+bz},new double[]{X+bx,Y+by,Z+bz},new double[]{X+ax,Y+ay,Z+az},color);
        }
    }
    private void quad(double[] a,double[] b,double[] c,double[] d,int color){
        double ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];
        double nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx,len=Math.sqrt(nx*nx+ny*ny+nz*nz);if(len<1e-9)len=1;
        for(double[] p:new double[][]{a,b,c,d})out.addVertex(pose,(float)p[0],(float)p[1],(float)p[2]).setColor(color).setUv(21.5f/128,21.5f/128).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose,(float)(nx/len),(float)(ny/len),(float)(nz/len));
    }
}
