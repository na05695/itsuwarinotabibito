package jp.false_traveler.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import jp.false_traveler.Network;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Sends operator-approved server options without ever requesting existing API-key text. */
final class ServerSettingsScreen extends Screen {
    private final Screen parent;private final JsonObject data;private final List<EditBox> keys=new ArrayList<>();
    private EditBox model,missionCount;private boolean enabled;private String difficulty;
    ServerSettingsScreen(Screen parent,JsonObject data){super(Component.translatable("ui.false_traveler.server_settings_title"));this.parent=parent;this.data=data;enabled=data.get("groqEnabled").getAsBoolean();difficulty=data.get("bossDifficulty").getAsString();}
    @Override protected void init(){
        keys.clear();int total=Math.min(560,width-20),left=(width-total)/2,top=Math.max(20,height/2-150),gap=8,col=(total-gap)/2;
        model=new EditBox(font,left,top+22,total,20,Component.translatable("ui.false_traveler.setting.groq_model"));model.setMaxLength(128);model.setValue(data.get("groqModel").getAsString());addRenderableWidget(model);
        JsonArray configured=data.getAsJsonArray("configuredKeys");
        for(int i=0;i<10;i++){
            int x=left+(i%2)*(col+gap),y=top+52+(i/2)*24;EditBox box=new EditBox(font,x,y,col,20,Component.literal("API Key "+(i+1)));box.setMaxLength(256);
            box.setHint(Component.translatable("ui.false_traveler.setting.groq_key",i+1,configured.get(i).getAsBoolean()?Component.translatable("ui.false_traveler.configured"):Component.translatable("ui.false_traveler.not_configured")));
            keys.add(box);addRenderableWidget(box);
        }
        int buttons=top+178;
        addRenderableWidget(Button.builder(enabledLabel(),b->{enabled=!enabled;b.setMessage(enabledLabel());}).bounds(left,buttons,col,20).build());
        addRenderableWidget(Button.builder(difficultyLabel(),b->{difficulty=switch(difficulty){case "NORMAL"->"HARD";case "HARD"->"NIGHTMARE";default->"NORMAL";};b.setMessage(difficultyLabel());}).bounds(left+col+gap,buttons,col,20).build());
        missionCount=new EditBox(font,left,buttons+27,total,20,Component.translatable("ui.false_traveler.setting.mission_count"));missionCount.setMaxLength(2);missionCount.setFilter(s->s.matches("\\d{0,2}"));missionCount.setValue(String.valueOf(data.get("missionCount").getAsInt()));missionCount.setHint(Component.translatable("ui.false_traveler.setting.mission_count"));addRenderableWidget(missionCount);
        addRenderableWidget(Button.builder(Component.translatable("ui.false_traveler.save"),b->save()).bounds(left,buttons+54,col,20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.cancel"),b->onClose()).bounds(left+col+gap,buttons+54,col,20).build());
    }
    private Component enabledLabel(){return Component.translatable("ui.false_traveler.setting.groq_enabled",Component.translatable(enabled?"options.on":"options.off"));}
    private Component difficultyLabel(){return Component.translatable("ui.false_traveler.setting.boss_difficulty",Component.translatable("ui.false_traveler.difficulty."+difficulty.toLowerCase(java.util.Locale.ROOT)));}
    private void save(){
        JsonObject update=new JsonObject();update.addProperty("groqEnabled",enabled);update.addProperty("groqModel",model.getValue());update.addProperty("bossDifficulty",difficulty);
        try{update.addProperty("missionCount",Math.max(3,Math.min(30,Integer.parseInt(missionCount.getValue()))));}catch(NumberFormatException ignored){update.addProperty("missionCount",30);}
        for(int i=0;i<keys.size();i++){String value=keys.get(i).getValue().trim();if(!value.isBlank())update.addProperty("key"+(i+1),value);}
        Network.updateServerSettings(update.toString());minecraft.setScreen(parent);
    }
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float dt){
        g.fill(0,0,width,height,0xF0101826);int top=Math.max(20,height/2-150);g.drawCenteredString(font,title,width/2,top,0xE8D8AC);
        g.drawString(font,Component.translatable("ui.false_traveler.setting.groq_model"),Math.max(10,(width-Math.min(560,width-20))/2),top+11,0xAFC6D8,false);
        g.drawCenteredString(font,Component.translatable("ui.false_traveler.key_help"),width/2,top+260,0x91A3AF);super.render(g,mouseX,mouseY,dt);
    }
    @Override public void renderBackground(GuiGraphics g,int mouseX,int mouseY,float dt){}
    @Override public void onClose(){minecraft.setScreen(parent);}
    @Override public boolean isPauseScreen(){return false;}
}
