package jp.false_traveler.client;

import jp.false_traveler.FalseTraveler;
import jp.false_traveler.ShadowEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public final class ShadowRenderer extends HumanoidMobRenderer<ShadowEntity, TravelerModel<ShadowEntity>> {
    private static final ResourceLocation TEXTURE = FalseTraveler.id("textures/entity/shadow.png");
    public ShadowRenderer(EntityRendererProvider.Context ctx) { super(ctx, new TravelerModel<>(ctx.bakeLayer(TravelerModel.LAYER)), .4F); }
    @Override public ResourceLocation getTextureLocation(ShadowEntity entity) { return TEXTURE; }
}
