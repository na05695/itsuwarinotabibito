package jp.false_traveler.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import jp.false_traveler.FalseTraveler;
import jp.false_traveler.ModConfig;
import jp.false_traveler.Network;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.FormattedCharSequence;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/** This class is discovered only on the physical client. */
@EventBusSubscriber(modid = FalseTraveler.MOD_ID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class ClientEvents {
    private static final KeyMapping SKIP = new KeyMapping("key.false_traveler.skip", GLFW.GLFW_KEY_K, "key.categories.false_traveler");
    private static JsonObject hud;
    private static JsonObject reveal;
    private static boolean skipSent;
    private static long receivedAt;
    private static Component cueText;
    private static long cueUntil, shakeUntil;
    private static Screen settingsParent;
    private static String windowMode="normal";
    private static int guiScaleTicks;

    @SubscribeEvent
    public static void setup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            Network.CLIENT_HANDLER = ClientEvents::receive;
            NeoForge.EVENT_BUS.addListener(ClientEvents::tick);
            NeoForge.EVENT_BUS.addListener(ClientEvents::camera);
        });
    }

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent event) { event.register(SKIP); }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(FalseTraveler.LUKA.get(), LukaRenderer::new);
        event.registerEntityRenderer(FalseTraveler.SHADOW.get(), ShadowRenderer::new);
    }

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(TravelerModel.LAYER, TravelerModel::createLayer);
    }

    @SubscribeEvent
    public static void gui(RegisterGuiLayersEvent event) {
        event.registerAboveAll(FalseTraveler.id("story"), (graphics, delta) -> renderHud(graphics));
    }

    private static void receive(String raw) {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> {
            try {
                JsonObject data = JsonParser.parseString(raw).getAsJsonObject();
                switch (string(data, "mode", "")) {
                    case "hud" -> {
                        if (hud != null && integer(hud, "stage", -1) != 7 && integer(data, "stage", -1) == 7) playCue("defeat");
                        hud = data;
                        updateWindowTitle(mc,data);
                        if (integer(data, "stage", -1) != 5) { reveal = null; skipSent = false; }
                    }
                    case "reveal" -> {
                        if (reveal == null) playCue("dialogue");
                        if (reveal == null || integer(reveal, "session", -1) != integer(data, "session", -1)) skipSent = false;
                        reveal = data;
                        receivedAt = System.currentTimeMillis();
                        if (mc.screen instanceof DialogueScreen) mc.setScreen(null);
                    }
                    case "close" -> {
                        reveal = null;
                        if (mc.screen instanceof DialogueScreen) mc.setScreen(null);
                    }
                    case "dialogue", "journal", "ready" -> { playCue("dialogue"); mc.setScreen(new DialogueScreen(data)); }
                    case "end_roll" -> { reveal=null;mc.setScreen(new EndRollScreen()); }
                    case "server_settings" -> { Screen parent=settingsParent!=null?settingsParent:mc.screen;settingsParent=null;mc.setScreen(new ServerSettingsScreen(parent,data)); }
                    case "cue" -> {
                        String sound = string(data, "sound", "warning");
                        if (List.of("warning", "transform", "defeat", "dialogue").contains(sound)) playCue(sound);
                        cueText = component(data, "body");
                        cueUntil = System.currentTimeMillis() + 2200;
                        if (sound.equals("transform")) shakeUntil = System.currentTimeMillis() + 4200;
                    }
                    default -> { }
                }
            } catch (RuntimeException ignored) { /* A malformed presentation packet cannot change world state. */ }
        });
    }
    static void requestServerSettings(Screen parent){settingsParent=parent;Network.requestServerSettings();}

    private static void tick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        // Two client ticks = 0.1 seconds. Resize only when the option changed.
        if (++guiScaleTicks >= 2) {
            guiScaleTicks = 0;
            if (mc.options.guiScale().get() != 2) {
                mc.options.guiScale().set(2);
                mc.resizeDisplay();
                mc.options.save();
            }
        }
        if (mc.player == null || mc.level == null) { hud = null; reveal = null; cueText = null; shakeUntil = 0; skipSent = false;if(!windowMode.equals("normal")){windowMode="normal";GLFW.glfwSetWindowTitle(mc.getWindow().getWindow(),"Minecraft 1.21.1");}return; }
        while (SKIP.consumeClick()) {
            if (reveal != null && !skipSent && mc.screen == null) {
                Network.sendAction(integer(reveal, "session", 0), "skip");
                skipSent = true;
            }
        }
    }

    private static void playCue(String name) {
        float volume = ModConfig.CINEMATIC_VOLUME.get().floatValue();
        if (volume > 0) Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvent.createVariableRangeEvent(FalseTraveler.id(name)), 1.0F, volume));
    }

    private static void camera(ViewportEvent.ComputeCameraAngles event) {
        long remaining = shakeUntil - System.currentTimeMillis();
        if (remaining > 0 && ModConfig.SCREEN_SHAKE.get()) {
            float intensity = Math.min(1, remaining / 800.0F);
            double time=System.currentTimeMillis();
            event.setRoll(event.getRoll() + (float)Math.sin(time * .048) * intensity * 1.8F);
            event.setPitch(event.getPitch() + (float)Math.sin(time * .071) * intensity * .9F);
            event.setYaw(event.getYaw() + (float)Math.cos(time * .063) * intensity * .8F);
        }
    }

    private static void renderHud(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        int screenW = mc.getWindow().getGuiScaledWidth(), screenH = mc.getWindow().getGuiScaledHeight();
        if (cueText != null && System.currentTimeMillis() < cueUntil && ModConfig.SUBTITLES.get()) {
            int cueW = Math.min(screenW - 32, mc.font.width(cueText) + 20);
            int cx = (screenW - cueW) / 2, cy = Math.max(22, screenH / 4);
            g.fill(cx, cy, cx + cueW, cy + 22, 0xDA231C2F);
            g.drawCenteredString(mc.font, cueText, screenW / 2, cy + 7, 0xF5E4BB);
        }
        if (hud != null && ModConfig.SHOW_OBJECTIVE.get() && mc.screen == null) {
            String objective = string(hud, "objective", "");
            if (!objective.isBlank()) {
                int maxW = Math.max(80, Math.min(252, screenW / 2 - 18));
                List<FormattedCharSequence> lines = mc.font.split(objectiveComponent(hud), maxW - 16);
                int boxH = 24 + lines.size() * 11;
                boolean target = hud.has("targetX") && hud.has("targetZ") && mc.level != null && mc.level.dimension().location().equals(FalseTraveler.id("valley"));
                if (target) boxH += 15;
                g.fill(7, 7, maxW + 15, 7 + boxH, 0xC9131C27);
                g.fill(7, 7, 9, 7 + boxH, 0xFFCFB878);
                g.drawString(mc.font, Component.translatable("ui.false_traveler.objective"), 16, 13, 0xDAC893, false);
                int y = 27;
                for (FormattedCharSequence line : lines) { g.drawString(mc.font, line, 16, y, 0xF1F1E8, false); y += 11; }
                if (target) {
                    double dx = hud.get("targetX").getAsDouble() - mc.player.getX(), dz = hud.get("targetZ").getAsDouble() - mc.player.getZ();
                    double angle = Math.toDegrees(Math.atan2(-dx, dz)) - mc.player.getYRot();
                    double wrapped = (angle % 360 + 540) % 360 - 180;
                    String direction = Math.abs(wrapped) < 35 ? "forward" : Math.abs(wrapped) > 145 ? "back" : wrapped > 0 ? "right" : "left";
                    String name = I18n.get(string(hud, "targetName", "ui.false_traveler.shrine"));
                    g.drawString(mc.font, Component.translatable("ui.false_traveler.direction", I18n.get("ui.false_traveler." + direction), name, Math.round(Math.sqrt(dx * dx + dz * dz))), 16, y + 2, 0x9BBECC, false);
                }
            }
        }
        if (reveal != null) {
            int w = Math.min(430, screenW - 24), x = (screenW - w) / 2;
            List<FormattedCharSequence> lines = mc.font.split(component(reveal, "body"), w - 28);
            int h = 54 + lines.size() * 12, y = Math.max(12, screenH - h - 42);
            g.fill(x, y, x + w, y + h, 0xEC141320);
            g.fill(x, y, x + w, y + 2, 0xFFC098D7);
            g.drawString(mc.font, component(reveal, "title"), x + 14, y + 12, 0xE7C8F0, false);
            int ty = y + 29;
            for (FormattedCharSequence line : lines) { g.drawString(mc.font, line, x + 14, ty, 0xF7F0F5, false); ty += 12; }
            boolean canSkip = reveal.has("choices") && reveal.getAsJsonArray("choices").size() > 0;
            Component hint = !canSkip ? Component.translatable("ui.false_traveler.countdown_hint")
                : skipSent ? Component.translatable("ui.false_traveler.skip_voted")
                : Component.translatable("ui.false_traveler.skip_hint", SKIP.getTranslatedKeyMessage());
            g.drawString(mc.font, hint, x + 14, y + h - 15, 0xACA2BD, false);
            int duration = integer(reveal, "durationMs", canSkip ? 6000 : 1000);
            float progress = Math.min(1, (System.currentTimeMillis() - receivedAt) / (float) Math.max(1, duration));
            g.fill(x, y + h - 2, x + (int)(w * progress), y + h, 0xFF88689E);
        }
    }

    static String string(JsonObject data, String key, String fallback) {
        return data.has(key) && data.get(key).isJsonPrimitive() ? data.get(key).getAsString() : fallback;
    }

    static int integer(JsonObject data, String key, int fallback) {
        try { return data.has(key) ? data.get(key).getAsInt() : fallback; } catch (RuntimeException ignored) { return fallback; }
    }

    static Component component(JsonObject data, String key) {
        String value = string(data, key, "");
        if (data.has(key + "Literal") && data.get(key + "Literal").getAsBoolean()) return Component.literal(value);
        Object[] args = data.has("args") && data.get("args").isJsonArray()
                ? java.util.stream.StreamSupport.stream(data.getAsJsonArray("args").spliterator(), false).map(e -> e.getAsString()).toArray()
                : new Object[0];
        // Resolve packet arguments eagerly. This avoids the untranslated "%s" placeholders that
        // some resource-pack/language reload combinations left visible in server-driven screens.
        return args.length==0?Component.translatable(value):Component.literal(I18n.get(value,args));
    }
    private static Component objectiveComponent(JsonObject data){
        String type=string(data,"missionType","");
        if(type.equals("supply"))return Component.translatable("objective.false_traveler.mission_detail",integer(data,"missionNumber",1),integer(data,"missionTotal",30),Component.translatable(string(data,"missionItem","item.minecraft.air")),integer(data,"missionRequired",0),integer(data,"missionHeld",0));
        if(type.equals("shrine"))return Component.translatable("objective.false_traveler.shrine_detail",integer(data,"missionNumber",1),integer(data,"missionTotal",30),Component.translatable(string(data,"missionShrine","ui.false_traveler.shrine")));
        return component(data,"objective");
    }
    private static void updateWindowTitle(Minecraft mc,JsonObject data){
        boolean valley=data.has("inValley")&&data.get("inValley").getAsBoolean();int stage=integer(data,"stage",0);
        String mode=!valley?"normal":stage==5||stage==6?"boss":"valley";if(mode.equals(windowMode))return;windowMode=mode;
        String title=mode.equals("boss")?I18n.get("window.false_traveler.boss"):mode.equals("valley")?I18n.get("window.false_traveler.valley"):"Minecraft 1.21.1";
        GLFW.glfwSetWindowTitle(mc.getWindow().getWindow(),title);
    }
}
