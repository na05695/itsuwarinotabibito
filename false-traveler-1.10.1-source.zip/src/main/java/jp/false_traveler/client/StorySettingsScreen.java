package jp.false_traveler.client;

import jp.false_traveler.ModConfig;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.common.ModConfigSpec;

/** Mod-specific accessibility settings, reachable directly from the journal. */
final class StorySettingsScreen extends Screen {
    private final Screen parent;
    StorySettingsScreen(Screen parent) { super(Component.translatable("ui.false_traveler.settings_title")); this.parent = parent; }

    @Override protected void init() {
        int x = Math.max(8, width / 2 - 120), w = Math.min(240, width - 16), y = Math.max(28, height / 2 - 66);
        toggle("objective", ModConfig.SHOW_OBJECTIVE, x, y, w);
        toggle("subtitles", ModConfig.SUBTITLES, x, y + 24, w);
        toggle("screen_shake", ModConfig.SCREEN_SHAKE, x, y + 48, w);
        addRenderableWidget(Button.builder(volumeLabel(), b -> {
            double current = ModConfig.CINEMATIC_VOLUME.get();
            ModConfig.CINEMATIC_VOLUME.set(current >= .99 ? 0.0 : Math.min(1.0, Math.round((current + .25) * 4) / 4.0));
            ModConfig.CINEMATIC_VOLUME.save();
            b.setMessage(volumeLabel());
        }).bounds(x, y + 72, w, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("ui.false_traveler.server_settings"),b->ClientEvents.requestServerSettings(this)).bounds(x,y+96,w,20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> onClose()).bounds(x, y + 127, w, 20).build());
    }

    private Component volumeLabel() { return Component.translatable("ui.false_traveler.setting.volume", (int)Math.round(ModConfig.CINEMATIC_VOLUME.get() * 100)); }
    private void toggle(String key, ModConfigSpec.BooleanValue value, int x, int y, int w) {
        addRenderableWidget(Button.builder(label(key, value.get()), b -> {
            value.set(!value.get()); value.save(); b.setMessage(label(key, value.get()));
        }).bounds(x, y, w, 20).build());
    }
    private Component label(String key, boolean value) { return Component.translatable("ui.false_traveler.setting." + key, Component.translatable(value ? "options.on" : "options.off")); }
    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float dt) {
        g.fill(0, 0, width, height, 0xDE101A27);
        g.drawCenteredString(font, title, width / 2, Math.max(10, height / 2 - 92), 0xE8D8AC);
        super.render(g, mouseX, mouseY, dt);
    }
    @Override public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float dt) {}
    @Override public void onClose() { minecraft.setScreen(parent); }
    @Override public boolean isPauseScreen() { return false; }
}
