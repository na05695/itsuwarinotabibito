package jp.false_traveler;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public final class QuestBlock extends Block {
    private final boolean altar;
    public QuestBlock(boolean altar,Properties p){super(p);this.altar=altar;}
    @Override protected InteractionResult useWithoutItem(BlockState state,Level level,BlockPos pos,Player player,BlockHitResult hit){
        if(player instanceof ServerPlayer p && Valley.isValley(level)){
            if(altar && pos.equals(Valley.ALTAR_POS))QuestManager.openAltar(p);
            else if(!altar)for(int i=0;i<3;i++)if(pos.equals(Valley.SHRINES[i]))QuestManager.usePedestal(p,i);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
