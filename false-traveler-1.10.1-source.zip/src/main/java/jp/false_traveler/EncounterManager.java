package jp.false_traveler;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

/** Server-only encounter ownership, persistent wave recovery and one-NPC invariant. */
public final class EncounterManager {
    private static final int SHRINE_GUARDS=5;
    private static final Map<MinecraftServer, RuntimeState> RUNTIMES = new WeakHashMap<>();
    private EncounterManager() {}
    private static RuntimeState runtime(MinecraftServer server) { return RUNTIMES.computeIfAbsent(server, ignored -> new RuntimeState()); }
    private static final class RuntimeState { int invalidBossTicks; Stage lastStage; }

    public static boolean isSurvivalPlayer(ServerPlayer player) { return player.isAlive() && !player.isCreative() && !player.isSpectator() && Valley.isValley(player.level()); }
    public static boolean isLiveParticipant(ServerPlayer player) {
        if (!isSurvivalPlayer(player)) return false;
        QuestData quest = QuestData.get(player.server);
        return quest.stage == Stage.BATTLE && quest.alive.contains(player.getUUID()) && Valley.inArena(player);
    }
    public static List<ServerPlayer> liveParticipants(ServerLevel level) { return level.players().stream().filter(EncounterManager::isLiveParticipant).toList(); }
    public static boolean canShadowTarget(ShadowEntity shadow, ServerPlayer player) {
        if (!isSurvivalPlayer(player) || player.level() != shadow.level() || !isCurrentShadow(shadow)) return false;
        if (shadow.getShrine() == -2) return isLiveParticipant(player);
        BlockPos home = shadow.getShrine() == -1 ? training() : Valley.SHRINES[shadow.getShrine()];
        return player.distanceToSqr(home.getX() + .5, home.getY(), home.getZ() + .5) <= 28 * 28;
    }
    public static boolean isCurrentShadow(ShadowEntity shadow) {
        if (shadow.level().isClientSide || shadow.getEncounterId() == 0) return false;
        MinecraftServer server = shadow.level().getServer(); QuestData quest = QuestData.get(server); EncounterState state = EncounterState.get(server);
        int shrine = shadow.getShrine();
        if (shrine == -2) return quest.stage == Stage.BATTLE && shadow.getEncounterId() == quest.encounterId;
        if (shrine == -1) return false; // The retired training encounter is never part of the story order.
        return shrine >= 0 && shrine < 3 && quest.stage == Stage.FRAGMENTS && (quest.fragments & (1 << shrine)) == 0
            && (state.shrineCleared & (1 << shrine)) == 0 && shadow.getEncounterId() == state.shrineIds[shrine];
    }
    private static BlockPos training() { return Valley.CAMP.offset(12, 0, 0); }
    private static boolean entitiesReady(ServerLevel level) {
        // Valley.ensure tickets this complete bounded rectangle. Never infer absence from an unloaded chunk.
        for (int x = -6; x <= 5; x++) for (int z = -6; z <= 5; z++) if (!level.areEntitiesLoaded(ChunkPos.asLong(x, z))) return false;
        return true;
    }
    public static LukaEntity ensureLuka(MinecraftServer server) {
        QuestData quest = QuestData.get(server); ServerLevel level = Valley.ensure(server);
        if (level == null || !entitiesReady(level)) return null;
        List<LukaEntity> found = new ArrayList<>();
        for (Entity entity : level.getAllEntities()) if (entity instanceof LukaEntity luka && luka.isAlive()) found.add(luka);
        found.sort(Comparator.comparing(e -> e.getUUID().toString()));
        if (quest.stage == Stage.CLEARED) { found.forEach(Entity::discard); return null; }
        LukaEntity chosen = found.stream().filter(e -> e.getUUID().equals(quest.lukaId)).findFirst().orElse(found.isEmpty() ? null : found.getFirst());
        for (LukaEntity duplicate : found) if (duplicate != chosen) duplicate.discard();
        if (chosen == null) {
            if (quest.active()) return null; // A vanished active boss must fail the encounter, never respawn mid-fight.
            chosen = FalseTraveler.LUKA.get().create(level);
            if (chosen == null) return null;
            BlockPos position = quest.stage == Stage.READY ? Valley.ARENA : Valley.CAMP;
            chosen.moveTo(position.getX() + .5, position.getY(), position.getZ() + .5, 180, 0);
            level.addFreshEntity(chosen);
        }
        if (!chosen.getUUID().equals(quest.lukaId)) { quest.lukaId = chosen.getUUID(); quest.setDirty(); }
        if (!quest.active() && chosen.isHostile()) chosen.resetFriendly();
        return chosen;
    }
    public static void tick(MinecraftServer server) {
        QuestData quest = QuestData.get(server); if (!quest.valleyBuilt) return;
        ServerLevel level = server.getLevel(Valley.KEY); if (level == null) return;
        RuntimeState runtime = runtime(server);
        if (quest.active()) {
            Entity entity = quest.lukaId == null ? null : level.getEntity(quest.lukaId);
            boolean valid = entity instanceof LukaEntity luka && luka.isAlive() && Valley.inArena(luka);
            runtime.invalidBossTicks = valid ? 0 : runtime.invalidBossTicks + 1;
            if (runtime.invalidBossTicks >= 100 && entitiesReady(level)) { runtime.invalidBossTicks = 0; QuestManager.failEncounter(server); return; }
        } else runtime.invalidBossTicks = 0;
        if (server.getTickCount() % 20 != 0 || !entitiesReady(level)) return;
        LukaEntity luka = ensureLuka(server);
        if (runtime.lastStage != quest.stage) {
            if (luka != null && quest.stage == Stage.READY) { luka.resetFriendly(); luka.moveTo(Valley.ARENA.getX() + .5, Valley.ARENA.getY(), Valley.ARENA.getZ() + .5, 180, 0); }
            runtime.lastStage = quest.stage;
        }
        if (quest.stage == Stage.FRAGMENTS) {
            EncounterState state = EncounterState.get(server);
            for (int shrine = 0; shrine < 3; shrine++) {
                if ((quest.fragments & (1 << shrine)) != 0 || shrineClear(server, shrine)) continue;
                int index = shrine;
                if (state.shrineIds[index] != 0 || level.players().stream().anyMatch(p -> isSurvivalPlayer(p) && p.distanceToSqr(Vec3.atCenterOf(Valley.SHRINES[index])) < 20 * 20)) startShrine(server, index);
            }
        }
        for (Entity entity : level.getAllEntities()) if (entity instanceof ShadowEntity shadow && !isCurrentShadow(shadow)) shadow.discard();
    }
    public static void startShrine(MinecraftServer server, int shrine) {
        if (shrine < 0 || shrine > 2) return;
        QuestData quest = QuestData.get(server); if (quest.stage != Stage.FRAGMENTS || (quest.fragments & (1 << shrine)) != 0 || shrineClear(server, shrine)) return;
        ServerLevel level = Valley.ensure(server); if (level == null || !entitiesReady(level)) return;
        EncounterState state = EncounterState.get(server);
        if (state.shrineIds[shrine] == 0) { state.shrineIds[shrine] = state.allocate(); state.setDirty(); }
        ensureWave(level, state.shrineIds[shrine], shrine, Valley.SHRINES[shrine], Math.max(0, SHRINE_GUARDS - state.shrineKills[shrine]));
    }
    private static void ensureWave(ServerLevel level, long id, int shrine, BlockPos center, int desired) {
        long current = shadows(level).stream().filter(e -> e.isAlive() && e.getEncounterId() == id && e.getShrine() == shrine).count();
        for (int i = (int)current; i < desired; i++) {
            double angle = (i + 1) * Math.PI * 2 / SHRINE_GUARDS;
            spawnShadow(level, id, shrine, Vec3.atBottomCenterOf(center).add(Math.sin(angle) * 5, 0, Math.cos(angle) * 5));
        }
    }
    private static ShadowEntity spawnShadow(ServerLevel level, long id, int shrine, Vec3 position) {
        ShadowEntity shadow = FalseTraveler.SHADOW.get().create(level); if (shadow == null) return null;
        shadow.moveTo(position.x, position.y, position.z, 0, 0); shadow.setEncounter(id, shrine); level.addFreshEntity(shadow); return shadow;
    }
    private static List<ShadowEntity> shadows(ServerLevel level) {
        List<ShadowEntity> result = new ArrayList<>(); for (Entity entity : level.getAllEntities()) if (entity instanceof ShadowEntity shadow) result.add(shadow); return result;
    }
    public static boolean shrineClear(MinecraftServer server, int shrine) {
        return shrine >= 0 && shrine < 3 && ((EncounterState.get(server).shrineCleared | QuestData.get(server).fragments) & (1 << shrine)) != 0;
    }
    public static void onShadowKilled(ShadowEntity shadow) {
        if (!isCurrentShadow(shadow)) return;
        MinecraftServer server = shadow.level().getServer(); QuestData quest = QuestData.get(server); EncounterState state = EncounterState.get(server);
        if (shadow.getShrine() >= 0 && shadow.getShrine() <= 2) {
            int shrine = shadow.getShrine(); state.shrineKills[shrine] = Math.min(SHRINE_GUARDS, state.shrineKills[shrine] + 1);
            if (state.shrineKills[shrine] >= SHRINE_GUARDS) state.shrineCleared |= 1 << shrine; state.setDirty();
        }
    }
    public static void startBoss(MinecraftServer server) {
        QuestData quest = QuestData.get(server); LukaEntity luka = ensureLuka(server); if (luka == null) return;
        quest.encounterId = EncounterState.get(server).allocate(); quest.setDirty();
        setBattleBarrier(server,true);
        luka.moveTo(Valley.ARENA.getX() + .5, Valley.ARENA.getY(), Valley.ARENA.getZ() + .5, 180, 0);
        luka.beginBattle(quest.participants.size(), ModConfig.BOSS_BASE_HEALTH.get()*ModConfig.bossHealthScale(), ModConfig.BOSS_DAMAGE_MULTIPLIER.get()*ModConfig.bossDamageScale()); runtime(server).invalidBossTicks = 0;
    }
    public static long bossMinionCount(MinecraftServer server) {
        ServerLevel level = server.getLevel(Valley.KEY); if (level == null) return 0; long id = QuestData.get(server).encounterId;
        return shadows(level).stream().filter(e -> e.isAlive() && e.getShrine() == -2 && e.getEncounterId() == id).count();
    }
    public static void summonBossMinions(MinecraftServer server, Vec3 position) {
        QuestData quest = QuestData.get(server); ServerLevel level = server.getLevel(Valley.KEY);
        if (level == null || quest.stage != Stage.BATTLE) return;
        int spawn = (int)Math.min(2, 4 - bossMinionCount(server));
        for (int i = 0; i < spawn; i++) {
            Vec3 candidate = position.add(i == 0 ? 2 : -2, 0, 2);
            double dx = candidate.x - Valley.ARENA.getX(), dz = candidate.z - Valley.ARENA.getZ();
            if (!CombatRules.withinCircle(dx, dz, 18)) candidate = Vec3.atBottomCenterOf(Valley.ARENA).add(i == 0 ? 3 : -3, 0, 0);
            spawnShadow(level, quest.encounterId, -2, candidate);
        }
    }
    public static void cleanup(MinecraftServer server) {
        ServerLevel level = server.getLevel(Valley.KEY); if (level == null) return;
        setBattleBarrier(server,false);
        shadows(level).forEach(Entity::discard);
        for (Entity entity : level.getAllEntities()) if (entity instanceof LukaEntity luka) luka.clearCombat();
        runtime(server).invalidBossTicks = 0;
    }
    public static void recover(MinecraftServer server) {
        if (QuestData.get(server).active()) { QuestManager.failEncounter(server); return; }
        LukaEntity luka = ensureLuka(server);
        if (luka != null) { luka.resetFriendly(); BlockPos pos = QuestData.get(server).stage == Stage.READY ? Valley.ARENA : Valley.CAMP; luka.moveTo(pos.getX() + .5, pos.getY(), pos.getZ() + .5, 180, 0); }
    }
    public static void reset(MinecraftServer server) {
        cleanup(server); EncounterState state = EncounterState.get(server); state.defenseId = 0; state.defenseHealUsed = false; state.shrineCleared = 0;
        for (int i = 0; i < 3; i++) { state.shrineIds[i] = 0; state.shrineKills[i] = 0; } state.setDirty(); runtime(server).lastStage = null;
    }
    public static void setBattleBarrier(MinecraftServer server,boolean enabled){
        ServerLevel level=server.getLevel(Valley.KEY);if(level==null)return;
        for(int x=-22;x<=22;x++)for(int z=-22;z<=22;z++){
            int radius=x*x+z*z;if(radius<400||radius>484)continue;
            for(int y=65;y<=73;y++){
                BlockPos pos=new BlockPos(Valley.ARENA.getX()+x,y,Valley.ARENA.getZ()+z);
                if(enabled){if(level.getBlockState(pos).isAir())level.setBlockAndUpdate(pos,Blocks.BARRIER.defaultBlockState());}
                else if(level.getBlockState(pos).is(Blocks.BARRIER))level.setBlockAndUpdate(pos,Blocks.AIR.defaultBlockState());
            }
        }
    }
}
