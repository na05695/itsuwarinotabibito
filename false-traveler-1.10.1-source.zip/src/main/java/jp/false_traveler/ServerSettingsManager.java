package jp.false_traveler;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.List;
import net.minecraft.server.level.ServerPlayer;

/** Operator-only bridge for editing server options from the mod settings screen. */
public final class ServerSettingsManager {
    private static boolean allowed(ServerPlayer player){return player.createCommandSourceStack().hasPermission(2);}
    public static void open(ServerPlayer player){
        if(!allowed(player)){QuestManager.notify(player,"message.false_traveler.server_settings_denied");return;}
        JsonObject data=new JsonObject();data.addProperty("mode","server_settings");data.addProperty("groqEnabled",ModConfig.GROQ_ENABLED.get());
        data.addProperty("groqModel",ModConfig.GROQ_MODEL.get());data.addProperty("bossDifficulty",ModConfig.BOSS_DIFFICULTY.get());data.addProperty("missionCount",ModConfig.MISSION_COUNT.get());
        JsonArray configured=new JsonArray();for(var key:ModConfig.GROQ_API_KEYS)configured.add(!key.get().isBlank());data.add("configuredKeys",configured);
        Network.send(player,data);
    }
    public static void update(ServerPlayer player,String raw){
        if(!allowed(player)){QuestManager.notify(player,"message.false_traveler.server_settings_denied");return;}
        try{
            JsonObject data=JsonParser.parseString(raw).getAsJsonObject();
            if(data.has("groqEnabled")){ModConfig.GROQ_ENABLED.set(data.get("groqEnabled").getAsBoolean());ModConfig.GROQ_ENABLED.save();}
            if(data.has("groqModel")){
                String model=data.get("groqModel").getAsString().trim();
                if(model.matches("[A-Za-z0-9._/-]{1,128}")){ModConfig.GROQ_MODEL.set(model);ModConfig.GROQ_MODEL.save();}
            }
            if(data.has("bossDifficulty")){
                String difficulty=data.get("bossDifficulty").getAsString().toUpperCase(java.util.Locale.ROOT);
                if(List.of("NORMAL","HARD","NIGHTMARE").contains(difficulty)){ModConfig.BOSS_DIFFICULTY.set(difficulty);ModConfig.BOSS_DIFFICULTY.save();}
            }
            if(data.has("missionCount")){
                int count=Math.max(3,Math.min(30,data.get("missionCount").getAsInt()));
                ModConfig.MISSION_COUNT.set(count);ModConfig.MISSION_COUNT.save();
            }
            for(int i=0;i<10;i++)if(data.has("key"+(i+1))){
                String key=data.get("key"+(i+1)).getAsString().trim();if(key.equals("-"))key="";
                if(key.length()<=256){ModConfig.GROQ_API_KEYS.get(i).set(key);ModConfig.GROQ_API_KEYS.get(i).save();}
            }
            QuestManager.notify(player,"message.false_traveler.server_settings_saved");
            for(ServerPlayer online:player.server.getPlayerList().getPlayers())if(online!=player)QuestManager.notify(online,"message.false_traveler.ai_settings_synced");
        }catch(RuntimeException ignored){QuestManager.notify(player,"message.false_traveler.server_settings_invalid");}
    }
    private ServerSettingsManager(){}
}
