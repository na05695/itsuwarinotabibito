package jp.false_traveler;

import java.util.Comparator;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.level.Level;

public class ShadowEntity extends PathfinderMob {
    private long encounterId;
    private int shrine = -1;
    private BlockPos home = BlockPos.ZERO;
    private boolean credited;
    public ShadowEntity(EntityType<? extends ShadowEntity> type, Level level) {
        super(type, level); setPersistenceRequired(); xpReward = 0;
    }
    public static AttributeSupplier.Builder createAttributes() {
        return createMobAttributes().add(Attributes.MAX_HEALTH, 16).add(Attributes.ATTACK_DAMAGE, 3).add(Attributes.ARMOR,0).add(Attributes.MOVEMENT_SPEED, .24).add(Attributes.FOLLOW_RANGE, 24);
    }
    @Override protected void registerGoals() { goalSelector.addGoal(0, new FloatGoal(this)); goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0, false)); }
    public void setEncounter(long id, int shrine) { this.encounterId = id; this.shrine = shrine; this.home = blockPosition(); configureStrength(true); }
    public long getEncounterId() { return encounterId; }
    public int getShrine() { return shrine; }
    @Override public boolean removeWhenFarAway(double distance) { return false; }
    @Override public boolean canBeLeashed() { return false; }
    @Override protected void dropAllDeathLoot(ServerLevel level, DamageSource source) {}
    @Override public boolean doHurtTarget(Entity target) {
        if (!(target instanceof ServerPlayer player) || !EncounterManager.canShadowTarget(this, player)) return false;
        return player.hurt(CombatDamage.source(this, CombatDamage.STRIKE, position()), (shrine>=0?4:3) * CombatDamage.difficulty(this));
    }
    @Override public void tick() {
        super.tick();
        if (!(level() instanceof ServerLevel serverLevel) || !isAlive()) return;
        if (getTarget() instanceof ServerPlayer player && !EncounterManager.canShadowTarget(this, player)) setTarget(null);
        if (tickCount % 20 == 0) {
            if (!EncounterManager.isCurrentShadow(this)) { discard(); return; }
            setTarget(serverLevel.players().stream().filter(p -> EncounterManager.canShadowTarget(this, p))
                .filter(p -> p.distanceToSqr(this) <= 24 * 24)
                .min(Comparator.comparingDouble((ServerPlayer p) -> p.distanceToSqr(this)).thenComparing(p -> p.getUUID().toString())).orElse(null));
            if (distanceToSqr(home.getX() + .5, home.getY(), home.getZ() + .5) > 30 * 30 || getY() < 60) {
                setTarget(null); moveTo(home.getX() + .5, home.getY(), home.getZ() + .5, 0, 0); getNavigation().stop();
            }
        }
    }
    @Override public void die(DamageSource source) {
        if (!level().isClientSide && !credited) { credited = true; QuestManager.onShadowKilled(this); }
        super.die(source);
    }
    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag); tag.putLong("EncounterId", encounterId); tag.putInt("Shrine", shrine); tag.putLong("Home", home.asLong()); tag.putBoolean("Credited", credited);
    }
    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag); encounterId = tag.getLong("EncounterId"); shrine = tag.getInt("Shrine"); home = BlockPos.of(tag.getLong("Home")); credited = tag.getBoolean("Credited");configureStrength(false);
    }
    private void configureStrength(boolean refill){
        if(getAttribute(Attributes.MAX_HEALTH)==null)return;
        double health=shrine>=0?24:16;getAttribute(Attributes.MAX_HEALTH).setBaseValue(health);getAttribute(Attributes.ARMOR).setBaseValue(shrine>=0?4:0);
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(shrine>=0?.27:.24);if(refill)setHealth((float)health);
    }
}
