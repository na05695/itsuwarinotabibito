package jp.false_traveler;

import java.util.ArrayList;
import java.util.List;
import net.neoforged.neoforge.common.ModConfigSpec;

public final class ModConfig {
    public static final ModConfigSpec SERVER, CLIENT;
    public static final ModConfigSpec.DoubleValue BOSS_BASE_HEALTH, BOSS_DAMAGE_MULTIPLIER, CINEMATIC_VOLUME;
    public static final ModConfigSpec.IntValue MAX_PARTICIPANTS, MISSION_COUNT, GROQ_TIMEOUT_SECONDS;
    public static final ModConfigSpec.BooleanValue GROQ_ENABLED, SHOW_OBJECTIVE, SUBTITLES, SCREEN_SHAKE;
    public static final ModConfigSpec.ConfigValue<String> GROQ_MODEL, BOSS_DIFFICULTY;
    public static final List<ModConfigSpec.ConfigValue<String>> GROQ_API_KEYS;
    static {
        ModConfigSpec.Builder b=new ModConfigSpec.Builder();
        BOSS_DIFFICULTY=b.comment("Boss preset: NORMAL, HARD or NIGHTMARE.").define("bossDifficulty","NORMAL",value->value instanceof String s&&List.of("NORMAL","HARD","NIGHTMARE").contains(s));
        BOSS_BASE_HEALTH=b.comment("Base HP for the next encounter. Default 1200.").defineInRange("bossBaseHealth",1200.0,40.0,8000.0);
        BOSS_DAMAGE_MULTIPLIER=b.defineInRange("bossDamageMultiplier",1.75,0.1,8.0);
        MAX_PARTICIPANTS=b.defineInRange("maxParticipants",10,1,10);
        MISSION_COUNT=b.comment("Total missions after the opening oak-log request, including the final three shrines. Range 3-30.").defineInRange("missionCount",30,3,30);
        b.push("groq");
        GROQ_ENABLED=b.comment("Enable server-side AI hints and Luka dialogue.").define("enabled",true);
        GROQ_MODEL=b.comment("Groq production model id. Keys are never sent to clients.").define("model","openai/gpt-oss-120b");
        GROQ_TIMEOUT_SECONDS=b.defineInRange("timeoutSeconds",12,3,30);
        List<ModConfigSpec.ConfigValue<String>> keys=new ArrayList<>();
        for(int i=1;i<=10;i++)keys.add(b.comment("Groq API key slot "+i+". Leave blank when unused.").define("apiKey"+i,""));
        GROQ_API_KEYS=List.copyOf(keys);
        b.pop();
        SERVER=b.build();b=new ModConfigSpec.Builder();
        SHOW_OBJECTIVE=b.define("showObjective",true);SUBTITLES=b.define("subtitles",true);
        SCREEN_SHAKE=b.define("screenShake",true);CINEMATIC_VOLUME=b.defineInRange("cinematicVolume",0.8,0.0,1.0);
        CLIENT=b.build();
    }
    public static List<String> groqKeys(){
        return GROQ_API_KEYS.stream().map(ModConfigSpec.ConfigValue::get).map(String::trim).filter(s->!s.isBlank()).distinct().toList();
    }
    public static double bossHealthScale(){return switch(BOSS_DIFFICULTY.get()){case "HARD"->1.45;case "NIGHTMARE"->2.0;default->1.0;};}
    public static double bossDamageScale(){return switch(BOSS_DIFFICULTY.get()){case "HARD"->1.25;case "NIGHTMARE"->1.65;default->1.0;};}
    private ModConfig(){}
}
