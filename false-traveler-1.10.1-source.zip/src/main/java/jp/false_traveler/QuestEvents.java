package jp.false_traveler;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.living.*;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

public final class QuestEvents {
    @SubscribeEvent public static void tick(ServerTickEvent.Post e){Valley.tick(e.getServer());QuestManager.tick(e.getServer());EncounterManager.tick(e.getServer());}
    @SubscribeEvent public static void started(ServerStartedEvent e){QuestManager.serverStarted(e.getServer());}
    @SubscribeEvent public static void login(PlayerEvent.PlayerLoggedInEvent e){if(e.getEntity() instanceof ServerPlayer p)QuestManager.login(p);}
    @SubscribeEvent public static void logout(PlayerEvent.PlayerLoggedOutEvent e){if(e.getEntity() instanceof ServerPlayer p)QuestManager.logout(p);}
    @SubscribeEvent public static void damage(LivingIncomingDamageEvent e){
        if(e.getEntity().level().isClientSide)return;
        var server=e.getEntity().getServer();if(server==null)return;QuestData d=QuestData.get(server);
        if(e.getEntity() instanceof ServerPlayer p){
            if(Valley.isValley(p.level())){
                if(d.stage==Stage.REVEAL || (d.active()&&!d.alive.contains(p.getUUID()))){e.setCanceled(true);return;}
                // Cooperative encounters do not allow friendly fire or spectator assistance.
                if(d.active()&&e.getSource().getEntity() instanceof ServerPlayer){e.setCanceled(true);return;}
            }
            QuestManager.close(p);
        }
        if(d.active()&&(e.getEntity() instanceof LukaEntity||e.getEntity() instanceof ShadowEntity)){
            if(!(e.getSource().getEntity() instanceof ServerPlayer attacker)||!d.alive.contains(attacker.getUUID())||!QuestManager.eligible(attacker))e.setCanceled(true);
        }
    }
    @SubscribeEvent public static void lethal(LivingDamageEvent.Pre e){
        if(e.getEntity() instanceof ServerPlayer p&&Valley.isValley(p.level())&&e.getNewDamage()>=p.getHealth()+p.getAbsorptionAmount()){
            e.setNewDamage(0);QuestManager.defeat(p);
        }
    }
    @SubscribeEvent public static void deathFallback(LivingDeathEvent e){
        if(e.getEntity() instanceof ServerPlayer p&&Valley.isValley(p.level())){e.setCanceled(true);QuestManager.defeat(p);}
    }
    @SubscribeEvent public static void commands(RegisterCommandsEvent e){
        e.getDispatcher().register(Commands.literal("false_traveler")
            .then(Commands.literal("journal").executes(c->{QuestManager.issueJournal(c.getSource().getPlayerOrException());return 1;}))
            .then(Commands.literal("status").executes(c->{QuestData d=QuestData.get(c.getSource().getServer());c.getSource().sendSuccess(()->Component.translatable(d.stage.objective()),false);return d.stage.ordinal();}))
            .then(Commands.literal("mission")
                .then(Commands.literal("skip").executes(c->{ServerPlayer p=c.getSource().getPlayerOrException();int changed=MissionManager.skip(p,false);int n=MissionManager.progress(QuestData.get(p.server),p);c.getSource().sendSuccess(()->changed==0?Component.translatable("message.false_traveler.mission_skip_unavailable"):Component.translatable("message.false_traveler.mission_skipped",n,MissionManager.count()),false);return changed;}))
                .then(Commands.literal("skip_all").executes(c->{ServerPlayer p=c.getSource().getPlayerOrException();int changed=MissionManager.skip(p,true);c.getSource().sendSuccess(()->changed==0?Component.translatable("message.false_traveler.mission_skip_unavailable"):Component.translatable("message.false_traveler.missions_skipped_all",MissionManager.count()),false);return changed;})))
            .then(Commands.literal("recover").requires(s->s.hasPermission(2)).executes(c->{QuestManager.recover(c.getSource().getServer());c.getSource().sendSuccess(()->Component.translatable("message.false_traveler.recovered"),true);return 1;}))
            .then(Commands.literal("reset").requires(s->s.hasPermission(2))
                .executes(c->{c.getSource().sendSuccess(()->Component.translatable("message.false_traveler.reset_warning"),false);return 0;})
                .then(Commands.literal("confirm").executes(c->{QuestManager.reset(c.getSource().getServer());c.getSource().sendSuccess(()->Component.translatable("message.false_traveler.reset_done"),true);return 1;})))
            .then(Commands.literal("debug").requires(s->s.hasPermission(2))
                .then(Commands.literal("ready").executes(c->{
                    ServerPlayer p=c.getSource().getPlayerOrException();if(QuestData.get(p.server).active())return 0;
                    Valley.enter(p);QuestData d=QuestData.get(p.server);d.stage=Stage.READY;d.fragments=7;d.setDirty();
                    p.teleportTo(p.serverLevel(),Valley.ALTAR_POS.getX()+0.5,Valley.ARENA.getY(),Valley.ALTAR_POS.getZ()+2.5,0,0);
                    c.getSource().sendSuccess(()->Component.translatable("message.false_traveler.debug_ready"),false);return 1;
                }))));
        e.getDispatcher().register(Commands.literal("ai").then(Commands.argument("message",StringArgumentType.greedyString()).executes(c->{ServerPlayer p=c.getSource().getPlayerOrException();GroqService.askCommand(p,StringArgumentType.getString(c,"message"));return 1;})));
    }
    private QuestEvents(){}
}
